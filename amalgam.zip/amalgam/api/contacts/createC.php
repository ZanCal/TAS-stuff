<?php 
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
// get database connection
include_once '../config/database.php';
// instantiate contact object
include_once '../objects/contact.php';

$database = new Database();
$db = $database->getConnection();

$contact = new Contact($db);

$data = json_decode(file_get_contents("php://input"));

if( //update these to be for contact instead of product. id and contactOf should not be included here as the user is 
    //oblivous to their existance. details should not also be included here because it can be null
    !empty($data->firstName) &&
    !empty($data->lastName) &&
    !empty($data->email) &&
    !empty($data->phoneNumber)
){
    // set product property values
    $contact->firstName = $data->firstName;
    $contact->lastName = $data->lastName;
    $contact->email = $data->email;
    $contact->phoneNumber = $data->phoneNumber;
    
    if (!empty($data->details)){
        $contact->details = $data->details;
    } else {
        $contact->details = "No details for this contact";
    }

    $contact->contactOf = $data->contactOf;

    // create the product
    if($contact->create() == true){
        http_response_code(201); 
        echo json_encode(array("message" => "Contact was added.", "contact" => $contact->create()));
    } else { // if unable to create the product, tell the user
        // set response code - 503 service unavailable
        http_response_code(503);
        echo json_encode(array("message" => "Unable to add Contact.", "contact" => $contact->create(), "data" => $data));
    }
} else {
    // set response code - 400 bad request
    http_response_code(400);
    echo json_encode(array("message" => "Unable to add Contact. Data is incomplete.", "contact" => $contact));
}
?>
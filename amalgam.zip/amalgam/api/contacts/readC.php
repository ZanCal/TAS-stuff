<?php 
//the beginning chunk of code is copied from the product read.php file
//something with this file is not working right, could it be an issue with contacts.php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
include_once '../config/database.php';
include_once '../objects/contact.php';
$database = new Database();
$db = $database->getConnection();

$contact = new Contact($db);
$stmt = $contact->read();
$num = $stmt->rowCount();

if($num > 0){

    $contacts_arr=array();
    $contacts_arr["contacts"]=array();

    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        //this is what is not working right
        //i have now reached a state where i have no idea what's going on, so i'm going to keep trying things 
        //until something works out right
        $contact_info=array( 
            "id" => $row['id'],
            "firstName" => $row['firstName'],
            "lastName" => $row['lastName'],
            "email" => $row['email'],
            "phoneNumber" => $row['phoneNumber'],
            "details" => $row['details']           
        );
 
        array_push($contacts_arr["contacts"], $contact_info);
    }
 
    // set response code - 200 OK
    http_response_code(200);
 
    // show contacts data in json format
    echo json_encode($contacts_arr);
}else{
 
    // set response code - 404 Not found
    http_response_code(404);
 
    // tell the user no contacts found
    echo json_encode(
        array("message" => "No contacts found.")
    );

}
?>
<?php 
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Credentials: true");
header('Content-Type: application/json');
include_once '../config/database.php';
include_once '../objects/contact.php';
$database = new Database();
$db = $database->getConnection();

$contact = new Contact($db);

$contact->id = isset($_GET['id']) ? $_GET['id'] : die(); 

$contact->readOne();

if($contact->firstName!=null){
    // create array
    $contact_arr = array(
        "id" =>  $contact->id,
        "firstName" => $contact->firstName,
        "lastName" => $contact->lastName,
        "email" => $contact->email,
        "phoneNumber" => $contact->phoneNumber,
        "details" => $contact->details
    );
    // set response code - 200 OK
    http_response_code(200);
    // make it json format
    echo json_encode($contact_arr);
}else{
    // set response code - 404 Not found
    http_response_code(404);
    // tell the user product does not exist
    echo json_encode(array("message" => "Contact does not exist.", "Contact" => $contact));
}

?>
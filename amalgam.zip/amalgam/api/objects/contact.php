<?php 
class Contact{
    //mosty copy pasted from product.php, with some tweaks of course

    private $conn;
    private $table_name = "contacts";

    public $id;
    public $firstName;
    public $lastName;
    public $email;
    public $phoneNumber;
    public $details;
    public $contactOf;

    public function __construct($db){
        $this->conn = $db;
    }

    function read(){ 
        $query = "SELECT
            c.id,
            c.firstName,
            c.lastName,
            c.email,
            c.phoneNumber,
            c.details
            FROM " . $this->table_name." c ";

        $stmt = $this->conn->prepare($query);

        $stmt->execute();

        return $stmt;
        
    }

    function readOne(){
        // query to read single record, hopefully this works
        $query = "SELECT
                id,
                firstName,
                lastName,
                email,
                phoneNumber,
                details
                FROM " . $this->table_name . "
            WHERE
                id = ?
            LIMIT
                0,1";
 
        // prepare query statement
        $stmt = $this->conn->prepare( $query );
 
        // bind id of product to be updated
        $stmt->bindParam(1, $this->id);
 
        // execute query
        $stmt->execute();
 
        // get retrieved row
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
 
        // set values to object properties
        $this->firstName = $row['firstName'];
        $this->lastName = $row['lastName'];
        $this->phoneNumber = $row['phoneNumber'];
        $this->email = $row['email'];
        $this->details = $row['details'];
        //i hope i did this right
    }

    function create(){ 

        $query = "INSERT INTO " . $this->table_name . "(`firstName`, `lastName`, `email`, `phoneNumber`, `details`,`contactOf`)
                VALUES( :firstName, :lastName, :email, :phoneNumber, :details, :contactOf);";
        $stmt = $this->conn->prepare($query);      
        
        $intContactOf = (int) $this->contactOf;

        $stmt->bindParam(':firstName', $this->firstName);
        $stmt->bindParam(':lastName', $this->lastName);
        $stmt->bindParam(':email', $this->email);
        $stmt->bindParam(':phoneNumber', $this->phoneNumber);
        $stmt->bindParam(':details', $this->details);
        $stmt->bindParam(':contactOf', $intContactOf);

        //make sure that the contactOf value is for an actual user and not the debug value
        if ($intContactOf == 0){
            return false;
        } else { //i know an else if would work here but it makes more sense to me to have it like this
            if ($stmt->execute()){
                return true;
            } else {
                return false;
            }
        }
    }

    function update(){
        $query = "UPDATE ".$this->table_name." SET
                    firstName = :firstName, lastName = :lastName, email =  :email, phoneNumber =  :phoneNumber, details = :details
                WHERE id = :id";
 
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':firstName', $this->firstName);
        $stmt->bindParam(':lastName', $this->lastName);
        $stmt->bindParam(':email', $this->email);
        $stmt->bindParam(':phoneNumber', $this->phoneNumber);
        $stmt->bindParam(':details', $this->details);
        $stmt->bindParam(':id', $this->id);
        if($stmt->execute()){
            return true;
        }
    
        return false;
    }

    function delete(){
        //this function was copy pasted directly from product.php without changes, i just don't know what 
        //to change
        
        // delete query
        $query = "DELETE FROM " . $this->table_name . " WHERE id = ?";
 
        // prepare query
        $stmt = $this->conn->prepare($query);
 
        // sanitize
        $this->id=htmlspecialchars(strip_tags($this->id));
 
        // bind id of record to delete
        $stmt->bindParam(1, $this->id);
 
        // execute query
        if($stmt->execute()){
            return true;
        }
 
        return false;
    }

    function search($keywords){ //still needs updating for contacts
        //this is going to need to be changed to work for contacts instead of products
        //that should only involve changing around the sql
        $query = "SELECT
        c.name as category_name, p.id, p.name, p.description, p.price, p.category_id, p.created
        FROM
        " . $this->table_name . " p
        LEFT JOIN
            categories c
                ON p.category_id = c.id
        WHERE
            p.name LIKE ? OR p.description LIKE ? OR c.name LIKE ?
        ORDER BY
            p.created DESC";

        // prepare query statement
        $stmt = $this->conn->prepare($query);

        // sanitize
        $keywords=htmlspecialchars(strip_tags($keywords));
        $keywords = "%{$keywords}%";

        // bind
        $stmt->bindParam(1, $keywords);
        $stmt->bindParam(2, $keywords);
        $stmt->bindParam(3, $keywords);

        // execute query
        $stmt->execute();

        return $stmt;
    }

    public function readPaging($from_rec_num, $recs_per_page){
        $query = "SELECT * FROM " . $this->table_name .
        " ORDER BY id ASC LIMIT " . $from_rec_num . ", " . $recs_per_page . "";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;       
    }

    public function count(){
        $query = "SELECT COUNT(*) as total_rows FROM " . $this->table_name . "";
 
        $stmt = $this->conn->prepare( $query );
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
 
        return $row['total_rows'];
    }
}
?>
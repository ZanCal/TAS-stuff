$(document).ready(function(){
    $(document).on('click', '.create-contact-button', function(){
        //console.log("add contact button clicked")
        //UserAccounts.getUserID();
        var html = `
        <!-- 'create contact' html form -->
        <form id='create-contact-form' action='#' method='post' border='0'>
            <table class='table table-hover table-responsive table-bordered'>
                <!-- first name field -->
                <tr>
                    <td>First Name</td>
                    <td><input type='text' name='firstName' class='form-control' required /></td>
                </tr>

                <!-- last name field -->
                <tr>
                    <td>Last Name</td>
                    <td><input type='text' name='lastName' class='form-control' required /></td>
                </tr>
                <!-- email field -->
                <tr>
                    <td>Email</td>
                    <td><input type='text' name='email' class='form-control' required /></td>
                </tr>
                <!-- phone number field -->
                <tr>
                    <td>Phone Number</td>
                    <td><input type='text' name='phoneNumber' class='form-control' required /></td>
                </tr>
                <!-- details field -->
                <tr>
                    <td>Details</td>
                    <td><input type='text' name='details' class='form-control' required /></td>
                </tr>
                <!-- button to submit form -->
                <tr>
                    <td>
                        <button type='cancel' class='btn btn-primary'>
                            <span class='glyphicon glyphicon-plus'></span> Cancel
                    </button>
                    </td>
                    <td>
                        <button type='submit' class='btn btn-primary'>
                            <span class='glyphicon glyphicon-plus'></span> Add Contact
                        </button>
                    </td>
                </tr>
            </table>
        </form>`;
        $("#content").html(html);

    });
    $(document).on('submit', '#create-contact-form', function(){ //how to do the different buttons 
        
        var form_data=JSON.stringify($(this).serializeObject());
        
        console.log("callback 1")
        contactOfInfo =  callBackFunction(UserAccounts.getUserID);
        setTimeout( function() {
            console.log("callback 4")
            var stringedcontactOf  =  JSON.stringify(contactOfInfo);
            console.log("stradd")
            console.log(stringedcontactOf)
            setTimeout( function(){
                var fullInfo = form_data.replace("}", ',' + stringedcontactOf.slice(1));
                console.log("fullInfo")
                console.log(fullInfo)
                // submit form data to api
                $.ajax({
                    url: "http://localhost/amalgam/api/contacts/createC.php",
                    type : "POST",
                    contentType : 'application/json',
                    data : fullInfo,
                    success : function(result) {
                        // product was created, go back to products list
                        //showProducts();//need to change to a different function that may not even be written yet
                        console.log(result)
                    },
                    error: function(result) {
                        // show error to console
                        console.log(result);
                    }
                })
            }, 1000)
        }, 1250 ); 
        
    return false;
    });
    
});


function callBackFunction(callback){
    var contactOfInfo = { contactOf: 0 }
    console.log("callback 2")
    contactOfInfo.contactOf = callback();
    setTimeout( function () {console.log("callback 3")}, 750)
    return contactOfInfo
}

//mostly copied from read-products.js, so that may cause errors for changed i needed to make and missed
$(document).ready(function(){
 
    // show list of product on first load
    showContactsFirstPage();
 
    // when a 'read products' button was clicked
    $(document).on('click', '.read-contacts-button', function(){
        showContactsFirstPage();
        console.log("read contacts button press");//this is probably redundant
    });
 
    // when a 'page' button was clicked
    $(document).on('click', '.contactPage li', function(){
        // get json url
        var json_url=$(this).find('a').attr('data-page');
        
        //updatedURL is used 'cuz not having the "/amalgam" part will cause a 404 
        var updatedURL = json_url.replace("/api/", "/amalgam/api/")
        // show list of contacts
        console.log(updatedURL)
        //ShowContacts(updatedURL);
        
        $.getJSON(updatedURL, function(data){
            readContactsTemplate(data, "");

        });
    });
 
 
});

function showContactsFirstPage(){
    var json_url="http://localhost/amalgam/api/contacts/read_pageC.php";
    showContacts(json_url);
}

function showContacts(json_url){
    // get list of products from the API
    $.getJSON(json_url, function(data){
        // html for listing products
        readContactsTemplate(data, "");
        //function is from products.js
    });
}

function readContactsTemplate(data, keywords){
    var html = "";
    html += HTMLGenerator.getContactsBase();
    $.each(data.records, function(key, val) {
        html += HTMLGenerator.addContactToTable(val);
    });
    html+=`</table>`;
    if(data.paging){ 
        html +=  HTMLGenerator.addContactPageList(data);
    }
    $("#content").html(html);
}
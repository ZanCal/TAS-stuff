$(document).ready(function(){
    $(document).on('click','.read-one-contact-button', function(){
        console.log("buttonclick")
        var id = $(this).attr('data-id');
        //console.log(id)
        
        $.getJSON("http://localhost/amalgam/api/contacts/read_oneC.php?id=" + id, function(data){

            var html=`
            <div id='read-contacts' class='btn btn-primary pull-right m-b-15px read-contacts-button'>
                <span class='glyphicon glyphicon-list'></span> Read Contacts
            </div>
            <table class='table table-bordered table-hover'>
                <tr>
                    <td class='w-30-pct'>First Name</td>
                    <td class='w-70-pct'>` + data.firstName + `</td>
                </tr>
                <tr>
                    <td class='w-30-pct'>Last Name</td>
                    <td class='w-70-pct'>` + data.lastName + `</td>
                </tr>
                <tr>
                    <td class='w-30-pct'>Email</td>
                    <td class='w-70-pct'>` + data.email + `</td>
                </tr>
                <tr>
                    <td class='w-30-pct'>Phone Number</td>
                    <td class='w-70-pct'>` + data.phoneNumber + `</td>
                </tr>
                <tr>
                    <td class='w-30-pct'>Details</td>
                    <td class='w-70-pct'>` + data.details + `</td>
                </tr>
            </table>`;
            // inject html to 'page-content' of our app
            $("#content").html(html);

        });
    });
});
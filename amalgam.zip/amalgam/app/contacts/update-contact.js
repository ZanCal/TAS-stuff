$(document).ready(function(){
    $(document).on('click', '.update-contact-button', function(){
        var id = $(this).attr('data-id'); 
        //this should look a lot like reading a single contact, but with a few extra bits
        $.getJSON("http://localhost/amalgam/api/contacts/read_oneC.php?id=" + id, function(data){
            var firstName = data.firstName;
            var lastName = data.lastName;
            var email = data.email;
            var phoneNumber = data.phoneNumber;
            var details = data.details;
            var html=`
                <div id='read-contacts' class='btn btn-primary pull-right m-b-15px cancel-contact-update-button'>
                    <span class='glyphicon glyphicon-list'></span> Discard Changes
                </div>
                <form id='update-contact-form' action='#' method='post' border='0'>
                    <table class='table table-bordered table-hover'>
                        <tr>
                            <td class='w-30-pct'>First Name</td>
                            <td>
                                <input value=\"` + firstName + `\" type='text' name='firstName' class='form-control' required />
                            </td>
                        </tr>
                        <tr>
                            <td class='w-30-pct'>Last Name</td>
                            <td>
                                <input value=\"` + lastName + `\" type='text' name='lastName' class='form-control' required />
                            </td>
                        </tr>
                        <tr>
                            <td class='w-30-pct'>Email</td>
                            <td>
                                <input value=\"` + email + `\" type='text' name='email' class='form-control' required />
                            </td>
                        </tr>
                        <tr>
                            <td class='w-30-pct'>Phone Number</td>
                            <td>
                                <input value=\"` + phoneNumber + `\" type='text' name='phoneNumber' class='form-control' required />
                            </td>
                        </tr>
                        <tr>
                            <td class='w-30-pct'>Details</td>
                            <td>
                                <input value=\"` + details + `\" type='text' name='details' class='form-control' required />
                            </td>
                        </tr>
                        <tr>
                            <!-- hidden 'product id' to identify which record to delete -->
                            <td><input value=\"` + id + `\" name='id' type='hidden' /></td>
                            <!-- button to submit form -->
                            <td>
                                <button type='submit' class='btn btn-info'>
                                    <span class='glyphicon glyphicon-edit'></span> Update Contact
                                </button>
                            </td>
                        </tr>
                    </table>
                </form>`;
            $("#content").html(html);
            $(document).on('submit', '#update-contact-form', function(){
                var form_data=JSON.stringify($(this).serializeObject());
                $.ajax({
                    url: "http://localhost/amalgam/api/contacts/updateC.php",
                    type : "POST",
                    contentType : 'application/json',
                    data : form_data,
                    success : function(result) {
                        console.log(result)
                    },
                    error: function(xhr, resp, text) {
                        console.log(xhr, resp, text);
                    }
                }); 
                return false;
            });
            $(document).on('click', '.cancel-contact-update-button', function(){
                console.log("discard")
                Viewer.showContactHomePage();
            });

        });

    });
});
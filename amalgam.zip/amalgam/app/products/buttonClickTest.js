class buttonClickTest{
//yea this is probably gonna not be used, but it might be a good idea to leave it around
//for the sake of testing stuff.
    static createProductButton() {
        console.log("create product button pressed")
    }

    static readOneProductButton(){
        console.log("read one product button pressed")
    }

    static readAllProductsButton(){
        console.log("read all products button pressed")
    }

    static updateProductButton(){
        console.log("update product button pressed")
    } 

    static deleteProductButton(){
        console.log("delete product button pressed")
    }

}
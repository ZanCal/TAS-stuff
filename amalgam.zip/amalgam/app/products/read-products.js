$(document).ready(function(){
 
    // show list of product on first load
    showProductsFirstPage();
 
    // when a 'read products' button was clicked
    $(document).on('click', '.read-products-button', function(){
        showProductsFirstPage();
        console.log("read products button press");
    });
 
    // when a 'page' button was clicked
    $(document).on('click', '.productPage li', function(){
        // get json url
        var json_url=$(this).find('a').attr('data-page');
        
        //updatedURL is used 'cuz not having the "/amalgam" part will cause a 404 
        var updatedURL = json_url.replace("/api/", "/amalgam/api/")
        console.log(updatedURL)
        // show list of products
        showProducts(updatedURL);
    });
 
 
});
 
function showProductsFirstPage(){
    var json_url="http://localhost/amalgam/api/product/read_paging.php";
    showProducts(json_url);
}
 
// function to show list of products
function showProducts(json_url){
    // get list of products from the API
    $.getJSON(json_url, function(data){
        // html for listing products
        readProductsTemplate(data, "");
        //function is from products.js
    });
}

function readProductsTemplate(data, keywords){
    var read_products_html = "";
    read_products_html += HTMLGenerator.getHomePageHTML();
    // loop through returned list of data
    $.each(data.records, function(key, val) {
        read_products_html += HTMLGenerator.addProductToTable(val);
    });
    // end table
    read_products_html+=`</table>`;
    // pagination
    if(data.paging){ 
        read_products_html +=  HTMLGenerator.addProductPageList(data);
    }
    // inject to 'page-content' of our app
    $("#content").html(read_products_html);
}

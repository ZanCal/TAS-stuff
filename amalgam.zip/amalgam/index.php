<!doctype html>
<html lang="en">
<!-- copy paste from token index.php, but i'm going to change around the part for the home tab-->
<!-- i want it to have all the products and stuff instead of the generic homepage info -->
<!-- and i'll move it to its own tab later, but i want it at home as a baseline first -->
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
 
        <title>OSMA</title>
 
        <!-- CSS links will be here -->
        <!-- Bootstrap 4 CSS and custom CSS -->
        <link rel="stylesheet" type="text/css" href="css/bootstrap-css-4.3.1/bootstrap.min.css" />
        <link rel="stylesheet" type="text/css" href="css/custom.css" />
 
    </head>
<body>
 
<!-- navigation bar will be here -->
<!-- navbar -->
<nav class="navbar navbar-expand-md navbar-dark bg-dark fixed-top">
    <a class="navbar-brand" href="#">Ogeemo Sales Manager</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
        <div class="navbar-nav">
            <a class="nav-item nav-link" href="#" id='home'>Home</a>
            <a class="nav-item nav-link" href="#" id='update_account'>Account</a>
            <a class="nav-item nav-link" href="#" id='logout'>Logout</a>
            <a class="nav-item nav-link" href="#" id='login'>Login</a>
            <a class="nav-item nav-link" href="#" id='sign_up'>Sign Up</a>
        </div>
    </div>
</nav>
<!-- /navbar -->

<!-- content section will be here -->
<!-- container -->
<main role="main" class="container starter-template">
 
    <div class="row">
        <div class="col">
 
            <!-- where prompt / messages will appear -->
            <div id="response"></div>
 
            <!-- where main content will appear -->
            <div id="content"></div>
        </div>
    </div>
 
</main>
<!-- /container -->
 
<!-- script links will be here -->


<!-- jQuery & Bootstrap 4 JavaScript libraries -->
<script src="js/jquery/jquery-3.4.1.js"></script>
<script src="js/popper-1.16.0-umd/popper.min.js"></script>
<script src="js/bootstrap-js-4.3.1/bootstrap.min.js"></script>

<!-- bootbox for popup things -->
<script src="app/assets/js/bootbox.min.js"></script>

<!-- jquery scripts will be here -->
<script src="js/htmlGenerator.js"></script>
<script src="js/userAccounts.js"></script>
<script src="js/sessions.js"></script>
<script src="js/viewer.js"></script>
<!-- this is the script i'm using to test my buttons, this is either going to be temporary -->
<!-- or replace the product scripts -->
<script src="app/products/buttonClickTest.js"></script>
 <!-- products scripts -->
<script src="app/products/products.js"></script>
<script src="app/products/search-products.js"></script>
<script src="app/products/read-products.js"></script>
<script src="app/products/create-product.js"></script>
<script src="app/products/read-one-product.js"></script>
<script src="app/products/update-product.js"></script>
<script src="app/products/delete-product.js"></script>
 
<script>
    // jQuery codes
    $(document).ready(function(){
        //other on click things are done here, probably where new ones should be done
        //these seem to completely redo the page, i only want to change a part of it
        //probably an easy way to accomidate for that. 
        //does this handle the initial loading of the page? and does that mean this is where i would
        //tinker with things to fix the problem of things not showing up until after a refresh

        // show sign up / registration form
        $(document).on('click', '#sign_up', function(){
            var html = HTMLGenerator.getSignUpFormHTML();
            Viewer.clearResponse();
            $('#content').html(html);
        });
     
        // trigger when registration form is submitted here
        $(document).on('submit', '#sign_up_form', function(){
            // get form data
            var sign_up_form=$(this);
            var form_data=JSON.stringify(sign_up_form.serializeObject());
            // submit form data to api
            UserAccounts.createUser(form_data,sign_up_form);
            return false;
        });
        // show login form
        $(document).on('click', '#login', function(){
            Viewer.showLoginPage();
        });
        
        // login form submit trigger will be here
        // trigger when login form is submitted
        $(document).on('submit', '#login_form', function(){
            // get form data
            var login_form=$(this);
            var form_data=JSON.stringify(login_form.serializeObject());
            // http request will be here
            // submit form data to api
            UserAccounts.login(form_data,login_form);
            return false;
        });

        // trigger to show home page will be here
        // show home page
        $(document).on('click', '#home', function(){
            Viewer.showHomePage();
            Viewer.clearResponse();
        });
        
        // trigger to show account form will be here
        // show update account form
        $(document).on('click', '#update_account', function(){
            Viewer.showUpdateAccountForm();
        });

        //let's just try this and see what happens
        //a syntax error, that's what happens
        //#(document).on('click','.read-one-product-button',function(){
        //    buttonClickTest.readOneProductButton();
        //});
        
        // trigger for updating user account will be here
        // trigger when 'update account' form is submitted
        $(document).on('submit', '#update_account_form', function(){
            // check if token expired here?
            // handle for update_account_form
            var update_account_form=$(this);
            // validate jwt to verify access
            var jwt = Sessions.getCookie('jwt');
            // get form data and jwt here
            // get form data
            var update_account_form_obj = update_account_form.serializeObject()
            // add jwt on the object
            update_account_form_obj.jwt = jwt;
            // convert object to json string
            var form_data=JSON.stringify(update_account_form_obj);
            // send data to api here
            // submit form data to api
            UserAccounts.updateUser(form_data);
            return false;
        });

        // trigger to logout will be here
        // logout the user
        $(document).on('click', '#logout', function(){
            // if the user is about to log out, then the expired nature of their token doesn't matter?
            Viewer.showLoginPage();
            $('#response').html("<div class='alert alert-info'>You are logged out.</div>");
        });
        
        // serializeObject will be here
        // function to make form values to json format
        $.fn.serializeObject = function(){
        
            var o = {};
            var a = this.serializeArray();
            $.each(a, function() {
                if (o[this.name] !== undefined) {
                    if (!o[this.name].push) {
                        o[this.name] = [o[this.name]];
                    }
                    o[this.name].push(this.value || '');
                } else {
                    o[this.name] = this.value || '';
                }
            });
            return o;
        };

        Viewer.showDefaultView();
    });
</script>

</body>
</html>
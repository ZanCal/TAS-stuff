class HTMLGenerator {
    static getSignUpFormHTML(){
        var html = `
                <h2>Sign Up</h2>
                <form id='sign_up_form'>
                    <div class="form-group">
                        <label for="firstname">Firstname</label>
                        <input type="text" class="form-control" name="firstname" id="firstname" required />
                    </div>
        
                    <div class="form-group">
                        <label for="lastname">Lastname</label>
                        <input type="text" class="form-control" name="lastname" id="lastname" required />
                    </div>
        
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" name="email" id="email" required />
                    </div>
        
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input maxlength="50" type="password" class="form-control" name="password" id="password" required />
                    </div>
        
                    <button type='submit' class='btn btn-primary'>Sign Up</button>
                </form>
                `;
        return html;
    }

    static getLoginFormHTML(){
        var html = `
                    <h2>Login</h2>
                    <form id='login_form'>
                        <div class='form-group'>
                            <label for='email'>Email address</label>
                            <input type='email' class='form-control' id='email' name='email' placeholder='Enter email'>
                        </div>

                        <div class='form-group'>
                            <label for='password'>Password</label>
                            <input type='password' class='form-control' id='password' name='password' placeholder='Password'>
                        </div>

                        <button type='submit' class='btn btn-primary'>Login</button>
                    </form>
                    `;
        return html;
    }

    static getUpdateAccountFormHTML(result){
        var html = `
                    <h2>Update Account</h2>
                    <form id='update_account_form'>
                        <div class="form-group">
                            <label for="firstname">Firstname</label>
                            <input type="text" class="form-control" name="firstname" id="firstname" required value="` + result.data.firstname + `" />
                        </div>
            
                        <div class="form-group">
                            <label for="lastname">Lastname</label>
                            <input type="text" class="form-control" name="lastname" id="lastname" required value="` + result.data.lastname + `" />
                        </div>
            
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" name="email" id="email" required value="` + result.data.email + `" />
                        </div>
            
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" class="form-control" name="password" id="password" />
                        </div>
            
                        <button type='submit' class='btn btn-primary'>
                            Save Changes
                        </button>
                    </form>
                `;
        return html;
    }

    static addProductToTable(product){
        var html =  `<tr>
        <td>`+ product.name + ` </td>
        <td>$`+ product.price + `</td>
        <td>`+product.category_name+`</td>
        <!-- 'action' buttons -->
            <td>
                <!-- read product button -->
                <button class='btn btn-primary m-r-10px read-one-product-button' data-id='`+product.id+`'>
                    <span class='glyphicon glyphicon-eye-open'></span> Read
                </button>
                <!-- edit button -->
                <button class='btn btn-info m-r-10px update-product-button' data-id='`+product.id+`'>
                    <span class='glyphicon glyphicon-edit'></span> Edit
                </button>
                <!-- delete button -->
                <button class='btn btn-danger delete-product-button' data-id='`+product.id+`'>
                    <span class='glyphicon glyphicon-remove'></span> Delete
                </button>
            </td>
        </tr>`;
        return html;
    }

    static addContactToTable(contact){
        //should be simmilar to addProductToTable(product)
        var html =  `<tr>
        <td>`+ contact.firstName + ` </td>
        <td>`+ contact.lastName + `</td>
        <td>`+ contact.email +`</td>
        <td>`+ contact.phoneNumber + `</td>
        <td>`+ contact.details + `</td>
        <!-- 'action' buttons -->
            <td>
                <!-- read product button -->
                <button class='btn btn-primary m-r-10px read-one-contact-button' data-id='`+contact.id+`'>
                    <span class='glyphicon glyphicon-eye-open'></span> Read
                </button>
                <!-- edit button -->
                <button class='btn btn-info m-r-10px update-contact-button' data-id='`+contact.id+`'>
                    <span class='glyphicon glyphicon-edit'></span> Edit
                </button>
                <!-- delete button -->
                <button class='btn btn-danger delete-contact-button' data-id='`+contact.id+`'>
                    <span class='glyphicon glyphicon-remove'></span> Delete
                </button>
            </td>
        </tr>`;
        return html;
    }

    static addProductPageList(data){
        var html = "";
        html+="<ul class='productPage pull-left margin-zero padding-bottom-2em'>";
        if(data.paging.first!=""){
            html+="<li><a data-page='" + data.paging.first + "'>First Page</a></li>";
        }
        $.each(data.paging.pages, function(key, val){
            var active_page=val.current_page=="yes" ? "class='active'" : "";
            html+="<li " + active_page + "><a data-page='" + val.url + "'>" + val.page + "</a></li>";
        });
        if(data.paging.last!=""){
            html+="<li><a data-page='" + data.paging.last + "'>Last Page</a></li>";
        }
        html+="</ul>";
        return html;

    }

    static addContactPageList(data){
        var html = "";
        html+="<ul class='contactPage pull-left margin-zero padding-bottom-2em'>";
        if(data.paging.first!=""){
            html+="<li><a data-page='" + data.paging.first + "'>First Page</a></li>";
        } 
        $.each(data.paging.pages, function(key, val){
            var active_page=val.current_page=="yes" ? "class='active'" : "";
            html+="<li " + active_page + "><a data-page='" + val.url + "'>" + val.page + "</a></li>";
        });
        if(data.paging.last!=""){
            html+="<li><a data-page='" + data.paging.last + "'>Last Page</a></li>";
        }
        html+="</ul>";
        return html;

    }

    static getHomePageHTML(){
        var html=`
        <!-- search products form -->
        <form id='search-product-form' action='#' method='post'>
        <div class='input-group pull-left w-30-pct'>
            <input type='text' value='' name='keywords' class='form-control product-search-keywords' placeholder='Search products...' />
            <span class='input-group-btn'>
                <button type='submit' class='btn btn-default' type='button'>
                    <span class='glyphicon glyphicon-search'></span>
                </button>
            </span>
        </div>
        </form>
            <div id='create-product' class='btn btn-primary pull-right m-b-15px create-product-button'>
                <span class='glyphicon glyphicon-plus'></span> Create Product
            </div>
            <!-- start table -->
            <table class='table table-bordered table-hover'> 
                <!-- creating our table heading -->
                <tr>
                    <th class='w-25-pct'>Name</th>
                    <th class='w-10-pct'>Price</th>
                    <th class='w-15-pct'>Category</th>
                    <th class='w-25-pct text-align-center'>Action</th>
                </tr>`;
        return html;
    }

    static getContactsBase(){
        var html=`
        <!-- search contacts form -->
        <form id='search-contact-form' action='#' method='post'>
        <div class='input-group pull-left w-30-pct'>
            <input type='text' value='' name='keywords' class='form-control product-search-keywords' placeholder='Search contacts...' />
            <span class='input-group-btn'>
                <button type='submit' class='btn btn-default' type='button'>
                    <span class='glyphicon glyphicon-search'></span>
                </button>
            </span>
        </div>
        </form>
        <div id='create-contact' class='btn btn-primary pull-right m-b-15px create-contact-button'>
            <span class='glyphicon glyphicon-plus'></span> Add Contact
        </div>
        <!-- start table -->
        <table class='table table-bordered table-hover'> 
            <!-- creating our table heading -->
            <tr>
                <th class='w-15-pct'>First Name</th>
                <th class='w-15-pct'>Last Name</th>
                <th class='w-15-pct'>Email</th>
                <th class='w-15-pct'>Phone Number</th>
                <th class='w-15-pct'>Details</th>
                <th class='w-25-pct text-align-center'>Action</th>
            </tr>`;
        return html;

    }
    

    //what was i thinking of doing with these?
    static readOneProduct(product){
        var html = `<p>this is not a message that should appear</p>`;
        return html;
    }
    static createProduct(){
        var html = '<p>this is not a message that should appear</p>';
        return html;
    }
    static updateProduct(product){
        var html = '<p>this is not a message that should appear</p>';
        return html;
    }
}
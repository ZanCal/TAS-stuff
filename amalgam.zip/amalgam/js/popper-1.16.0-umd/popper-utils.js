<!DOCTYPE html><html lang="en"><head><script async="" src="https://www.googletagmanager.com/gtag/js?id=UA-140352188-1"></script><script>window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());
gtag('config', 'UA-140352188-1');</script><meta charSet="utf-8"/><meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/><meta name="description" content="The CDN for popper.js"/><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1"/><meta name="timestamp" content="2019-12-09T05:22:14.114Z"/><link rel="shortcut icon" href="/favicon.ico"/><title>UNPKG - popper.js</title><script>window.Promise || document.write('\x3Cscript src="/es6-promise@4.2.5/dist/es6-promise.min.js">\x3C/script>\x3Cscript>ES6Promise.polyfill()\x3C/script>')</script><script>window.fetch || document.write('\x3Cscript src="/whatwg-fetch@3.0.0/dist/fetch.umd.js">\x3C/script>')</script><script>window.__DATA__ = {"packageName":"popper.js","packageVersion":"1.16.0","availableVersions":["0.2.0","0.2.1","0.2.2","0.2.3","0.2.4","0.2.5","0.2.6","0.3.0","0.3.1","0.3.2","0.3.3","0.3.4","0.3.5","0.3.6","0.3.7","0.3.8","0.4.0","0.4.1","0.4.2","0.5.0","0.5.1","0.5.2","0.5.3","0.6.0","0.6.1","0.6.2","0.6.3","0.6.4","1.0.0-alpha.1","1.0.0-alpha.2","1.0.0-alpha.3","1.0.0-alpha.4","1.0.0-alpha.5","1.0.0-alpha.6","1.0.0-alpha.7","1.0.0-alpha.8","1.0.0-beta.1","1.0.0-beta.2","1.0.0-beta.3","1.0.0-beta.4","1.0.0-beta.5","1.0.0","1.0.1","1.0.2","1.0.3","1.0.4","1.0.5","1.0.6","1.0.7","1.0.8","1.5.0","1.5.1-pre","1.5.1-pre.2","1.5.1","1.5.2","1.6.0","1.7.0","1.8.0","1.8.1","1.8.2","1.8.3","1.8.4","1.8.5","1.8.6","1.9.0","1.9.1","1.9.2","1.9.3","1.9.4","1.9.5","1.9.6","1.9.7","1.9.8","1.9.9","1.10.0","1.10.1","1.10.2","1.10.3","1.10.4","1.10.5","1.10.6","1.10.7","1.10.8","1.11.0","1.11.1","1.12.0","1.12.1","1.12.2","1.12.3","1.12.4","1.12.5","1.12.6","1.12.7","1.12.8","1.12.9","1.13.0-next","1.13.0-next.1","1.13.0","1.14.0","1.14.1","1.14.2","1.14.3","1.14.4","1.14.5","1.14.6","1.14.7","1.15.0","1.16.0","2.0.0-next.1","2.0.0-next.2","2.0.0-next.3","2.0.0-next.4"],"filename":"/dist/umd/popper-utils.js","target":{"path":"/dist/umd/popper-utils.js","type":"file","details":{"contentType":"application/javascript","integrity":"sha384-I/m0wZRCtGf3N2XFAJ9rWej5MX5JbdgJtvGFVCrWjmXf8OoYBZd+uIcbOf+SWD0K","language":"JavaScript","size":36692,"uri":null,"highlights":["<span class=\"code-comment\">/**!\n</span>","<span class=\"code-comment\"> * @fileOverview Kickass library to create and place poppers near their reference elements.\n</span>","<span class=\"code-comment\"> * @version 1.16.0\n</span>","<span class=\"code-comment\"> * @license\n</span>","<span class=\"code-comment\"> * Copyright (c) 2016 Federico Zivolo and contributors\n</span>","<span class=\"code-comment\"> *\n</span>","<span class=\"code-comment\"> * Permission is hereby granted, free of charge, to any person obtaining a copy\n</span>","<span class=\"code-comment\"> * of this software and associated documentation files (the \"Software\"), to deal\n</span>","<span class=\"code-comment\"> * in the Software without restriction, including without limitation the rights\n</span>","<span class=\"code-comment\"> * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell\n</span>","<span class=\"code-comment\"> * copies of the Software, and to permit persons to whom the Software is\n</span>","<span class=\"code-comment\"> * furnished to do so, subject to the following conditions:\n</span>","<span class=\"code-comment\"> *\n</span>","<span class=\"code-comment\"> * The above copyright notice and this permission notice shall be included in all\n</span>","<span class=\"code-comment\"> * copies or substantial portions of the Software.\n</span>","<span class=\"code-comment\"> *\n</span>","<span class=\"code-comment\"> * THE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR\n</span>","<span class=\"code-comment\"> * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,\n</span>","<span class=\"code-comment\"> * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE\n</span>","<span class=\"code-comment\"> * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER\n</span>","<span class=\"code-comment\"> * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,\n</span>","<span class=\"code-comment\"> * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE\n</span>","<span class=\"code-comment\"> * SOFTWARE.\n</span>","<span class=\"code-comment\"> */</span>\n","(<span class=\"code-function\"><span class=\"code-keyword\">function</span> (<span class=\"code-params\">global, factory</span>) </span>{\n","\t<span class=\"code-keyword\">typeof</span> exports === <span class=\"code-string\">'object'</span> &amp;&amp; <span class=\"code-keyword\">typeof</span> <span class=\"code-built_in\">module</span> !== <span class=\"code-string\">'undefined'</span> ? factory(exports) :\n","\t<span class=\"code-keyword\">typeof</span> define === <span class=\"code-string\">'function'</span> &amp;&amp; define.amd ? define([<span class=\"code-string\">'exports'</span>], factory) :\n","\t(factory((global.PopperUtils = {})));\n","}(<span class=\"code-keyword\">this</span>, (<span class=\"code-function\"><span class=\"code-keyword\">function</span> (<span class=\"code-params\">exports</span>) </span>{ <span class=\"code-string\">'use strict'</span>;\n","\n","<span class=\"code-comment\">/**\n</span>","<span class=\"code-comment\"> * Get CSS computed property of the given element\n</span>","<span class=\"code-comment\"> * @method\n</span>","<span class=\"code-comment\"> * @memberof Popper.Utils\n</span>","<span class=\"code-comment\"> * @argument {Eement} element\n</span>","<span class=\"code-comment\"> * @argument {String} property\n</span>","<span class=\"code-comment\"> */</span>\n","<span class=\"code-function\"><span class=\"code-keyword\">function</span> <span class=\"code-title\">getStyleComputedProperty</span>(<span class=\"code-params\">element, property</span>) </span>{\n","  <span class=\"code-keyword\">if</span> (element.nodeType !== <span class=\"code-number\">1</span>) {\n","    <span class=\"code-keyword\">return</span> [];\n","  }\n","  <span class=\"code-comment\">// <span class=\"code-doctag\">NOTE:</span> 1 DOM access here</span>\n","  <span class=\"code-keyword\">var</span> <span class=\"code-built_in\">window</span> = element.ownerDocument.defaultView;\n","  <span class=\"code-keyword\">var</span> css = <span class=\"code-built_in\">window</span>.getComputedStyle(element, <span class=\"code-literal\">null</span>);\n","  <span class=\"code-keyword\">return</span> property ? css[property] : css;\n","}\n","\n","<span class=\"code-comment\">/**\n</span>","<span class=\"code-comment\"> * Returns the parentNode or the host of the element\n</span>","<span class=\"code-comment\"> * @method\n</span>","<span class=\"code-comment\"> * @memberof Popper.Utils\n</span>","<span class=\"code-comment\"> * @argument {Element} element\n</span>","<span class=\"code-comment\"> * @returns {Element} parent\n</span>","<span class=\"code-comment\"> */</span>\n","<span class=\"code-function\"><span class=\"code-keyword\">function</span> <span class=\"code-title\">getParentNode</span>(<span class=\"code-params\">element</span>) </span>{\n","  <span class=\"code-keyword\">if</span> (element.nodeName === <span class=\"code-string\">'HTML'</span>) {\n","    <span class=\"code-keyword\">return</span> element;\n","  }\n","  <span class=\"code-keyword\">return</span> element.parentNode || element.host;\n","}\n","\n","<span class=\"code-comment\">/**\n</span>","<span class=\"code-comment\"> * Returns the scrolling parent of the given element\n</span>","<span class=\"code-comment\"> * @method\n</span>","<span class=\"code-comment\"> * @memberof Popper.Utils\n</span>","<span class=\"code-comment\"> * @argument {Element} element\n</span>","<span class=\"code-comment\"> * @returns {Element} scroll parent\n</span>","<span class=\"code-comment\"> */</span>\n","<span class=\"code-function\"><span class=\"code-keyword\">function</span> <span class=\"code-title\">getScrollParent</span>(<span class=\"code-params\">element</span>) </span>{\n","  <span class=\"code-comment\">// Return body, `getScroll` will take care to get the correct `scrollTop` from it</span>\n","  <span class=\"code-keyword\">if</span> (!element) {\n","    <span class=\"code-keyword\">return</span> <span class=\"code-built_in\">document</span>.body;\n","  }\n","\n","  <span class=\"code-keyword\">switch</span> (element.nodeName) {\n","    <span class=\"code-keyword\">case</span> <span class=\"code-string\">'HTML'</span>:\n","    <span class=\"code-keyword\">case</span> <span class=\"code-string\">'BODY'</span>:\n","      <span class=\"code-keyword\">return</span> element.ownerDocument.body;\n","    <span class=\"code-keyword\">case</span> <span class=\"code-string\">'#document'</span>:\n","      <span class=\"code-keyword\">return</span> element.body;\n","  }\n","\n","  <span class=\"code-comment\">// Firefox want us to check `-x` and `-y` variations as well</span>\n","\n","  <span class=\"code-keyword\">var</span> _getStyleComputedProp = getStyleComputedProperty(element),\n","      overflow = _getStyleComputedProp.overflow,\n","      overflowX = _getStyleComputedProp.overflowX,\n","      overflowY = _getStyleComputedProp.overflowY;\n","\n","  <span class=\"code-keyword\">if</span> (<span class=\"code-regexp\">/(auto|scroll|overlay)/</span>.test(overflow + overflowY + overflowX)) {\n","    <span class=\"code-keyword\">return</span> element;\n","  }\n","\n","  <span class=\"code-keyword\">return</span> getScrollParent(getParentNode(element));\n","}\n","\n","<span class=\"code-comment\">/**\n</span>","<span class=\"code-comment\"> * Returns the reference node of the reference object, or the reference object itself.\n</span>","<span class=\"code-comment\"> * @method\n</span>","<span class=\"code-comment\"> * @memberof Popper.Utils\n</span>","<span class=\"code-comment\"> * @param {Element|Object} reference - the reference element (the popper will be relative to this)\n</span>","<span class=\"code-comment\"> * @returns {Element} parent\n</span>","<span class=\"code-comment\"> */</span>\n","<span class=\"code-function\"><span class=\"code-keyword\">function</span> <span class=\"code-title\">getReferenceNode</span>(<span class=\"code-params\">reference</span>) </span>{\n","  <span class=\"code-keyword\">return</span> reference &amp;&amp; reference.referenceNode ? reference.referenceNode : reference;\n","}\n","\n","<span class=\"code-keyword\">var</span> isBrowser = <span class=\"code-keyword\">typeof</span> <span class=\"code-built_in\">window</span> !== <span class=\"code-string\">'undefined'</span> &amp;&amp; <span class=\"code-keyword\">typeof</span> <span class=\"code-built_in\">document</span> !== <span class=\"code-string\">'undefined'</span> &amp;&amp; <span class=\"code-keyword\">typeof</span> navigator !== <span class=\"code-string\">'undefined'</span>;\n","\n","<span class=\"code-keyword\">var</span> isIE11 = isBrowser &amp;&amp; !!(<span class=\"code-built_in\">window</span>.MSInputMethodContext &amp;&amp; <span class=\"code-built_in\">document</span>.documentMode);\n","<span class=\"code-keyword\">var</span> isIE10 = isBrowser &amp;&amp; <span class=\"code-regexp\">/MSIE 10/</span>.test(navigator.userAgent);\n","\n","<span class=\"code-comment\">/**\n</span>","<span class=\"code-comment\"> * Determines if the browser is Internet Explorer\n</span>","<span class=\"code-comment\"> * @method\n</span>","<span class=\"code-comment\"> * @memberof Popper.Utils\n</span>","<span class=\"code-comment\"> * @param {Number} version to check\n</span>","<span class=\"code-comment\"> * @returns {Boolean} isIE\n</span>","<span class=\"code-comment\"> */</span>\n","<span class=\"code-function\"><span class=\"code-keyword\">function</span> <span class=\"code-title\">isIE</span>(<span class=\"code-params\">version</span>) </span>{\n","  <span class=\"code-keyword\">if</span> (version === <span class=\"code-number\">11</span>) {\n","    <span class=\"code-keyword\">return</span> isIE11;\n","  }\n","  <span class=\"code-keyword\">if</span> (version === <span class=\"code-number\">10</span>) {\n","    <span class=\"code-keyword\">return</span> isIE10;\n","  }\n","  <span class=\"code-keyword\">return</span> isIE11 || isIE10;\n","}\n","\n","<span class=\"code-comment\">/**\n</span>","<span class=\"code-comment\"> * Returns the offset parent of the given element\n</span>","<span class=\"code-comment\"> * @method\n</span>","<span class=\"code-comment\"> * @memberof Popper.Utils\n</span>","<span class=\"code-comment\"> * @argument {Element} element\n</span>","<span class=\"code-comment\"> * @returns {Element} offset parent\n</span>","<span class=\"code-comment\"> */</span>\n","<span class=\"code-function\"><span class=\"code-keyword\">function</span> <span class=\"code-title\">getOffsetParent</span>(<span class=\"code-params\">element</span>) </span>{\n","  <span class=\"code-keyword\">if</span> (!element) {\n","    <span class=\"code-keyword\">return</span> <span class=\"code-built_in\">document</span>.documentElement;\n","  }\n","\n","  <span class=\"code-keyword\">var</span> noOffsetParent = isIE(<span class=\"code-number\">10</span>) ? <span class=\"code-built_in\">document</span>.body : <span class=\"code-literal\">null</span>;\n","\n","  <span class=\"code-comment\">// <span class=\"code-doctag\">NOTE:</span> 1 DOM access here</span>\n","  <span class=\"code-keyword\">var</span> offsetParent = element.offsetParent || <span class=\"code-literal\">null</span>;\n","  <span class=\"code-comment\">// Skip hidden elements which don't have an offsetParent</span>\n","  <span class=\"code-keyword\">while</span> (offsetParent === noOffsetParent &amp;&amp; element.nextElementSibling) {\n","    offsetParent = (element = element.nextElementSibling).offsetParent;\n","  }\n","\n","  <span class=\"code-keyword\">var</span> nodeName = offsetParent &amp;&amp; offsetParent.nodeName;\n","\n","  <span class=\"code-keyword\">if</span> (!nodeName || nodeName === <span class=\"code-string\">'BODY'</span> || nodeName === <span class=\"code-string\">'HTML'</span>) {\n","    <span class=\"code-keyword\">return</span> element ? element.ownerDocument.documentElement : <span class=\"code-built_in\">document</span>.documentElement;\n","  }\n","\n","  <span class=\"code-comment\">// .offsetParent will return the closest TH, TD or TABLE in case</span>\n","  <span class=\"code-comment\">// no offsetParent is present, I hate this job...</span>\n","  <span class=\"code-keyword\">if</span> ([<span class=\"code-string\">'TH'</span>, <span class=\"code-string\">'TD'</span>, <span class=\"code-string\">'TABLE'</span>].indexOf(offsetParent.nodeName) !== <span class=\"code-number\">-1</span> &amp;&amp; getStyleComputedProperty(offsetParent, <span class=\"code-string\">'position'</span>) === <span class=\"code-string\">'static'</span>) {\n","    <span class=\"code-keyword\">return</span> getOffsetParent(offsetParent);\n","  }\n","\n","  <span class=\"code-keyword\">return</span> offsetParent;\n","}\n","\n","<span class=\"code-function\"><span class=\"code-keyword\">function</span> <span class=\"code-title\">isOffsetContainer</span>(<span class=\"code-params\">element</span>) </span>{\n","  <span class=\"code-keyword\">var</span> nodeName = element.nodeName;\n","\n","  <span class=\"code-keyword\">if</span> (nodeName === <span class=\"code-string\">'BODY'</span>) {\n","    <span class=\"code-keyword\">return</span> <span class=\"code-literal\">false</span>;\n","  }\n","  <span class=\"code-keyword\">return</span> nodeName === <span class=\"code-string\">'HTML'</span> || getOffsetParent(element.firstElementChild) === element;\n","}\n","\n","<span class=\"code-comment\">/**\n</span>","<span class=\"code-comment\"> * Finds the root node (document, shadowDOM root) of the given element\n</span>","<span class=\"code-comment\"> * @method\n</span>","<span class=\"code-comment\"> * @memberof Popper.Utils\n</span>","<span class=\"code-comment\"> * @argument {Element} node\n</span>","<span class=\"code-comment\"> * @returns {Element} root node\n</span>","<span class=\"code-comment\"> */</span>\n","<span class=\"code-function\"><span class=\"code-keyword\">function</span> <span class=\"code-title\">getRoot</span>(<span class=\"code-params\">node</span>) </span>{\n","  <span class=\"code-keyword\">if</span> (node.parentNode !== <span class=\"code-literal\">null</span>) {\n","    <span class=\"code-keyword\">return</span> getRoot(node.parentNode);\n","  }\n","\n","  <span class=\"code-keyword\">return</span> node;\n","}\n","\n","<span class=\"code-comment\">/**\n</span>","<span class=\"code-comment\"> * Finds the offset parent common to the two provided nodes\n</span>","<span class=\"code-comment\"> * @method\n</span>","<span class=\"code-comment\"> * @memberof Popper.Utils\n</span>","<span class=\"code-comment\"> * @argument {Element} element1\n</span>","<span class=\"code-comment\"> * @argument {Element} element2\n</span>","<span class=\"code-comment\"> * @returns {Element} common offset parent\n</span>","<span class=\"code-comment\"> */</span>\n","<span class=\"code-function\"><span class=\"code-keyword\">function</span> <span class=\"code-title\">findCommonOffsetParent</span>(<span class=\"code-params\">element1, element2</span>) </span>{\n","  <span class=\"code-comment\">// This check is needed to avoid errors in case one of the elements isn't defined for any reason</span>\n","  <span class=\"code-keyword\">if</span> (!element1 || !element1.nodeType || !element2 || !element2.nodeType) {\n","    <span class=\"code-keyword\">return</span> <span class=\"code-built_in\">document</span>.documentElement;\n","  }\n","\n","  <span class=\"code-comment\">// Here we make sure to give as \"start\" the element that comes first in the DOM</span>\n","  <span class=\"code-keyword\">var</span> order = element1.compareDocumentPosition(element2) &amp; Node.DOCUMENT_POSITION_FOLLOWING;\n","  <span class=\"code-keyword\">var</span> start = order ? element1 : element2;\n","  <span class=\"code-keyword\">var</span> end = order ? element2 : element1;\n","\n","  <span class=\"code-comment\">// Get common ancestor container</span>\n","  <span class=\"code-keyword\">var</span> range = <span class=\"code-built_in\">document</span>.createRange();\n","  range.setStart(start, <span class=\"code-number\">0</span>);\n","  range.setEnd(end, <span class=\"code-number\">0</span>);\n","  <span class=\"code-keyword\">var</span> commonAncestorContainer = range.commonAncestorContainer;\n","\n","  <span class=\"code-comment\">// Both nodes are inside #document</span>\n","\n","  <span class=\"code-keyword\">if</span> (element1 !== commonAncestorContainer &amp;&amp; element2 !== commonAncestorContainer || start.contains(end)) {\n","    <span class=\"code-keyword\">if</span> (isOffsetContainer(commonAncestorContainer)) {\n","      <span class=\"code-keyword\">return</span> commonAncestorContainer;\n","    }\n","\n","    <span class=\"code-keyword\">return</span> getOffsetParent(commonAncestorContainer);\n","  }\n","\n","  <span class=\"code-comment\">// one of the nodes is inside shadowDOM, find which one</span>\n","  <span class=\"code-keyword\">var</span> element1root = getRoot(element1);\n","  <span class=\"code-keyword\">if</span> (element1root.host) {\n","    <span class=\"code-keyword\">return</span> findCommonOffsetParent(element1root.host, element2);\n","  } <span class=\"code-keyword\">else</span> {\n","    <span class=\"code-keyword\">return</span> findCommonOffsetParent(element1, getRoot(element2).host);\n","  }\n","}\n","\n","<span class=\"code-comment\">/**\n</span>","<span class=\"code-comment\"> * Gets the scroll value of the given element in the given side (top and left)\n</span>","<span class=\"code-comment\"> * @method\n</span>","<span class=\"code-comment\"> * @memberof Popper.Utils\n</span>","<span class=\"code-comment\"> * @argument {Element} element\n</span>","<span class=\"code-comment\"> * @argument {String} side `top` or `left`\n</span>","<span class=\"code-comment\"> * @returns {number} amount of scrolled pixels\n</span>","<span class=\"code-comment\"> */</span>\n","<span class=\"code-function\"><span class=\"code-keyword\">function</span> <span class=\"code-title\">getScroll</span>(<span class=\"code-params\">element</span>) </span>{\n","  <span class=\"code-keyword\">var</span> side = <span class=\"code-built_in\">arguments</span>.length &gt; <span class=\"code-number\">1</span> &amp;&amp; <span class=\"code-built_in\">arguments</span>[<span class=\"code-number\">1</span>] !== <span class=\"code-literal\">undefined</span> ? <span class=\"code-built_in\">arguments</span>[<span class=\"code-number\">1</span>] : <span class=\"code-string\">'top'</span>;\n","\n","  <span class=\"code-keyword\">var</span> upperSide = side === <span class=\"code-string\">'top'</span> ? <span class=\"code-string\">'scrollTop'</span> : <span class=\"code-string\">'scrollLeft'</span>;\n","  <span class=\"code-keyword\">var</span> nodeName = element.nodeName;\n","\n","  <span class=\"code-keyword\">if</span> (nodeName === <span class=\"code-string\">'BODY'</span> || nodeName === <span class=\"code-string\">'HTML'</span>) {\n","    <span class=\"code-keyword\">var</span> html = element.ownerDocument.documentElement;\n","    <span class=\"code-keyword\">var</span> scrollingElement = element.ownerDocument.scrollingElement || html;\n","    <span class=\"code-keyword\">return</span> scrollingElement[upperSide];\n","  }\n","\n","  <span class=\"code-keyword\">return</span> element[upperSide];\n","}\n","\n","<span class=\"code-comment\">/*\n</span>","<span class=\"code-comment\"> * Sum or subtract the element scroll values (left and top) from a given rect object\n</span>","<span class=\"code-comment\"> * @method\n</span>","<span class=\"code-comment\"> * @memberof Popper.Utils\n</span>","<span class=\"code-comment\"> * @param {Object} rect - Rect object you want to change\n</span>","<span class=\"code-comment\"> * @param {HTMLElement} element - The element from the function reads the scroll values\n</span>","<span class=\"code-comment\"> * @param {Boolean} subtract - set to true if you want to subtract the scroll values\n</span>","<span class=\"code-comment\"> * @return {Object} rect - The modifier rect object\n</span>","<span class=\"code-comment\"> */</span>\n","<span class=\"code-function\"><span class=\"code-keyword\">function</span> <span class=\"code-title\">includeScroll</span>(<span class=\"code-params\">rect, element</span>) </span>{\n","  <span class=\"code-keyword\">var</span> subtract = <span class=\"code-built_in\">arguments</span>.length &gt; <span class=\"code-number\">2</span> &amp;&amp; <span class=\"code-built_in\">arguments</span>[<span class=\"code-number\">2</span>] !== <span class=\"code-literal\">undefined</span> ? <span class=\"code-built_in\">arguments</span>[<span class=\"code-number\">2</span>] : <span class=\"code-literal\">false</span>;\n","\n","  <span class=\"code-keyword\">var</span> scrollTop = getScroll(element, <span class=\"code-string\">'top'</span>);\n","  <span class=\"code-keyword\">var</span> scrollLeft = getScroll(element, <span class=\"code-string\">'left'</span>);\n","  <span class=\"code-keyword\">var</span> modifier = subtract ? <span class=\"code-number\">-1</span> : <span class=\"code-number\">1</span>;\n","  rect.top += scrollTop * modifier;\n","  rect.bottom += scrollTop * modifier;\n","  rect.left += scrollLeft * modifier;\n","  rect.right += scrollLeft * modifier;\n","  <span class=\"code-keyword\">return</span> rect;\n","}\n","\n","<span class=\"code-comment\">/*\n</span>","<span class=\"code-comment\"> * Helper to detect borders of a given element\n</span>","<span class=\"code-comment\"> * @method\n</span>","<span class=\"code-comment\"> * @memberof Popper.Utils\n</span>","<span class=\"code-comment\"> * @param {CSSStyleDeclaration} styles\n</span>","<span class=\"code-comment\"> * Result of `getStyleComputedProperty` on the given element\n</span>","<span class=\"code-comment\"> * @param {String} axis - `x` or `y`\n</span>","<span class=\"code-comment\"> * @return {number} borders - The borders size of the given axis\n</span>","<span class=\"code-comment\"> */</span>\n","\n","<span class=\"code-function\"><span class=\"code-keyword\">function</span> <span class=\"code-title\">getBordersSize</span>(<span class=\"code-params\">styles, axis</span>) </span>{\n","  <span class=\"code-keyword\">var</span> sideA = axis === <span class=\"code-string\">'x'</span> ? <span class=\"code-string\">'Left'</span> : <span class=\"code-string\">'Top'</span>;\n","  <span class=\"code-keyword\">var</span> sideB = sideA === <span class=\"code-string\">'Left'</span> ? <span class=\"code-string\">'Right'</span> : <span class=\"code-string\">'Bottom'</span>;\n","\n","  <span class=\"code-keyword\">return</span> <span class=\"code-built_in\">parseFloat</span>(styles[<span class=\"code-string\">'border'</span> + sideA + <span class=\"code-string\">'Width'</span>], <span class=\"code-number\">10</span>) + <span class=\"code-built_in\">parseFloat</span>(styles[<span class=\"code-string\">'border'</span> + sideB + <span class=\"code-string\">'Width'</span>], <span class=\"code-number\">10</span>);\n","}\n","\n","<span class=\"code-function\"><span class=\"code-keyword\">function</span> <span class=\"code-title\">getSize</span>(<span class=\"code-params\">axis, body, html, computedStyle</span>) </span>{\n","  <span class=\"code-keyword\">return</span> <span class=\"code-built_in\">Math</span>.max(body[<span class=\"code-string\">'offset'</span> + axis], body[<span class=\"code-string\">'scroll'</span> + axis], html[<span class=\"code-string\">'client'</span> + axis], html[<span class=\"code-string\">'offset'</span> + axis], html[<span class=\"code-string\">'scroll'</span> + axis], isIE(<span class=\"code-number\">10</span>) ? <span class=\"code-built_in\">parseInt</span>(html[<span class=\"code-string\">'offset'</span> + axis]) + <span class=\"code-built_in\">parseInt</span>(computedStyle[<span class=\"code-string\">'margin'</span> + (axis === <span class=\"code-string\">'Height'</span> ? <span class=\"code-string\">'Top'</span> : <span class=\"code-string\">'Left'</span>)]) + <span class=\"code-built_in\">parseInt</span>(computedStyle[<span class=\"code-string\">'margin'</span> + (axis === <span class=\"code-string\">'Height'</span> ? <span class=\"code-string\">'Bottom'</span> : <span class=\"code-string\">'Right'</span>)]) : <span class=\"code-number\">0</span>);\n","}\n","\n","<span class=\"code-function\"><span class=\"code-keyword\">function</span> <span class=\"code-title\">getWindowSizes</span>(<span class=\"code-params\">document</span>) </span>{\n","  <span class=\"code-keyword\">var</span> body = <span class=\"code-built_in\">document</span>.body;\n","  <span class=\"code-keyword\">var</span> html = <span class=\"code-built_in\">document</span>.documentElement;\n","  <span class=\"code-keyword\">var</span> computedStyle = isIE(<span class=\"code-number\">10</span>) &amp;&amp; getComputedStyle(html);\n","\n","  <span class=\"code-keyword\">return</span> {\n","    height: getSize(<span class=\"code-string\">'Height'</span>, body, html, computedStyle),\n","    width: getSize(<span class=\"code-string\">'Width'</span>, body, html, computedStyle)\n","  };\n","}\n","\n","<span class=\"code-keyword\">var</span> _extends = <span class=\"code-built_in\">Object</span>.assign || <span class=\"code-function\"><span class=\"code-keyword\">function</span> (<span class=\"code-params\">target</span>) </span>{\n","  <span class=\"code-keyword\">for</span> (<span class=\"code-keyword\">var</span> i = <span class=\"code-number\">1</span>; i &lt; <span class=\"code-built_in\">arguments</span>.length; i++) {\n","    <span class=\"code-keyword\">var</span> source = <span class=\"code-built_in\">arguments</span>[i];\n","\n","    <span class=\"code-keyword\">for</span> (<span class=\"code-keyword\">var</span> key <span class=\"code-keyword\">in</span> source) {\n","      <span class=\"code-keyword\">if</span> (<span class=\"code-built_in\">Object</span>.prototype.hasOwnProperty.call(source, key)) {\n","        target[key] = source[key];\n","      }\n","    }\n","  }\n","\n","  <span class=\"code-keyword\">return</span> target;\n","};\n","\n","<span class=\"code-comment\">/**\n</span>","<span class=\"code-comment\"> * Given element offsets, generate an output similar to getBoundingClientRect\n</span>","<span class=\"code-comment\"> * @method\n</span>","<span class=\"code-comment\"> * @memberof Popper.Utils\n</span>","<span class=\"code-comment\"> * @argument {Object} offsets\n</span>","<span class=\"code-comment\"> * @returns {Object} ClientRect like output\n</span>","<span class=\"code-comment\"> */</span>\n","<span class=\"code-function\"><span class=\"code-keyword\">function</span> <span class=\"code-title\">getClientRect</span>(<span class=\"code-params\">offsets</span>) </span>{\n","  <span class=\"code-keyword\">return</span> _extends({}, offsets, {\n","    right: offsets.left + offsets.width,\n","    bottom: offsets.top + offsets.height\n","  });\n","}\n","\n","<span class=\"code-comment\">/**\n</span>","<span class=\"code-comment\"> * Get bounding client rect of given element\n</span>","<span class=\"code-comment\"> * @method\n</span>","<span class=\"code-comment\"> * @memberof Popper.Utils\n</span>","<span class=\"code-comment\"> * @param {HTMLElement} element\n</span>","<span class=\"code-comment\"> * @return {Object} client rect\n</span>","<span class=\"code-comment\"> */</span>\n","<span class=\"code-function\"><span class=\"code-keyword\">function</span> <span class=\"code-title\">getBoundingClientRect</span>(<span class=\"code-params\">element</span>) </span>{\n","  <span class=\"code-keyword\">var</span> rect = {};\n","\n","  <span class=\"code-comment\">// IE10 10 FIX: Please, don't ask, the element isn't</span>\n","  <span class=\"code-comment\">// considered in DOM in some circumstances...</span>\n","  <span class=\"code-comment\">// This isn't reproducible in IE10 compatibility mode of IE11</span>\n","  <span class=\"code-keyword\">try</span> {\n","    <span class=\"code-keyword\">if</span> (isIE(<span class=\"code-number\">10</span>)) {\n","      rect = element.getBoundingClientRect();\n","      <span class=\"code-keyword\">var</span> scrollTop = getScroll(element, <span class=\"code-string\">'top'</span>);\n","      <span class=\"code-keyword\">var</span> scrollLeft = getScroll(element, <span class=\"code-string\">'left'</span>);\n","      rect.top += scrollTop;\n","      rect.left += scrollLeft;\n","      rect.bottom += scrollTop;\n","      rect.right += scrollLeft;\n","    } <span class=\"code-keyword\">else</span> {\n","      rect = element.getBoundingClientRect();\n","    }\n","  } <span class=\"code-keyword\">catch</span> (e) {}\n","\n","  <span class=\"code-keyword\">var</span> result = {\n","    left: rect.left,\n","    top: rect.top,\n","    width: rect.right - rect.left,\n","    height: rect.bottom - rect.top\n","  };\n","\n","  <span class=\"code-comment\">// subtract scrollbar size from sizes</span>\n","  <span class=\"code-keyword\">var</span> sizes = element.nodeName === <span class=\"code-string\">'HTML'</span> ? getWindowSizes(element.ownerDocument) : {};\n","  <span class=\"code-keyword\">var</span> width = sizes.width || element.clientWidth || result.width;\n","  <span class=\"code-keyword\">var</span> height = sizes.height || element.clientHeight || result.height;\n","\n","  <span class=\"code-keyword\">var</span> horizScrollbar = element.offsetWidth - width;\n","  <span class=\"code-keyword\">var</span> vertScrollbar = element.offsetHeight - height;\n","\n","  <span class=\"code-comment\">// if an hypothetical scrollbar is detected, we must be sure it's not a `border`</span>\n","  <span class=\"code-comment\">// we make this check conditional for performance reasons</span>\n","  <span class=\"code-keyword\">if</span> (horizScrollbar || vertScrollbar) {\n","    <span class=\"code-keyword\">var</span> styles = getStyleComputedProperty(element);\n","    horizScrollbar -= getBordersSize(styles, <span class=\"code-string\">'x'</span>);\n","    vertScrollbar -= getBordersSize(styles, <span class=\"code-string\">'y'</span>);\n","\n","    result.width -= horizScrollbar;\n","    result.height -= vertScrollbar;\n","  }\n","\n","  <span class=\"code-keyword\">return</span> getClientRect(result);\n","}\n","\n","<span class=\"code-function\"><span class=\"code-keyword\">function</span> <span class=\"code-title\">getOffsetRectRelativeToArbitraryNode</span>(<span class=\"code-params\">children, parent</span>) </span>{\n","  <span class=\"code-keyword\">var</span> fixedPosition = <span class=\"code-built_in\">arguments</span>.length &gt; <span class=\"code-number\">2</span> &amp;&amp; <span class=\"code-built_in\">arguments</span>[<span class=\"code-number\">2</span>] !== <span class=\"code-literal\">undefined</span> ? <span class=\"code-built_in\">arguments</span>[<span class=\"code-number\">2</span>] : <span class=\"code-literal\">false</span>;\n","\n","  <span class=\"code-keyword\">var</span> isIE10 = isIE(<span class=\"code-number\">10</span>);\n","  <span class=\"code-keyword\">var</span> isHTML = parent.nodeName === <span class=\"code-string\">'HTML'</span>;\n","  <span class=\"code-keyword\">var</span> childrenRect = getBoundingClientRect(children);\n","  <span class=\"code-keyword\">var</span> parentRect = getBoundingClientRect(parent);\n","  <span class=\"code-keyword\">var</span> scrollParent = getScrollParent(children);\n","\n","  <span class=\"code-keyword\">var</span> styles = getStyleComputedProperty(parent);\n","  <span class=\"code-keyword\">var</span> borderTopWidth = <span class=\"code-built_in\">parseFloat</span>(styles.borderTopWidth, <span class=\"code-number\">10</span>);\n","  <span class=\"code-keyword\">var</span> borderLeftWidth = <span class=\"code-built_in\">parseFloat</span>(styles.borderLeftWidth, <span class=\"code-number\">10</span>);\n","\n","  <span class=\"code-comment\">// In cases where the parent is fixed, we must ignore negative scroll in offset calc</span>\n","  <span class=\"code-keyword\">if</span> (fixedPosition &amp;&amp; isHTML) {\n","    parentRect.top = <span class=\"code-built_in\">Math</span>.max(parentRect.top, <span class=\"code-number\">0</span>);\n","    parentRect.left = <span class=\"code-built_in\">Math</span>.max(parentRect.left, <span class=\"code-number\">0</span>);\n","  }\n","  <span class=\"code-keyword\">var</span> offsets = getClientRect({\n","    top: childrenRect.top - parentRect.top - borderTopWidth,\n","    left: childrenRect.left - parentRect.left - borderLeftWidth,\n","    width: childrenRect.width,\n","    height: childrenRect.height\n","  });\n","  offsets.marginTop = <span class=\"code-number\">0</span>;\n","  offsets.marginLeft = <span class=\"code-number\">0</span>;\n","\n","  <span class=\"code-comment\">// Subtract margins of documentElement in case it's being used as parent</span>\n","  <span class=\"code-comment\">// we do this only on HTML because it's the only element that behaves</span>\n","  <span class=\"code-comment\">// differently when margins are applied to it. The margins are included in</span>\n","  <span class=\"code-comment\">// the box of the documentElement, in the other cases not.</span>\n","  <span class=\"code-keyword\">if</span> (!isIE10 &amp;&amp; isHTML) {\n","    <span class=\"code-keyword\">var</span> marginTop = <span class=\"code-built_in\">parseFloat</span>(styles.marginTop, <span class=\"code-number\">10</span>);\n","    <span class=\"code-keyword\">var</span> marginLeft = <span class=\"code-built_in\">parseFloat</span>(styles.marginLeft, <span class=\"code-number\">10</span>);\n","\n","    offsets.top -= borderTopWidth - marginTop;\n","    offsets.bottom -= borderTopWidth - marginTop;\n","    offsets.left -= borderLeftWidth - marginLeft;\n","    offsets.right -= borderLeftWidth - marginLeft;\n","\n","    <span class=\"code-comment\">// Attach marginTop and marginLeft because in some circumstances we may need them</span>\n","    offsets.marginTop = marginTop;\n","    offsets.marginLeft = marginLeft;\n","  }\n","\n","  <span class=\"code-keyword\">if</span> (isIE10 &amp;&amp; !fixedPosition ? parent.contains(scrollParent) : parent === scrollParent &amp;&amp; scrollParent.nodeName !== <span class=\"code-string\">'BODY'</span>) {\n","    offsets = includeScroll(offsets, parent);\n","  }\n","\n","  <span class=\"code-keyword\">return</span> offsets;\n","}\n","\n","<span class=\"code-function\"><span class=\"code-keyword\">function</span> <span class=\"code-title\">getViewportOffsetRectRelativeToArtbitraryNode</span>(<span class=\"code-params\">element</span>) </span>{\n","  <span class=\"code-keyword\">var</span> excludeScroll = <span class=\"code-built_in\">arguments</span>.length &gt; <span class=\"code-number\">1</span> &amp;&amp; <span class=\"code-built_in\">arguments</span>[<span class=\"code-number\">1</span>] !== <span class=\"code-literal\">undefined</span> ? <span class=\"code-built_in\">arguments</span>[<span class=\"code-number\">1</span>] : <span class=\"code-literal\">false</span>;\n","\n","  <span class=\"code-keyword\">var</span> html = element.ownerDocument.documentElement;\n","  <span class=\"code-keyword\">var</span> relativeOffset = getOffsetRectRelativeToArbitraryNode(element, html);\n","  <span class=\"code-keyword\">var</span> width = <span class=\"code-built_in\">Math</span>.max(html.clientWidth, <span class=\"code-built_in\">window</span>.innerWidth || <span class=\"code-number\">0</span>);\n","  <span class=\"code-keyword\">var</span> height = <span class=\"code-built_in\">Math</span>.max(html.clientHeight, <span class=\"code-built_in\">window</span>.innerHeight || <span class=\"code-number\">0</span>);\n","\n","  <span class=\"code-keyword\">var</span> scrollTop = !excludeScroll ? getScroll(html) : <span class=\"code-number\">0</span>;\n","  <span class=\"code-keyword\">var</span> scrollLeft = !excludeScroll ? getScroll(html, <span class=\"code-string\">'left'</span>) : <span class=\"code-number\">0</span>;\n","\n","  <span class=\"code-keyword\">var</span> offset = {\n","    top: scrollTop - relativeOffset.top + relativeOffset.marginTop,\n","    left: scrollLeft - relativeOffset.left + relativeOffset.marginLeft,\n","    width: width,\n","    height: height\n","  };\n","\n","  <span class=\"code-keyword\">return</span> getClientRect(offset);\n","}\n","\n","<span class=\"code-comment\">/**\n</span>","<span class=\"code-comment\"> * Check if the given element is fixed or is inside a fixed parent\n</span>","<span class=\"code-comment\"> * @method\n</span>","<span class=\"code-comment\"> * @memberof Popper.Utils\n</span>","<span class=\"code-comment\"> * @argument {Element} element\n</span>","<span class=\"code-comment\"> * @argument {Element} customContainer\n</span>","<span class=\"code-comment\"> * @returns {Boolean} answer to \"isFixed?\"\n</span>","<span class=\"code-comment\"> */</span>\n","<span class=\"code-function\"><span class=\"code-keyword\">function</span> <span class=\"code-title\">isFixed</span>(<span class=\"code-params\">element</span>) </span>{\n","  <span class=\"code-keyword\">var</span> nodeName = element.nodeName;\n","  <span class=\"code-keyword\">if</span> (nodeName === <span class=\"code-string\">'BODY'</span> || nodeName === <span class=\"code-string\">'HTML'</span>) {\n","    <span class=\"code-keyword\">return</span> <span class=\"code-literal\">false</span>;\n","  }\n","  <span class=\"code-keyword\">if</span> (getStyleComputedProperty(element, <span class=\"code-string\">'position'</span>) === <span class=\"code-string\">'fixed'</span>) {\n","    <span class=\"code-keyword\">return</span> <span class=\"code-literal\">true</span>;\n","  }\n","  <span class=\"code-keyword\">var</span> parentNode = getParentNode(element);\n","  <span class=\"code-keyword\">if</span> (!parentNode) {\n","    <span class=\"code-keyword\">return</span> <span class=\"code-literal\">false</span>;\n","  }\n","  <span class=\"code-keyword\">return</span> isFixed(parentNode);\n","}\n","\n","<span class=\"code-comment\">/**\n</span>","<span class=\"code-comment\"> * Finds the first parent of an element that has a transformed property defined\n</span>","<span class=\"code-comment\"> * @method\n</span>","<span class=\"code-comment\"> * @memberof Popper.Utils\n</span>","<span class=\"code-comment\"> * @argument {Element} element\n</span>","<span class=\"code-comment\"> * @returns {Element} first transformed parent or documentElement\n</span>","<span class=\"code-comment\"> */</span>\n","\n","<span class=\"code-function\"><span class=\"code-keyword\">function</span> <span class=\"code-title\">getFixedPositionOffsetParent</span>(<span class=\"code-params\">element</span>) </span>{\n","  <span class=\"code-comment\">// This check is needed to avoid errors in case one of the elements isn't defined for any reason</span>\n","  <span class=\"code-keyword\">if</span> (!element || !element.parentElement || isIE()) {\n","    <span class=\"code-keyword\">return</span> <span class=\"code-built_in\">document</span>.documentElement;\n","  }\n","  <span class=\"code-keyword\">var</span> el = element.parentElement;\n","  <span class=\"code-keyword\">while</span> (el &amp;&amp; getStyleComputedProperty(el, <span class=\"code-string\">'transform'</span>) === <span class=\"code-string\">'none'</span>) {\n","    el = el.parentElement;\n","  }\n","  <span class=\"code-keyword\">return</span> el || <span class=\"code-built_in\">document</span>.documentElement;\n","}\n","\n","<span class=\"code-comment\">/**\n</span>","<span class=\"code-comment\"> * Computed the boundaries limits and return them\n</span>","<span class=\"code-comment\"> * @method\n</span>","<span class=\"code-comment\"> * @memberof Popper.Utils\n</span>","<span class=\"code-comment\"> * @param {HTMLElement} popper\n</span>","<span class=\"code-comment\"> * @param {HTMLElement} reference\n</span>","<span class=\"code-comment\"> * @param {number} padding\n</span>","<span class=\"code-comment\"> * @param {HTMLElement} boundariesElement - Element used to define the boundaries\n</span>","<span class=\"code-comment\"> * @param {Boolean} fixedPosition - Is in fixed position mode\n</span>","<span class=\"code-comment\"> * @returns {Object} Coordinates of the boundaries\n</span>","<span class=\"code-comment\"> */</span>\n","<span class=\"code-function\"><span class=\"code-keyword\">function</span> <span class=\"code-title\">getBoundaries</span>(<span class=\"code-params\">popper, reference, padding, boundariesElement</span>) </span>{\n","  <span class=\"code-keyword\">var</span> fixedPosition = <span class=\"code-built_in\">arguments</span>.length &gt; <span class=\"code-number\">4</span> &amp;&amp; <span class=\"code-built_in\">arguments</span>[<span class=\"code-number\">4</span>] !== <span class=\"code-literal\">undefined</span> ? <span class=\"code-built_in\">arguments</span>[<span class=\"code-number\">4</span>] : <span class=\"code-literal\">false</span>;\n","\n","  <span class=\"code-comment\">// <span class=\"code-doctag\">NOTE:</span> 1 DOM access here</span>\n","\n","  <span class=\"code-keyword\">var</span> boundaries = { <span class=\"code-attr\">top</span>: <span class=\"code-number\">0</span>, <span class=\"code-attr\">left</span>: <span class=\"code-number\">0</span> };\n","  <span class=\"code-keyword\">var</span> offsetParent = fixedPosition ? getFixedPositionOffsetParent(popper) : findCommonOffsetParent(popper, getReferenceNode(reference));\n","\n","  <span class=\"code-comment\">// Handle viewport case</span>\n","  <span class=\"code-keyword\">if</span> (boundariesElement === <span class=\"code-string\">'viewport'</span>) {\n","    boundaries = getViewportOffsetRectRelativeToArtbitraryNode(offsetParent, fixedPosition);\n","  } <span class=\"code-keyword\">else</span> {\n","    <span class=\"code-comment\">// Handle other cases based on DOM element used as boundaries</span>\n","    <span class=\"code-keyword\">var</span> boundariesNode = <span class=\"code-keyword\">void</span> <span class=\"code-number\">0</span>;\n","    <span class=\"code-keyword\">if</span> (boundariesElement === <span class=\"code-string\">'scrollParent'</span>) {\n","      boundariesNode = getScrollParent(getParentNode(reference));\n","      <span class=\"code-keyword\">if</span> (boundariesNode.nodeName === <span class=\"code-string\">'BODY'</span>) {\n","        boundariesNode = popper.ownerDocument.documentElement;\n","      }\n","    } <span class=\"code-keyword\">else</span> <span class=\"code-keyword\">if</span> (boundariesElement === <span class=\"code-string\">'window'</span>) {\n","      boundariesNode = popper.ownerDocument.documentElement;\n","    } <span class=\"code-keyword\">else</span> {\n","      boundariesNode = boundariesElement;\n","    }\n","\n","    <span class=\"code-keyword\">var</span> offsets = getOffsetRectRelativeToArbitraryNode(boundariesNode, offsetParent, fixedPosition);\n","\n","    <span class=\"code-comment\">// In case of HTML, we need a different computation</span>\n","    <span class=\"code-keyword\">if</span> (boundariesNode.nodeName === <span class=\"code-string\">'HTML'</span> &amp;&amp; !isFixed(offsetParent)) {\n","      <span class=\"code-keyword\">var</span> _getWindowSizes = getWindowSizes(popper.ownerDocument),\n","          height = _getWindowSizes.height,\n","          width = _getWindowSizes.width;\n","\n","      boundaries.top += offsets.top - offsets.marginTop;\n","      boundaries.bottom = height + offsets.top;\n","      boundaries.left += offsets.left - offsets.marginLeft;\n","      boundaries.right = width + offsets.left;\n","    } <span class=\"code-keyword\">else</span> {\n","      <span class=\"code-comment\">// for all the other DOM elements, this one is good</span>\n","      boundaries = offsets;\n","    }\n","  }\n","\n","  <span class=\"code-comment\">// Add paddings</span>\n","  padding = padding || <span class=\"code-number\">0</span>;\n","  <span class=\"code-keyword\">var</span> isPaddingNumber = <span class=\"code-keyword\">typeof</span> padding === <span class=\"code-string\">'number'</span>;\n","  boundaries.left += isPaddingNumber ? padding : padding.left || <span class=\"code-number\">0</span>;\n","  boundaries.top += isPaddingNumber ? padding : padding.top || <span class=\"code-number\">0</span>;\n","  boundaries.right -= isPaddingNumber ? padding : padding.right || <span class=\"code-number\">0</span>;\n","  boundaries.bottom -= isPaddingNumber ? padding : padding.bottom || <span class=\"code-number\">0</span>;\n","\n","  <span class=\"code-keyword\">return</span> boundaries;\n","}\n","\n","<span class=\"code-function\"><span class=\"code-keyword\">function</span> <span class=\"code-title\">getArea</span>(<span class=\"code-params\">_ref</span>) </span>{\n","  <span class=\"code-keyword\">var</span> width = _ref.width,\n","      height = _ref.height;\n","\n","  <span class=\"code-keyword\">return</span> width * height;\n","}\n","\n","<span class=\"code-comment\">/**\n</span>","<span class=\"code-comment\"> * Utility used to transform the `auto` placement to the placement with more\n</span>","<span class=\"code-comment\"> * available space.\n</span>","<span class=\"code-comment\"> * @method\n</span>","<span class=\"code-comment\"> * @memberof Popper.Utils\n</span>","<span class=\"code-comment\"> * @argument {Object} data - The data object generated by update method\n</span>","<span class=\"code-comment\"> * @argument {Object} options - Modifiers configuration and options\n</span>","<span class=\"code-comment\"> * @returns {Object} The data object, properly modified\n</span>","<span class=\"code-comment\"> */</span>\n","<span class=\"code-function\"><span class=\"code-keyword\">function</span> <span class=\"code-title\">computeAutoPlacement</span>(<span class=\"code-params\">placement, refRect, popper, reference, boundariesElement</span>) </span>{\n","  <span class=\"code-keyword\">var</span> padding = <span class=\"code-built_in\">arguments</span>.length &gt; <span class=\"code-number\">5</span> &amp;&amp; <span class=\"code-built_in\">arguments</span>[<span class=\"code-number\">5</span>] !== <span class=\"code-literal\">undefined</span> ? <span class=\"code-built_in\">arguments</span>[<span class=\"code-number\">5</span>] : <span class=\"code-number\">0</span>;\n","\n","  <span class=\"code-keyword\">if</span> (placement.indexOf(<span class=\"code-string\">'auto'</span>) === <span class=\"code-number\">-1</span>) {\n","    <span class=\"code-keyword\">return</span> placement;\n","  }\n","\n","  <span class=\"code-keyword\">var</span> boundaries = getBoundaries(popper, reference, padding, boundariesElement);\n","\n","  <span class=\"code-keyword\">var</span> rects = {\n","    top: {\n","      width: boundaries.width,\n","      height: refRect.top - boundaries.top\n","    },\n","    right: {\n","      width: boundaries.right - refRect.right,\n","      height: boundaries.height\n","    },\n","    bottom: {\n","      width: boundaries.width,\n","      height: boundaries.bottom - refRect.bottom\n","    },\n","    left: {\n","      width: refRect.left - boundaries.left,\n","      height: boundaries.height\n","    }\n","  };\n","\n","  <span class=\"code-keyword\">var</span> sortedAreas = <span class=\"code-built_in\">Object</span>.keys(rects).map(<span class=\"code-function\"><span class=\"code-keyword\">function</span> (<span class=\"code-params\">key</span>) </span>{\n","    <span class=\"code-keyword\">return</span> _extends({\n","      key: key\n","    }, rects[key], {\n","      area: getArea(rects[key])\n","    });\n","  }).sort(<span class=\"code-function\"><span class=\"code-keyword\">function</span> (<span class=\"code-params\">a, b</span>) </span>{\n","    <span class=\"code-keyword\">return</span> b.area - a.area;\n","  });\n","\n","  <span class=\"code-keyword\">var</span> filteredAreas = sortedAreas.filter(<span class=\"code-function\"><span class=\"code-keyword\">function</span> (<span class=\"code-params\">_ref2</span>) </span>{\n","    <span class=\"code-keyword\">var</span> width = _ref2.width,\n","        height = _ref2.height;\n","    <span class=\"code-keyword\">return</span> width &gt;= popper.clientWidth &amp;&amp; height &gt;= popper.clientHeight;\n","  });\n","\n","  <span class=\"code-keyword\">var</span> computedPlacement = filteredAreas.length &gt; <span class=\"code-number\">0</span> ? filteredAreas[<span class=\"code-number\">0</span>].key : sortedAreas[<span class=\"code-number\">0</span>].key;\n","\n","  <span class=\"code-keyword\">var</span> variation = placement.split(<span class=\"code-string\">'-'</span>)[<span class=\"code-number\">1</span>];\n","\n","  <span class=\"code-keyword\">return</span> computedPlacement + (variation ? <span class=\"code-string\">'-'</span> + variation : <span class=\"code-string\">''</span>);\n","}\n","\n","<span class=\"code-keyword\">var</span> timeoutDuration = <span class=\"code-function\"><span class=\"code-keyword\">function</span> (<span class=\"code-params\"></span>) </span>{\n","  <span class=\"code-keyword\">var</span> longerTimeoutBrowsers = [<span class=\"code-string\">'Edge'</span>, <span class=\"code-string\">'Trident'</span>, <span class=\"code-string\">'Firefox'</span>];\n","  <span class=\"code-keyword\">for</span> (<span class=\"code-keyword\">var</span> i = <span class=\"code-number\">0</span>; i &lt; longerTimeoutBrowsers.length; i += <span class=\"code-number\">1</span>) {\n","    <span class=\"code-keyword\">if</span> (isBrowser &amp;&amp; navigator.userAgent.indexOf(longerTimeoutBrowsers[i]) &gt;= <span class=\"code-number\">0</span>) {\n","      <span class=\"code-keyword\">return</span> <span class=\"code-number\">1</span>;\n","    }\n","  }\n","  <span class=\"code-keyword\">return</span> <span class=\"code-number\">0</span>;\n","}();\n","\n","<span class=\"code-function\"><span class=\"code-keyword\">function</span> <span class=\"code-title\">microtaskDebounce</span>(<span class=\"code-params\">fn</span>) </span>{\n","  <span class=\"code-keyword\">var</span> called = <span class=\"code-literal\">false</span>;\n","  <span class=\"code-keyword\">return</span> <span class=\"code-function\"><span class=\"code-keyword\">function</span> (<span class=\"code-params\"></span>) </span>{\n","    <span class=\"code-keyword\">if</span> (called) {\n","      <span class=\"code-keyword\">return</span>;\n","    }\n","    called = <span class=\"code-literal\">true</span>;\n","    <span class=\"code-built_in\">window</span>.Promise.resolve().then(<span class=\"code-function\"><span class=\"code-keyword\">function</span> (<span class=\"code-params\"></span>) </span>{\n","      called = <span class=\"code-literal\">false</span>;\n","      fn();\n","    });\n","  };\n","}\n","\n","<span class=\"code-function\"><span class=\"code-keyword\">function</span> <span class=\"code-title\">taskDebounce</span>(<span class=\"code-params\">fn</span>) </span>{\n","  <span class=\"code-keyword\">var</span> scheduled = <span class=\"code-literal\">false</span>;\n","  <span class=\"code-keyword\">return</span> <span class=\"code-function\"><span class=\"code-keyword\">function</span> (<span class=\"code-params\"></span>) </span>{\n","    <span class=\"code-keyword\">if</span> (!scheduled) {\n","      scheduled = <span class=\"code-literal\">true</span>;\n","      setTimeout(<span class=\"code-function\"><span class=\"code-keyword\">function</span> (<span class=\"code-params\"></span>) </span>{\n","        scheduled = <span class=\"code-literal\">false</span>;\n","        fn();\n","      }, timeoutDuration);\n","    }\n","  };\n","}\n","\n","<span class=\"code-keyword\">var</span> supportsMicroTasks = isBrowser &amp;&amp; <span class=\"code-built_in\">window</span>.Promise;\n","\n","<span class=\"code-comment\">/**\n</span>","<span class=\"code-comment\">* Create a debounced version of a method, that's asynchronously deferred\n</span>","<span class=\"code-comment\">* but called in the minimum time possible.\n</span>","<span class=\"code-comment\">*\n</span>","<span class=\"code-comment\">* @method\n</span>","<span class=\"code-comment\">* @memberof Popper.Utils\n</span>","<span class=\"code-comment\">* @argument {Function} fn\n</span>","<span class=\"code-comment\">* @returns {Function}\n</span>","<span class=\"code-comment\">*/</span>\n","<span class=\"code-keyword\">var</span> debounce = supportsMicroTasks ? microtaskDebounce : taskDebounce;\n","\n","<span class=\"code-comment\">/**\n</span>","<span class=\"code-comment\"> * Mimics the `find` method of Array\n</span>","<span class=\"code-comment\"> * @method\n</span>","<span class=\"code-comment\"> * @memberof Popper.Utils\n</span>","<span class=\"code-comment\"> * @argument {Array} arr\n</span>","<span class=\"code-comment\"> * @argument prop\n</span>","<span class=\"code-comment\"> * @argument value\n</span>","<span class=\"code-comment\"> * @returns index or -1\n</span>","<span class=\"code-comment\"> */</span>\n","<span class=\"code-function\"><span class=\"code-keyword\">function</span> <span class=\"code-title\">find</span>(<span class=\"code-params\">arr, check</span>) </span>{\n","  <span class=\"code-comment\">// use native find if supported</span>\n","  <span class=\"code-keyword\">if</span> (<span class=\"code-built_in\">Array</span>.prototype.find) {\n","    <span class=\"code-keyword\">return</span> arr.find(check);\n","  }\n","\n","  <span class=\"code-comment\">// use `filter` to obtain the same behavior of `find`</span>\n","  <span class=\"code-keyword\">return</span> arr.filter(check)[<span class=\"code-number\">0</span>];\n","}\n","\n","<span class=\"code-comment\">/**\n</span>","<span class=\"code-comment\"> * Return the index of the matching object\n</span>","<span class=\"code-comment\"> * @method\n</span>","<span class=\"code-comment\"> * @memberof Popper.Utils\n</span>","<span class=\"code-comment\"> * @argument {Array} arr\n</span>","<span class=\"code-comment\"> * @argument prop\n</span>","<span class=\"code-comment\"> * @argument value\n</span>","<span class=\"code-comment\"> * @returns index or -1\n</span>","<span class=\"code-comment\"> */</span>\n","<span class=\"code-function\"><span class=\"code-keyword\">function</span> <span class=\"code-title\">findIndex</span>(<span class=\"code-params\">arr, prop, value</span>) </span>{\n","  <span class=\"code-comment\">// use native findIndex if supported</span>\n","  <span class=\"code-keyword\">if</span> (<span class=\"code-built_in\">Array</span>.prototype.findIndex) {\n","    <span class=\"code-keyword\">return</span> arr.findIndex(<span class=\"code-function\"><span class=\"code-keyword\">function</span> (<span class=\"code-params\">cur</span>) </span>{\n","      <span class=\"code-keyword\">return</span> cur[prop] === value;\n","    });\n","  }\n","\n","  <span class=\"code-comment\">// use `find` + `indexOf` if `findIndex` isn't supported</span>\n","  <span class=\"code-keyword\">var</span> match = find(arr, <span class=\"code-function\"><span class=\"code-keyword\">function</span> (<span class=\"code-params\">obj</span>) </span>{\n","    <span class=\"code-keyword\">return</span> obj[prop] === value;\n","  });\n","  <span class=\"code-keyword\">return</span> arr.indexOf(match);\n","}\n","\n","<span class=\"code-comment\">/**\n</span>","<span class=\"code-comment\"> * Get the position of the given element, relative to its offset parent\n</span>","<span class=\"code-comment\"> * @method\n</span>","<span class=\"code-comment\"> * @memberof Popper.Utils\n</span>","<span class=\"code-comment\"> * @param {Element} element\n</span>","<span class=\"code-comment\"> * @return {Object} position - Coordinates of the element and its `scrollTop`\n</span>","<span class=\"code-comment\"> */</span>\n","<span class=\"code-function\"><span class=\"code-keyword\">function</span> <span class=\"code-title\">getOffsetRect</span>(<span class=\"code-params\">element</span>) </span>{\n","  <span class=\"code-keyword\">var</span> elementRect = <span class=\"code-keyword\">void</span> <span class=\"code-number\">0</span>;\n","  <span class=\"code-keyword\">if</span> (element.nodeName === <span class=\"code-string\">'HTML'</span>) {\n","    <span class=\"code-keyword\">var</span> _getWindowSizes = getWindowSizes(element.ownerDocument),\n","        width = _getWindowSizes.width,\n","        height = _getWindowSizes.height;\n","\n","    elementRect = {\n","      width: width,\n","      height: height,\n","      left: <span class=\"code-number\">0</span>,\n","      top: <span class=\"code-number\">0</span>\n","    };\n","  } <span class=\"code-keyword\">else</span> {\n","    elementRect = {\n","      width: element.offsetWidth,\n","      height: element.offsetHeight,\n","      left: element.offsetLeft,\n","      top: element.offsetTop\n","    };\n","  }\n","\n","  <span class=\"code-comment\">// position</span>\n","  <span class=\"code-keyword\">return</span> getClientRect(elementRect);\n","}\n","\n","<span class=\"code-comment\">/**\n</span>","<span class=\"code-comment\"> * Get the outer sizes of the given element (offset size + margins)\n</span>","<span class=\"code-comment\"> * @method\n</span>","<span class=\"code-comment\"> * @memberof Popper.Utils\n</span>","<span class=\"code-comment\"> * @argument {Element} element\n</span>","<span class=\"code-comment\"> * @returns {Object} object containing width and height properties\n</span>","<span class=\"code-comment\"> */</span>\n","<span class=\"code-function\"><span class=\"code-keyword\">function</span> <span class=\"code-title\">getOuterSizes</span>(<span class=\"code-params\">element</span>) </span>{\n","  <span class=\"code-keyword\">var</span> <span class=\"code-built_in\">window</span> = element.ownerDocument.defaultView;\n","  <span class=\"code-keyword\">var</span> styles = <span class=\"code-built_in\">window</span>.getComputedStyle(element);\n","  <span class=\"code-keyword\">var</span> x = <span class=\"code-built_in\">parseFloat</span>(styles.marginTop || <span class=\"code-number\">0</span>) + <span class=\"code-built_in\">parseFloat</span>(styles.marginBottom || <span class=\"code-number\">0</span>);\n","  <span class=\"code-keyword\">var</span> y = <span class=\"code-built_in\">parseFloat</span>(styles.marginLeft || <span class=\"code-number\">0</span>) + <span class=\"code-built_in\">parseFloat</span>(styles.marginRight || <span class=\"code-number\">0</span>);\n","  <span class=\"code-keyword\">var</span> result = {\n","    width: element.offsetWidth + y,\n","    height: element.offsetHeight + x\n","  };\n","  <span class=\"code-keyword\">return</span> result;\n","}\n","\n","<span class=\"code-comment\">/**\n</span>","<span class=\"code-comment\"> * Get the opposite placement of the given one\n</span>","<span class=\"code-comment\"> * @method\n</span>","<span class=\"code-comment\"> * @memberof Popper.Utils\n</span>","<span class=\"code-comment\"> * @argument {String} placement\n</span>","<span class=\"code-comment\"> * @returns {String} flipped placement\n</span>","<span class=\"code-comment\"> */</span>\n","<span class=\"code-function\"><span class=\"code-keyword\">function</span> <span class=\"code-title\">getOppositePlacement</span>(<span class=\"code-params\">placement</span>) </span>{\n","  <span class=\"code-keyword\">var</span> hash = { <span class=\"code-attr\">left</span>: <span class=\"code-string\">'right'</span>, <span class=\"code-attr\">right</span>: <span class=\"code-string\">'left'</span>, <span class=\"code-attr\">bottom</span>: <span class=\"code-string\">'top'</span>, <span class=\"code-attr\">top</span>: <span class=\"code-string\">'bottom'</span> };\n","  <span class=\"code-keyword\">return</span> placement.replace(<span class=\"code-regexp\">/left|right|bottom|top/g</span>, <span class=\"code-function\"><span class=\"code-keyword\">function</span> (<span class=\"code-params\">matched</span>) </span>{\n","    <span class=\"code-keyword\">return</span> hash[matched];\n","  });\n","}\n","\n","<span class=\"code-comment\">/**\n</span>","<span class=\"code-comment\"> * Get offsets to the popper\n</span>","<span class=\"code-comment\"> * @method\n</span>","<span class=\"code-comment\"> * @memberof Popper.Utils\n</span>","<span class=\"code-comment\"> * @param {Object} position - CSS position the Popper will get applied\n</span>","<span class=\"code-comment\"> * @param {HTMLElement} popper - the popper element\n</span>","<span class=\"code-comment\"> * @param {Object} referenceOffsets - the reference offsets (the popper will be relative to this)\n</span>","<span class=\"code-comment\"> * @param {String} placement - one of the valid placement options\n</span>","<span class=\"code-comment\"> * @returns {Object} popperOffsets - An object containing the offsets which will be applied to the popper\n</span>","<span class=\"code-comment\"> */</span>\n","<span class=\"code-function\"><span class=\"code-keyword\">function</span> <span class=\"code-title\">getPopperOffsets</span>(<span class=\"code-params\">popper, referenceOffsets, placement</span>) </span>{\n","  placement = placement.split(<span class=\"code-string\">'-'</span>)[<span class=\"code-number\">0</span>];\n","\n","  <span class=\"code-comment\">// Get popper node sizes</span>\n","  <span class=\"code-keyword\">var</span> popperRect = getOuterSizes(popper);\n","\n","  <span class=\"code-comment\">// Add position, width and height to our offsets object</span>\n","  <span class=\"code-keyword\">var</span> popperOffsets = {\n","    width: popperRect.width,\n","    height: popperRect.height\n","  };\n","\n","  <span class=\"code-comment\">// depending by the popper placement we have to compute its offsets slightly differently</span>\n","  <span class=\"code-keyword\">var</span> isHoriz = [<span class=\"code-string\">'right'</span>, <span class=\"code-string\">'left'</span>].indexOf(placement) !== <span class=\"code-number\">-1</span>;\n","  <span class=\"code-keyword\">var</span> mainSide = isHoriz ? <span class=\"code-string\">'top'</span> : <span class=\"code-string\">'left'</span>;\n","  <span class=\"code-keyword\">var</span> secondarySide = isHoriz ? <span class=\"code-string\">'left'</span> : <span class=\"code-string\">'top'</span>;\n","  <span class=\"code-keyword\">var</span> measurement = isHoriz ? <span class=\"code-string\">'height'</span> : <span class=\"code-string\">'width'</span>;\n","  <span class=\"code-keyword\">var</span> secondaryMeasurement = !isHoriz ? <span class=\"code-string\">'height'</span> : <span class=\"code-string\">'width'</span>;\n","\n","  popperOffsets[mainSide] = referenceOffsets[mainSide] + referenceOffsets[measurement] / <span class=\"code-number\">2</span> - popperRect[measurement] / <span class=\"code-number\">2</span>;\n","  <span class=\"code-keyword\">if</span> (placement === secondarySide) {\n","    popperOffsets[secondarySide] = referenceOffsets[secondarySide] - popperRect[secondaryMeasurement];\n","  } <span class=\"code-keyword\">else</span> {\n","    popperOffsets[secondarySide] = referenceOffsets[getOppositePlacement(secondarySide)];\n","  }\n","\n","  <span class=\"code-keyword\">return</span> popperOffsets;\n","}\n","\n","<span class=\"code-comment\">/**\n</span>","<span class=\"code-comment\"> * Get offsets to the reference element\n</span>","<span class=\"code-comment\"> * @method\n</span>","<span class=\"code-comment\"> * @memberof Popper.Utils\n</span>","<span class=\"code-comment\"> * @param {Object} state\n</span>","<span class=\"code-comment\"> * @param {Element} popper - the popper element\n</span>","<span class=\"code-comment\"> * @param {Element} reference - the reference element (the popper will be relative to this)\n</span>","<span class=\"code-comment\"> * @param {Element} fixedPosition - is in fixed position mode\n</span>","<span class=\"code-comment\"> * @returns {Object} An object containing the offsets which will be applied to the popper\n</span>","<span class=\"code-comment\"> */</span>\n","<span class=\"code-function\"><span class=\"code-keyword\">function</span> <span class=\"code-title\">getReferenceOffsets</span>(<span class=\"code-params\">state, popper, reference</span>) </span>{\n","  <span class=\"code-keyword\">var</span> fixedPosition = <span class=\"code-built_in\">arguments</span>.length &gt; <span class=\"code-number\">3</span> &amp;&amp; <span class=\"code-built_in\">arguments</span>[<span class=\"code-number\">3</span>] !== <span class=\"code-literal\">undefined</span> ? <span class=\"code-built_in\">arguments</span>[<span class=\"code-number\">3</span>] : <span class=\"code-literal\">null</span>;\n","\n","  <span class=\"code-keyword\">var</span> commonOffsetParent = fixedPosition ? getFixedPositionOffsetParent(popper) : findCommonOffsetParent(popper, getReferenceNode(reference));\n","  <span class=\"code-keyword\">return</span> getOffsetRectRelativeToArbitraryNode(reference, commonOffsetParent, fixedPosition);\n","}\n","\n","<span class=\"code-comment\">/**\n</span>","<span class=\"code-comment\"> * Get the prefixed supported property name\n</span>","<span class=\"code-comment\"> * @method\n</span>","<span class=\"code-comment\"> * @memberof Popper.Utils\n</span>","<span class=\"code-comment\"> * @argument {String} property (camelCase)\n</span>","<span class=\"code-comment\"> * @returns {String} prefixed property (camelCase or PascalCase, depending on the vendor prefix)\n</span>","<span class=\"code-comment\"> */</span>\n","<span class=\"code-function\"><span class=\"code-keyword\">function</span> <span class=\"code-title\">getSupportedPropertyName</span>(<span class=\"code-params\">property</span>) </span>{\n","  <span class=\"code-keyword\">var</span> prefixes = [<span class=\"code-literal\">false</span>, <span class=\"code-string\">'ms'</span>, <span class=\"code-string\">'Webkit'</span>, <span class=\"code-string\">'Moz'</span>, <span class=\"code-string\">'O'</span>];\n","  <span class=\"code-keyword\">var</span> upperProp = property.charAt(<span class=\"code-number\">0</span>).toUpperCase() + property.slice(<span class=\"code-number\">1</span>);\n","\n","  <span class=\"code-keyword\">for</span> (<span class=\"code-keyword\">var</span> i = <span class=\"code-number\">0</span>; i &lt; prefixes.length; i++) {\n","    <span class=\"code-keyword\">var</span> prefix = prefixes[i];\n","    <span class=\"code-keyword\">var</span> toCheck = prefix ? <span class=\"code-string\">''</span> + prefix + upperProp : property;\n","    <span class=\"code-keyword\">if</span> (<span class=\"code-keyword\">typeof</span> <span class=\"code-built_in\">document</span>.body.style[toCheck] !== <span class=\"code-string\">'undefined'</span>) {\n","      <span class=\"code-keyword\">return</span> toCheck;\n","    }\n","  }\n","  <span class=\"code-keyword\">return</span> <span class=\"code-literal\">null</span>;\n","}\n","\n","<span class=\"code-comment\">/**\n</span>","<span class=\"code-comment\"> * Check if the given variable is a function\n</span>","<span class=\"code-comment\"> * @method\n</span>","<span class=\"code-comment\"> * @memberof Popper.Utils\n</span>","<span class=\"code-comment\"> * @argument {Any} functionToCheck - variable to check\n</span>","<span class=\"code-comment\"> * @returns {Boolean} answer to: is a function?\n</span>","<span class=\"code-comment\"> */</span>\n","<span class=\"code-function\"><span class=\"code-keyword\">function</span> <span class=\"code-title\">isFunction</span>(<span class=\"code-params\">functionToCheck</span>) </span>{\n","  <span class=\"code-keyword\">var</span> getType = {};\n","  <span class=\"code-keyword\">return</span> functionToCheck &amp;&amp; getType.toString.call(functionToCheck) === <span class=\"code-string\">'[object Function]'</span>;\n","}\n","\n","<span class=\"code-comment\">/**\n</span>","<span class=\"code-comment\"> * Helper used to know if the given modifier is enabled.\n</span>","<span class=\"code-comment\"> * @method\n</span>","<span class=\"code-comment\"> * @memberof Popper.Utils\n</span>","<span class=\"code-comment\"> * @returns {Boolean}\n</span>","<span class=\"code-comment\"> */</span>\n","<span class=\"code-function\"><span class=\"code-keyword\">function</span> <span class=\"code-title\">isModifierEnabled</span>(<span class=\"code-params\">modifiers, modifierName</span>) </span>{\n","  <span class=\"code-keyword\">return</span> modifiers.some(<span class=\"code-function\"><span class=\"code-keyword\">function</span> (<span class=\"code-params\">_ref</span>) </span>{\n","    <span class=\"code-keyword\">var</span> name = _ref.name,\n","        enabled = _ref.enabled;\n","    <span class=\"code-keyword\">return</span> enabled &amp;&amp; name === modifierName;\n","  });\n","}\n","\n","<span class=\"code-comment\">/**\n</span>","<span class=\"code-comment\"> * Helper used to know if the given modifier depends from another one.&lt;br /&gt;\n</span>","<span class=\"code-comment\"> * It checks if the needed modifier is listed and enabled.\n</span>","<span class=\"code-comment\"> * @method\n</span>","<span class=\"code-comment\"> * @memberof Popper.Utils\n</span>","<span class=\"code-comment\"> * @param {Array} modifiers - list of modifiers\n</span>","<span class=\"code-comment\"> * @param {String} requestingName - name of requesting modifier\n</span>","<span class=\"code-comment\"> * @param {String} requestedName - name of requested modifier\n</span>","<span class=\"code-comment\"> * @returns {Boolean}\n</span>","<span class=\"code-comment\"> */</span>\n","<span class=\"code-function\"><span class=\"code-keyword\">function</span> <span class=\"code-title\">isModifierRequired</span>(<span class=\"code-params\">modifiers, requestingName, requestedName</span>) </span>{\n","  <span class=\"code-keyword\">var</span> requesting = find(modifiers, <span class=\"code-function\"><span class=\"code-keyword\">function</span> (<span class=\"code-params\">_ref</span>) </span>{\n","    <span class=\"code-keyword\">var</span> name = _ref.name;\n","    <span class=\"code-keyword\">return</span> name === requestingName;\n","  });\n","\n","  <span class=\"code-keyword\">var</span> isRequired = !!requesting &amp;&amp; modifiers.some(<span class=\"code-function\"><span class=\"code-keyword\">function</span> (<span class=\"code-params\">modifier</span>) </span>{\n","    <span class=\"code-keyword\">return</span> modifier.name === requestedName &amp;&amp; modifier.enabled &amp;&amp; modifier.order &lt; requesting.order;\n","  });\n","\n","  <span class=\"code-keyword\">if</span> (!isRequired) {\n","    <span class=\"code-keyword\">var</span> _requesting = <span class=\"code-string\">'`'</span> + requestingName + <span class=\"code-string\">'`'</span>;\n","    <span class=\"code-keyword\">var</span> requested = <span class=\"code-string\">'`'</span> + requestedName + <span class=\"code-string\">'`'</span>;\n","    <span class=\"code-built_in\">console</span>.warn(requested + <span class=\"code-string\">' modifier is required by '</span> + _requesting + <span class=\"code-string\">' modifier in order to work, be sure to include it before '</span> + _requesting + <span class=\"code-string\">'!'</span>);\n","  }\n","  <span class=\"code-keyword\">return</span> isRequired;\n","}\n","\n","<span class=\"code-comment\">/**\n</span>","<span class=\"code-comment\"> * Tells if a given input is a number\n</span>","<span class=\"code-comment\"> * @method\n</span>","<span class=\"code-comment\"> * @memberof Popper.Utils\n</span>","<span class=\"code-comment\"> * @param {*} input to check\n</span>","<span class=\"code-comment\"> * @return {Boolean}\n</span>","<span class=\"code-comment\"> */</span>\n","<span class=\"code-function\"><span class=\"code-keyword\">function</span> <span class=\"code-title\">isNumeric</span>(<span class=\"code-params\">n</span>) </span>{\n","  <span class=\"code-keyword\">return</span> n !== <span class=\"code-string\">''</span> &amp;&amp; !<span class=\"code-built_in\">isNaN</span>(<span class=\"code-built_in\">parseFloat</span>(n)) &amp;&amp; <span class=\"code-built_in\">isFinite</span>(n);\n","}\n","\n","<span class=\"code-comment\">/**\n</span>","<span class=\"code-comment\"> * Get the window associated with the element\n</span>","<span class=\"code-comment\"> * @argument {Element} element\n</span>","<span class=\"code-comment\"> * @returns {Window}\n</span>","<span class=\"code-comment\"> */</span>\n","<span class=\"code-function\"><span class=\"code-keyword\">function</span> <span class=\"code-title\">getWindow</span>(<span class=\"code-params\">element</span>) </span>{\n","  <span class=\"code-keyword\">var</span> ownerDocument = element.ownerDocument;\n","  <span class=\"code-keyword\">return</span> ownerDocument ? ownerDocument.defaultView : <span class=\"code-built_in\">window</span>;\n","}\n","\n","<span class=\"code-comment\">/**\n</span>","<span class=\"code-comment\"> * Remove event listeners used to update the popper position\n</span>","<span class=\"code-comment\"> * @method\n</span>","<span class=\"code-comment\"> * @memberof Popper.Utils\n</span>","<span class=\"code-comment\"> * @private\n</span>","<span class=\"code-comment\"> */</span>\n","<span class=\"code-function\"><span class=\"code-keyword\">function</span> <span class=\"code-title\">removeEventListeners</span>(<span class=\"code-params\">reference, state</span>) </span>{\n","  <span class=\"code-comment\">// Remove resize event listener on window</span>\n","  getWindow(reference).removeEventListener(<span class=\"code-string\">'resize'</span>, state.updateBound);\n","\n","  <span class=\"code-comment\">// Remove scroll event listener on scroll parents</span>\n","  state.scrollParents.forEach(<span class=\"code-function\"><span class=\"code-keyword\">function</span> (<span class=\"code-params\">target</span>) </span>{\n","    target.removeEventListener(<span class=\"code-string\">'scroll'</span>, state.updateBound);\n","  });\n","\n","  <span class=\"code-comment\">// Reset state</span>\n","  state.updateBound = <span class=\"code-literal\">null</span>;\n","  state.scrollParents = [];\n","  state.scrollElement = <span class=\"code-literal\">null</span>;\n","  state.eventsEnabled = <span class=\"code-literal\">false</span>;\n","  <span class=\"code-keyword\">return</span> state;\n","}\n","\n","<span class=\"code-comment\">/**\n</span>","<span class=\"code-comment\"> * Loop trough the list of modifiers and run them in order,\n</span>","<span class=\"code-comment\"> * each of them will then edit the data object.\n</span>","<span class=\"code-comment\"> * @method\n</span>","<span class=\"code-comment\"> * @memberof Popper.Utils\n</span>","<span class=\"code-comment\"> * @param {dataObject} data\n</span>","<span class=\"code-comment\"> * @param {Array} modifiers\n</span>","<span class=\"code-comment\"> * @param {String} ends - Optional modifier name used as stopper\n</span>","<span class=\"code-comment\"> * @returns {dataObject}\n</span>","<span class=\"code-comment\"> */</span>\n","<span class=\"code-function\"><span class=\"code-keyword\">function</span> <span class=\"code-title\">runModifiers</span>(<span class=\"code-params\">modifiers, data, ends</span>) </span>{\n","  <span class=\"code-keyword\">var</span> modifiersToRun = ends === <span class=\"code-literal\">undefined</span> ? modifiers : modifiers.slice(<span class=\"code-number\">0</span>, findIndex(modifiers, <span class=\"code-string\">'name'</span>, ends));\n","\n","  modifiersToRun.forEach(<span class=\"code-function\"><span class=\"code-keyword\">function</span> (<span class=\"code-params\">modifier</span>) </span>{\n","    <span class=\"code-keyword\">if</span> (modifier[<span class=\"code-string\">'function'</span>]) {\n","      <span class=\"code-comment\">// eslint-disable-line dot-notation</span>\n","      <span class=\"code-built_in\">console</span>.warn(<span class=\"code-string\">'`modifier.function` is deprecated, use `modifier.fn`!'</span>);\n","    }\n","    <span class=\"code-keyword\">var</span> fn = modifier[<span class=\"code-string\">'function'</span>] || modifier.fn; <span class=\"code-comment\">// eslint-disable-line dot-notation</span>\n","    <span class=\"code-keyword\">if</span> (modifier.enabled &amp;&amp; isFunction(fn)) {\n","      <span class=\"code-comment\">// Add properties to offsets to make them a complete clientRect object</span>\n","      <span class=\"code-comment\">// we do this before each modifier to make sure the previous one doesn't</span>\n","      <span class=\"code-comment\">// mess with these values</span>\n","      data.offsets.popper = getClientRect(data.offsets.popper);\n","      data.offsets.reference = getClientRect(data.offsets.reference);\n","\n","      data = fn(data, modifier);\n","    }\n","  });\n","\n","  <span class=\"code-keyword\">return</span> data;\n","}\n","\n","<span class=\"code-comment\">/**\n</span>","<span class=\"code-comment\"> * Set the attributes to the given popper\n</span>","<span class=\"code-comment\"> * @method\n</span>","<span class=\"code-comment\"> * @memberof Popper.Utils\n</span>","<span class=\"code-comment\"> * @argument {Element} element - Element to apply the attributes to\n</span>","<span class=\"code-comment\"> * @argument {Object} styles\n</span>","<span class=\"code-comment\"> * Object with a list of properties and values which will be applied to the element\n</span>","<span class=\"code-comment\"> */</span>\n","<span class=\"code-function\"><span class=\"code-keyword\">function</span> <span class=\"code-title\">setAttributes</span>(<span class=\"code-params\">element, attributes</span>) </span>{\n","  <span class=\"code-built_in\">Object</span>.keys(attributes).forEach(<span class=\"code-function\"><span class=\"code-keyword\">function</span> (<span class=\"code-params\">prop</span>) </span>{\n","    <span class=\"code-keyword\">var</span> value = attributes[prop];\n","    <span class=\"code-keyword\">if</span> (value !== <span class=\"code-literal\">false</span>) {\n","      element.setAttribute(prop, attributes[prop]);\n","    } <span class=\"code-keyword\">else</span> {\n","      element.removeAttribute(prop);\n","    }\n","  });\n","}\n","\n","<span class=\"code-comment\">/**\n</span>","<span class=\"code-comment\"> * Set the style to the given popper\n</span>","<span class=\"code-comment\"> * @method\n</span>","<span class=\"code-comment\"> * @memberof Popper.Utils\n</span>","<span class=\"code-comment\"> * @argument {Element} element - Element to apply the style to\n</span>","<span class=\"code-comment\"> * @argument {Object} styles\n</span>","<span class=\"code-comment\"> * Object with a list of properties and values which will be applied to the element\n</span>","<span class=\"code-comment\"> */</span>\n","<span class=\"code-function\"><span class=\"code-keyword\">function</span> <span class=\"code-title\">setStyles</span>(<span class=\"code-params\">element, styles</span>) </span>{\n","  <span class=\"code-built_in\">Object</span>.keys(styles).forEach(<span class=\"code-function\"><span class=\"code-keyword\">function</span> (<span class=\"code-params\">prop</span>) </span>{\n","    <span class=\"code-keyword\">var</span> unit = <span class=\"code-string\">''</span>;\n","    <span class=\"code-comment\">// add unit if the value is numeric and is one of the following</span>\n","    <span class=\"code-keyword\">if</span> ([<span class=\"code-string\">'width'</span>, <span class=\"code-string\">'height'</span>, <span class=\"code-string\">'top'</span>, <span class=\"code-string\">'right'</span>, <span class=\"code-string\">'bottom'</span>, <span class=\"code-string\">'left'</span>].indexOf(prop) !== <span class=\"code-number\">-1</span> &amp;&amp; isNumeric(styles[prop])) {\n","      unit = <span class=\"code-string\">'px'</span>;\n","    }\n","    element.style[prop] = styles[prop] + unit;\n","  });\n","}\n","\n","<span class=\"code-function\"><span class=\"code-keyword\">function</span> <span class=\"code-title\">attachToScrollParents</span>(<span class=\"code-params\">scrollParent, event, callback, scrollParents</span>) </span>{\n","  <span class=\"code-keyword\">var</span> isBody = scrollParent.nodeName === <span class=\"code-string\">'BODY'</span>;\n","  <span class=\"code-keyword\">var</span> target = isBody ? scrollParent.ownerDocument.defaultView : scrollParent;\n","  target.addEventListener(event, callback, { <span class=\"code-attr\">passive</span>: <span class=\"code-literal\">true</span> });\n","\n","  <span class=\"code-keyword\">if</span> (!isBody) {\n","    attachToScrollParents(getScrollParent(target.parentNode), event, callback, scrollParents);\n","  }\n","  scrollParents.push(target);\n","}\n","\n","<span class=\"code-comment\">/**\n</span>","<span class=\"code-comment\"> * Setup needed event listeners used to update the popper position\n</span>","<span class=\"code-comment\"> * @method\n</span>","<span class=\"code-comment\"> * @memberof Popper.Utils\n</span>","<span class=\"code-comment\"> * @private\n</span>","<span class=\"code-comment\"> */</span>\n","<span class=\"code-function\"><span class=\"code-keyword\">function</span> <span class=\"code-title\">setupEventListeners</span>(<span class=\"code-params\">reference, options, state, updateBound</span>) </span>{\n","  <span class=\"code-comment\">// Resize event listener on window</span>\n","  state.updateBound = updateBound;\n","  getWindow(reference).addEventListener(<span class=\"code-string\">'resize'</span>, state.updateBound, { <span class=\"code-attr\">passive</span>: <span class=\"code-literal\">true</span> });\n","\n","  <span class=\"code-comment\">// Scroll event listener on scroll parents</span>\n","  <span class=\"code-keyword\">var</span> scrollElement = getScrollParent(reference);\n","  attachToScrollParents(scrollElement, <span class=\"code-string\">'scroll'</span>, state.updateBound, state.scrollParents);\n","  state.scrollElement = scrollElement;\n","  state.eventsEnabled = <span class=\"code-literal\">true</span>;\n","\n","  <span class=\"code-keyword\">return</span> state;\n","}\n","\n","<span class=\"code-comment\">// This is here just for backward compatibility with versions lower than v1.10.3</span>\n","<span class=\"code-comment\">// you should import the utilities using named exports, if you want them all use:</span>\n","<span class=\"code-comment\">// ```</span>\n","<span class=\"code-comment\">// import * as PopperUtils from 'popper-utils';</span>\n","<span class=\"code-comment\">// ```</span>\n","<span class=\"code-comment\">// The default export will be removed in the next major version.</span>\n","<span class=\"code-keyword\">var</span> index = {\n","  computeAutoPlacement: computeAutoPlacement,\n","  debounce: debounce,\n","  findIndex: findIndex,\n","  getBordersSize: getBordersSize,\n","  getBoundaries: getBoundaries,\n","  getBoundingClientRect: getBoundingClientRect,\n","  getClientRect: getClientRect,\n","  getOffsetParent: getOffsetParent,\n","  getOffsetRect: getOffsetRect,\n","  getOffsetRectRelativeToArbitraryNode: getOffsetRectRelativeToArbitraryNode,\n","  getOuterSizes: getOuterSizes,\n","  getParentNode: getParentNode,\n","  getPopperOffsets: getPopperOffsets,\n","  getReferenceOffsets: getReferenceOffsets,\n","  getScroll: getScroll,\n","  getScrollParent: getScrollParent,\n","  getStyleComputedProperty: getStyleComputedProperty,\n","  getSupportedPropertyName: getSupportedPropertyName,\n","  getWindowSizes: getWindowSizes,\n","  isFixed: isFixed,\n","  isFunction: isFunction,\n","  isModifierEnabled: isModifierEnabled,\n","  isModifierRequired: isModifierRequired,\n","  isNumeric: isNumeric,\n","  removeEventListeners: removeEventListeners,\n","  runModifiers: runModifiers,\n","  setAttributes: setAttributes,\n","  setStyles: setStyles,\n","  setupEventListeners: setupEventListeners\n","};\n","\n","exports.computeAutoPlacement = computeAutoPlacement;\n","exports.debounce = debounce;\n","exports.findIndex = findIndex;\n","exports.getBordersSize = getBordersSize;\n","exports.getBoundaries = getBoundaries;\n","exports.getBoundingClientRect = getBoundingClientRect;\n","exports.getClientRect = getClientRect;\n","exports.getOffsetParent = getOffsetParent;\n","exports.getOffsetRect = getOffsetRect;\n","exports.getOffsetRectRelativeToArbitraryNode = getOffsetRectRelativeToArbitraryNode;\n","exports.getOuterSizes = getOuterSizes;\n","exports.getParentNode = getParentNode;\n","exports.getPopperOffsets = getPopperOffsets;\n","exports.getReferenceOffsets = getReferenceOffsets;\n","exports.getScroll = getScroll;\n","exports.getScrollParent = getScrollParent;\n","exports.getStyleComputedProperty = getStyleComputedProperty;\n","exports.getSupportedPropertyName = getSupportedPropertyName;\n","exports.getWindowSizes = getWindowSizes;\n","exports.isFixed = isFixed;\n","exports.isFunction = isFunction;\n","exports.isModifierEnabled = isModifierEnabled;\n","exports.isModifierRequired = isModifierRequired;\n","exports.isNumeric = isNumeric;\n","exports.removeEventListeners = removeEventListeners;\n","exports.runModifiers = runModifiers;\n","exports.setAttributes = setAttributes;\n","exports.setStyles = setStyles;\n","exports.setupEventListeners = setupEventListeners;\n","exports[<span class=\"code-string\">'default'</span>] = index;\n","\n","<span class=\"code-built_in\">Object</span>.defineProperty(exports, <span class=\"code-string\">'__esModule'</span>, { <span class=\"code-attr\">value</span>: <span class=\"code-literal\">true</span> });\n","\n","})));\n","<span class=\"code-comment\">//# sourceMappingURL=popper-utils.js.map</span>\n",""]}}}</script></head><body><div id="root"><style data-emotion-css="262b4o">html{box-sizing:border-box;}*,*:before,*:after{box-sizing:inherit;}html,body,#root{height:100%;margin:0;}body{font-family:-apple-system, BlinkMacSystemFont, "Segoe UI", "Roboto", "Oxygen", "Ubuntu", "Cantarell", "Fira Sans", "Droid Sans", "Helvetica Neue", sans-serif;font-size:16px;line-height:1.5;background:white;color:black;}code{font-family:Menlo, Monaco, Lucida Console, Liberation Mono, DejaVu Sans Mono, Bitstream Vera Sans Mono, Courier New, monospace;}th,td{padding:0;}select{font-size:inherit;}#root{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;}</style><style data-emotion-css="1r6h1r6">.code-listing{background:#fbfdff;color:#383a42;}.code-comment,.code-quote{color:#a0a1a7;font-style:italic;}.code-doctag,.code-keyword,.code-link,.code-formula{color:#a626a4;}.code-section,.code-name,.code-selector-tag,.code-deletion,.code-subst{color:#e45649;}.code-literal{color:#0184bb;}.code-string,.code-regexp,.code-addition,.code-attribute,.code-meta-string{color:#50a14f;}.code-built_in,.code-class .code-title{color:#c18401;}.code-attr,.code-variable,.code-template-variable,.code-type,.code-selector-class,.code-selector-attr,.code-selector-pseudo,.code-number{color:#986801;}.code-symbol,.code-bullet,.code-meta,.code-selector-id,.code-title{color:#4078f2;}.code-emphasis{font-style:italic;}.code-strong{font-weight:bold;}</style><style data-emotion-css="1c3h18e">.css-1c3h18e{-webkit-flex:1 0 auto;-ms-flex:1 0 auto;flex:1 0 auto;}</style><div class="css-1c3h18e"><style data-emotion-css="1cfuj1t">.css-1cfuj1t{max-width:940px;padding:0 20px;margin:0 auto;}</style><div class="css-1cfuj1t"><style data-emotion-css="xi606m">.css-xi606m{text-align:center;}</style><header class="css-xi606m"><style data-emotion-css="17kjije">.css-17kjije{font-size:3rem;margin-top:2rem;}</style><h1 class="css-17kjije"><style data-emotion-css="1ydg16i">.css-1ydg16i{color:#000;-webkit-text-decoration:none;text-decoration:none;}</style><a href="/" class="css-1ydg16i">UNPKG</a></h1></header><style data-emotion-css="93o42g">.css-93o42g{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;}@media (max-width:700px){.css-93o42g{-webkit-flex-direction:column-reverse;-ms-flex-direction:column-reverse;flex-direction:column-reverse;-webkit-align-items:flex-start;-webkit-box-align:flex-start;-ms-flex-align:flex-start;align-items:flex-start;}}</style><header class="css-93o42g"><style data-emotion-css="k4kplh">.css-k4kplh{font-size:1.5rem;font-weight:normal;-webkit-flex:1;-ms-flex:1;flex:1;}</style><h1 class="css-k4kplh"><nav><span><style data-emotion-css="xt128v">.css-xt128v{color:#0076ff;-webkit-text-decoration:none;text-decoration:none;}.css-xt128v:hover{-webkit-text-decoration:underline;text-decoration:underline;}</style><a href="/browse/popper.js@1.16.0/" class="css-xt128v">popper.js</a></span><span><style data-emotion-css="lllnmq">.css-lllnmq{padding-left:5px;padding-right:5px;}</style><span class="css-lllnmq">/</span><a href="/browse/popper.js@1.16.0/dist/" class="css-xt128v">dist</a></span><span><span class="css-lllnmq">/</span><a href="/browse/popper.js@1.16.0/dist/umd/" class="css-xt128v">umd</a></span><span><span class="css-lllnmq">/</span><strong>popper-utils.js</strong></span></nav></h1><style data-emotion-css="1nr3dab">.css-1nr3dab{margin-left:20px;}@media (max-width:700px){.css-1nr3dab{margin-left:0;margin-bottom:0;}}</style><p class="css-1nr3dab"><label>Version:<!-- --> <style data-emotion-css="un3bt6">.css-un3bt6{-webkit-appearance:none;-moz-appearance:none;appearance:none;cursor:pointer;padding:4px 24px 4px 8px;font-weight:600;font-size:0.9em;color:#24292e;border:1px solid rgba(27,31,35,.2);border-radius:3px;background-color:#eff3f6;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAKCAYAAAC9vt6cAAAAAXNSR0IArs4c6QAAARFJREFUKBVjZAACNS39RhBNKrh17WI9o4quoT3Dn78HSNUMUs/CzOTI/O7Vi4dCYpJ3/jP+92BkYGAlyiBGhm8MjIxJt65e3MQM0vDu9YvLYmISILYZELOBxHABRkaGr0yMzF23r12YDFIDNgDEePv65SEhEXENBkYGFSAXuyGMjF8Z/jOsvX3tYiFIDwgwQSgIaaijnvj/P8M5IO8HsjiY/f//D4b//88A1SQhywG9jQr09PS4v/1mPAeUUPzP8B8cJowMjL+Bqu6xMQmaXL164AuyDgwDQJLa2qYSP//9vARkCoMVMzK8YeVkNbh+9uxzMB+JwGoASF5Vx0jz/98/18BqmZi171w9D2EjaaYKEwAEK00XQLdJuwAAAABJRU5ErkJggg==);background-position:right 8px center;background-repeat:no-repeat;background-size:auto 25%;}.css-un3bt6:hover{background-color:#e6ebf1;border-color:rgba(27,31,35,.35);}.css-un3bt6:active{background-color:#e9ecef;border-color:rgba(27,31,35,.35);box-shadow:inset 0 0.15em 0.3em rgba(27,31,35,.15);}</style><select name="version" class="css-un3bt6"><option value="0.2.0">0.2.0</option><option value="0.2.1">0.2.1</option><option value="0.2.2">0.2.2</option><option value="0.2.3">0.2.3</option><option value="0.2.4">0.2.4</option><option value="0.2.5">0.2.5</option><option value="0.2.6">0.2.6</option><option value="0.3.0">0.3.0</option><option value="0.3.1">0.3.1</option><option value="0.3.2">0.3.2</option><option value="0.3.3">0.3.3</option><option value="0.3.4">0.3.4</option><option value="0.3.5">0.3.5</option><option value="0.3.6">0.3.6</option><option value="0.3.7">0.3.7</option><option value="0.3.8">0.3.8</option><option value="0.4.0">0.4.0</option><option value="0.4.1">0.4.1</option><option value="0.4.2">0.4.2</option><option value="0.5.0">0.5.0</option><option value="0.5.1">0.5.1</option><option value="0.5.2">0.5.2</option><option value="0.5.3">0.5.3</option><option value="0.6.0">0.6.0</option><option value="0.6.1">0.6.1</option><option value="0.6.2">0.6.2</option><option value="0.6.3">0.6.3</option><option value="0.6.4">0.6.4</option><option value="1.0.0-alpha.1">1.0.0-alpha.1</option><option value="1.0.0-alpha.2">1.0.0-alpha.2</option><option value="1.0.0-alpha.3">1.0.0-alpha.3</option><option value="1.0.0-alpha.4">1.0.0-alpha.4</option><option value="1.0.0-alpha.5">1.0.0-alpha.5</option><option value="1.0.0-alpha.6">1.0.0-alpha.6</option><option value="1.0.0-alpha.7">1.0.0-alpha.7</option><option value="1.0.0-alpha.8">1.0.0-alpha.8</option><option value="1.0.0-beta.1">1.0.0-beta.1</option><option value="1.0.0-beta.2">1.0.0-beta.2</option><option value="1.0.0-beta.3">1.0.0-beta.3</option><option value="1.0.0-beta.4">1.0.0-beta.4</option><option value="1.0.0-beta.5">1.0.0-beta.5</option><option value="1.0.0">1.0.0</option><option value="1.0.1">1.0.1</option><option value="1.0.2">1.0.2</option><option value="1.0.3">1.0.3</option><option value="1.0.4">1.0.4</option><option value="1.0.5">1.0.5</option><option value="1.0.6">1.0.6</option><option value="1.0.7">1.0.7</option><option value="1.0.8">1.0.8</option><option value="1.5.0">1.5.0</option><option value="1.5.1-pre">1.5.1-pre</option><option value="1.5.1-pre.2">1.5.1-pre.2</option><option value="1.5.1">1.5.1</option><option value="1.5.2">1.5.2</option><option value="1.6.0">1.6.0</option><option value="1.7.0">1.7.0</option><option value="1.8.0">1.8.0</option><option value="1.8.1">1.8.1</option><option value="1.8.2">1.8.2</option><option value="1.8.3">1.8.3</option><option value="1.8.4">1.8.4</option><option value="1.8.5">1.8.5</option><option value="1.8.6">1.8.6</option><option value="1.9.0">1.9.0</option><option value="1.9.1">1.9.1</option><option value="1.9.2">1.9.2</option><option value="1.9.3">1.9.3</option><option value="1.9.4">1.9.4</option><option value="1.9.5">1.9.5</option><option value="1.9.6">1.9.6</option><option value="1.9.7">1.9.7</option><option value="1.9.8">1.9.8</option><option value="1.9.9">1.9.9</option><option value="1.10.0">1.10.0</option><option value="1.10.1">1.10.1</option><option value="1.10.2">1.10.2</option><option value="1.10.3">1.10.3</option><option value="1.10.4">1.10.4</option><option value="1.10.5">1.10.5</option><option value="1.10.6">1.10.6</option><option value="1.10.7">1.10.7</option><option value="1.10.8">1.10.8</option><option value="1.11.0">1.11.0</option><option value="1.11.1">1.11.1</option><option value="1.12.0">1.12.0</option><option value="1.12.1">1.12.1</option><option value="1.12.2">1.12.2</option><option value="1.12.3">1.12.3</option><option value="1.12.4">1.12.4</option><option value="1.12.5">1.12.5</option><option value="1.12.6">1.12.6</option><option value="1.12.7">1.12.7</option><option value="1.12.8">1.12.8</option><option value="1.12.9">1.12.9</option><option value="1.13.0-next">1.13.0-next</option><option value="1.13.0-next.1">1.13.0-next.1</option><option value="1.13.0">1.13.0</option><option value="1.14.0">1.14.0</option><option value="1.14.1">1.14.1</option><option value="1.14.2">1.14.2</option><option value="1.14.3">1.14.3</option><option value="1.14.4">1.14.4</option><option value="1.14.5">1.14.5</option><option value="1.14.6">1.14.6</option><option value="1.14.7">1.14.7</option><option value="1.15.0">1.15.0</option><option selected="" value="1.16.0">1.16.0</option><option value="2.0.0-next.1">2.0.0-next.1</option><option value="2.0.0-next.2">2.0.0-next.2</option><option value="2.0.0-next.3">2.0.0-next.3</option><option value="2.0.0-next.4">2.0.0-next.4</option></select></label></p></header></div><style data-emotion-css="107j3ms">.css-107j3ms{max-width:940px;padding:0 20px;margin:0 auto;}@media (max-width:700px){.css-107j3ms{padding:0;margin:0;}}</style><div class="css-107j3ms"><style data-emotion-css="q3frg4">.css-q3frg4{border:1px solid #dfe2e5;border-radius:3px;}@media (max-width:700px){.css-q3frg4{border-right-width:0;border-left-width:0;}}</style><div class="css-q3frg4"><style data-emotion-css="10o5omr">.css-10o5omr{padding:10px;background:#f6f8fa;color:#424242;border:1px solid #d1d5da;border-top-left-radius:3px;border-top-right-radius:3px;margin:-1px -1px 0;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;}@media (max-width:700px){.css-10o5omr{padding-right:20px;padding-left:20px;}}</style><div class="css-10o5omr"><span>36.7 kB</span> <span>JavaScript</span> <style data-emotion-css="12cxnkg">.css-12cxnkg{display:inline-block;-webkit-text-decoration:none;text-decoration:none;padding:2px 8px;font-weight:600;font-size:0.9rem;color:#24292e;background-color:#eff3f6;border:1px solid rgba(27,31,35,.2);border-radius:3px;}.css-12cxnkg:hover{background-color:#e6ebf1;border-color:rgba(27,31,35,.35);}.css-12cxnkg:active{background-color:#e9ecef;border-color:rgba(27,31,35,.35);box-shadow:inset 0 0.15em 0.3em rgba(27,31,35,.15);}</style><a title="popper-utils.js" href="/popper.js@1.16.0/dist/umd/popper-utils.js" class="css-12cxnkg">View Raw</a></div><style data-emotion-css="1i31ihw">.css-1i31ihw{overflow-x:auto;overflow-y:hidden;padding-top:5px;padding-bottom:5px;}</style><div class="code-listing css-1i31ihw"><style data-emotion-css="173nir8">.css-173nir8{border:none;border-collapse:collapse;border-spacing:0;}</style><table class="css-173nir8"><tbody><tr><style data-emotion-css="a4x74f">.css-a4x74f{padding-left:10px;padding-right:10px;color:rgba(27,31,35,.3);text-align:right;vertical-align:top;width:1%;min-width:50px;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;}</style><td id="L1" class="css-a4x74f"><span>1</span></td><style data-emotion-css="1dcdqdg">.css-1dcdqdg{padding-left:10px;padding-right:10px;color:#24292e;white-space:pre;}</style><td id="LC1" class="css-1dcdqdg"><code><span class="code-comment">/**!
</span></code></td></tr><tr><td id="L2" class="css-a4x74f"><span>2</span></td><td id="LC2" class="css-1dcdqdg"><code><span class="code-comment"> * @fileOverview Kickass library to create and place poppers near their reference elements.
</span></code></td></tr><tr><td id="L3" class="css-a4x74f"><span>3</span></td><td id="LC3" class="css-1dcdqdg"><code><span class="code-comment"> * @version 1.16.0
</span></code></td></tr><tr><td id="L4" class="css-a4x74f"><span>4</span></td><td id="LC4" class="css-1dcdqdg"><code><span class="code-comment"> * @license
</span></code></td></tr><tr><td id="L5" class="css-a4x74f"><span>5</span></td><td id="LC5" class="css-1dcdqdg"><code><span class="code-comment"> * Copyright (c) 2016 Federico Zivolo and contributors
</span></code></td></tr><tr><td id="L6" class="css-a4x74f"><span>6</span></td><td id="LC6" class="css-1dcdqdg"><code><span class="code-comment"> *
</span></code></td></tr><tr><td id="L7" class="css-a4x74f"><span>7</span></td><td id="LC7" class="css-1dcdqdg"><code><span class="code-comment"> * Permission is hereby granted, free of charge, to any person obtaining a copy
</span></code></td></tr><tr><td id="L8" class="css-a4x74f"><span>8</span></td><td id="LC8" class="css-1dcdqdg"><code><span class="code-comment"> * of this software and associated documentation files (the "Software"), to deal
</span></code></td></tr><tr><td id="L9" class="css-a4x74f"><span>9</span></td><td id="LC9" class="css-1dcdqdg"><code><span class="code-comment"> * in the Software without restriction, including without limitation the rights
</span></code></td></tr><tr><td id="L10" class="css-a4x74f"><span>10</span></td><td id="LC10" class="css-1dcdqdg"><code><span class="code-comment"> * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
</span></code></td></tr><tr><td id="L11" class="css-a4x74f"><span>11</span></td><td id="LC11" class="css-1dcdqdg"><code><span class="code-comment"> * copies of the Software, and to permit persons to whom the Software is
</span></code></td></tr><tr><td id="L12" class="css-a4x74f"><span>12</span></td><td id="LC12" class="css-1dcdqdg"><code><span class="code-comment"> * furnished to do so, subject to the following conditions:
</span></code></td></tr><tr><td id="L13" class="css-a4x74f"><span>13</span></td><td id="LC13" class="css-1dcdqdg"><code><span class="code-comment"> *
</span></code></td></tr><tr><td id="L14" class="css-a4x74f"><span>14</span></td><td id="LC14" class="css-1dcdqdg"><code><span class="code-comment"> * The above copyright notice and this permission notice shall be included in all
</span></code></td></tr><tr><td id="L15" class="css-a4x74f"><span>15</span></td><td id="LC15" class="css-1dcdqdg"><code><span class="code-comment"> * copies or substantial portions of the Software.
</span></code></td></tr><tr><td id="L16" class="css-a4x74f"><span>16</span></td><td id="LC16" class="css-1dcdqdg"><code><span class="code-comment"> *
</span></code></td></tr><tr><td id="L17" class="css-a4x74f"><span>17</span></td><td id="LC17" class="css-1dcdqdg"><code><span class="code-comment"> * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
</span></code></td></tr><tr><td id="L18" class="css-a4x74f"><span>18</span></td><td id="LC18" class="css-1dcdqdg"><code><span class="code-comment"> * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
</span></code></td></tr><tr><td id="L19" class="css-a4x74f"><span>19</span></td><td id="LC19" class="css-1dcdqdg"><code><span class="code-comment"> * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
</span></code></td></tr><tr><td id="L20" class="css-a4x74f"><span>20</span></td><td id="LC20" class="css-1dcdqdg"><code><span class="code-comment"> * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
</span></code></td></tr><tr><td id="L21" class="css-a4x74f"><span>21</span></td><td id="LC21" class="css-1dcdqdg"><code><span class="code-comment"> * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
</span></code></td></tr><tr><td id="L22" class="css-a4x74f"><span>22</span></td><td id="LC22" class="css-1dcdqdg"><code><span class="code-comment"> * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
</span></code></td></tr><tr><td id="L23" class="css-a4x74f"><span>23</span></td><td id="LC23" class="css-1dcdqdg"><code><span class="code-comment"> * SOFTWARE.
</span></code></td></tr><tr><td id="L24" class="css-a4x74f"><span>24</span></td><td id="LC24" class="css-1dcdqdg"><code><span class="code-comment"> */</span>
</code></td></tr><tr><td id="L25" class="css-a4x74f"><span>25</span></td><td id="LC25" class="css-1dcdqdg"><code>(<span class="code-function"><span class="code-keyword">function</span> (<span class="code-params">global, factory</span>) </span>{
</code></td></tr><tr><td id="L26" class="css-a4x74f"><span>26</span></td><td id="LC26" class="css-1dcdqdg"><code>	<span class="code-keyword">typeof</span> exports === <span class="code-string">'object'</span> &amp;&amp; <span class="code-keyword">typeof</span> <span class="code-built_in">module</span> !== <span class="code-string">'undefined'</span> ? factory(exports) :
</code></td></tr><tr><td id="L27" class="css-a4x74f"><span>27</span></td><td id="LC27" class="css-1dcdqdg"><code>	<span class="code-keyword">typeof</span> define === <span class="code-string">'function'</span> &amp;&amp; define.amd ? define([<span class="code-string">'exports'</span>], factory) :
</code></td></tr><tr><td id="L28" class="css-a4x74f"><span>28</span></td><td id="LC28" class="css-1dcdqdg"><code>	(factory((global.PopperUtils = {})));
</code></td></tr><tr><td id="L29" class="css-a4x74f"><span>29</span></td><td id="LC29" class="css-1dcdqdg"><code>}(<span class="code-keyword">this</span>, (<span class="code-function"><span class="code-keyword">function</span> (<span class="code-params">exports</span>) </span>{ <span class="code-string">'use strict'</span>;
</code></td></tr><tr><td id="L30" class="css-a4x74f"><span>30</span></td><td id="LC30" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L31" class="css-a4x74f"><span>31</span></td><td id="LC31" class="css-1dcdqdg"><code><span class="code-comment">/**
</span></code></td></tr><tr><td id="L32" class="css-a4x74f"><span>32</span></td><td id="LC32" class="css-1dcdqdg"><code><span class="code-comment"> * Get CSS computed property of the given element
</span></code></td></tr><tr><td id="L33" class="css-a4x74f"><span>33</span></td><td id="LC33" class="css-1dcdqdg"><code><span class="code-comment"> * @method
</span></code></td></tr><tr><td id="L34" class="css-a4x74f"><span>34</span></td><td id="LC34" class="css-1dcdqdg"><code><span class="code-comment"> * @memberof Popper.Utils
</span></code></td></tr><tr><td id="L35" class="css-a4x74f"><span>35</span></td><td id="LC35" class="css-1dcdqdg"><code><span class="code-comment"> * @argument {Eement} element
</span></code></td></tr><tr><td id="L36" class="css-a4x74f"><span>36</span></td><td id="LC36" class="css-1dcdqdg"><code><span class="code-comment"> * @argument {String} property
</span></code></td></tr><tr><td id="L37" class="css-a4x74f"><span>37</span></td><td id="LC37" class="css-1dcdqdg"><code><span class="code-comment"> */</span>
</code></td></tr><tr><td id="L38" class="css-a4x74f"><span>38</span></td><td id="LC38" class="css-1dcdqdg"><code><span class="code-function"><span class="code-keyword">function</span> <span class="code-title">getStyleComputedProperty</span>(<span class="code-params">element, property</span>) </span>{
</code></td></tr><tr><td id="L39" class="css-a4x74f"><span>39</span></td><td id="LC39" class="css-1dcdqdg"><code>  <span class="code-keyword">if</span> (element.nodeType !== <span class="code-number">1</span>) {
</code></td></tr><tr><td id="L40" class="css-a4x74f"><span>40</span></td><td id="LC40" class="css-1dcdqdg"><code>    <span class="code-keyword">return</span> [];
</code></td></tr><tr><td id="L41" class="css-a4x74f"><span>41</span></td><td id="LC41" class="css-1dcdqdg"><code>  }
</code></td></tr><tr><td id="L42" class="css-a4x74f"><span>42</span></td><td id="LC42" class="css-1dcdqdg"><code>  <span class="code-comment">// <span class="code-doctag">NOTE:</span> 1 DOM access here</span>
</code></td></tr><tr><td id="L43" class="css-a4x74f"><span>43</span></td><td id="LC43" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> <span class="code-built_in">window</span> = element.ownerDocument.defaultView;
</code></td></tr><tr><td id="L44" class="css-a4x74f"><span>44</span></td><td id="LC44" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> css = <span class="code-built_in">window</span>.getComputedStyle(element, <span class="code-literal">null</span>);
</code></td></tr><tr><td id="L45" class="css-a4x74f"><span>45</span></td><td id="LC45" class="css-1dcdqdg"><code>  <span class="code-keyword">return</span> property ? css[property] : css;
</code></td></tr><tr><td id="L46" class="css-a4x74f"><span>46</span></td><td id="LC46" class="css-1dcdqdg"><code>}
</code></td></tr><tr><td id="L47" class="css-a4x74f"><span>47</span></td><td id="LC47" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L48" class="css-a4x74f"><span>48</span></td><td id="LC48" class="css-1dcdqdg"><code><span class="code-comment">/**
</span></code></td></tr><tr><td id="L49" class="css-a4x74f"><span>49</span></td><td id="LC49" class="css-1dcdqdg"><code><span class="code-comment"> * Returns the parentNode or the host of the element
</span></code></td></tr><tr><td id="L50" class="css-a4x74f"><span>50</span></td><td id="LC50" class="css-1dcdqdg"><code><span class="code-comment"> * @method
</span></code></td></tr><tr><td id="L51" class="css-a4x74f"><span>51</span></td><td id="LC51" class="css-1dcdqdg"><code><span class="code-comment"> * @memberof Popper.Utils
</span></code></td></tr><tr><td id="L52" class="css-a4x74f"><span>52</span></td><td id="LC52" class="css-1dcdqdg"><code><span class="code-comment"> * @argument {Element} element
</span></code></td></tr><tr><td id="L53" class="css-a4x74f"><span>53</span></td><td id="LC53" class="css-1dcdqdg"><code><span class="code-comment"> * @returns {Element} parent
</span></code></td></tr><tr><td id="L54" class="css-a4x74f"><span>54</span></td><td id="LC54" class="css-1dcdqdg"><code><span class="code-comment"> */</span>
</code></td></tr><tr><td id="L55" class="css-a4x74f"><span>55</span></td><td id="LC55" class="css-1dcdqdg"><code><span class="code-function"><span class="code-keyword">function</span> <span class="code-title">getParentNode</span>(<span class="code-params">element</span>) </span>{
</code></td></tr><tr><td id="L56" class="css-a4x74f"><span>56</span></td><td id="LC56" class="css-1dcdqdg"><code>  <span class="code-keyword">if</span> (element.nodeName === <span class="code-string">'HTML'</span>) {
</code></td></tr><tr><td id="L57" class="css-a4x74f"><span>57</span></td><td id="LC57" class="css-1dcdqdg"><code>    <span class="code-keyword">return</span> element;
</code></td></tr><tr><td id="L58" class="css-a4x74f"><span>58</span></td><td id="LC58" class="css-1dcdqdg"><code>  }
</code></td></tr><tr><td id="L59" class="css-a4x74f"><span>59</span></td><td id="LC59" class="css-1dcdqdg"><code>  <span class="code-keyword">return</span> element.parentNode || element.host;
</code></td></tr><tr><td id="L60" class="css-a4x74f"><span>60</span></td><td id="LC60" class="css-1dcdqdg"><code>}
</code></td></tr><tr><td id="L61" class="css-a4x74f"><span>61</span></td><td id="LC61" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L62" class="css-a4x74f"><span>62</span></td><td id="LC62" class="css-1dcdqdg"><code><span class="code-comment">/**
</span></code></td></tr><tr><td id="L63" class="css-a4x74f"><span>63</span></td><td id="LC63" class="css-1dcdqdg"><code><span class="code-comment"> * Returns the scrolling parent of the given element
</span></code></td></tr><tr><td id="L64" class="css-a4x74f"><span>64</span></td><td id="LC64" class="css-1dcdqdg"><code><span class="code-comment"> * @method
</span></code></td></tr><tr><td id="L65" class="css-a4x74f"><span>65</span></td><td id="LC65" class="css-1dcdqdg"><code><span class="code-comment"> * @memberof Popper.Utils
</span></code></td></tr><tr><td id="L66" class="css-a4x74f"><span>66</span></td><td id="LC66" class="css-1dcdqdg"><code><span class="code-comment"> * @argument {Element} element
</span></code></td></tr><tr><td id="L67" class="css-a4x74f"><span>67</span></td><td id="LC67" class="css-1dcdqdg"><code><span class="code-comment"> * @returns {Element} scroll parent
</span></code></td></tr><tr><td id="L68" class="css-a4x74f"><span>68</span></td><td id="LC68" class="css-1dcdqdg"><code><span class="code-comment"> */</span>
</code></td></tr><tr><td id="L69" class="css-a4x74f"><span>69</span></td><td id="LC69" class="css-1dcdqdg"><code><span class="code-function"><span class="code-keyword">function</span> <span class="code-title">getScrollParent</span>(<span class="code-params">element</span>) </span>{
</code></td></tr><tr><td id="L70" class="css-a4x74f"><span>70</span></td><td id="LC70" class="css-1dcdqdg"><code>  <span class="code-comment">// Return body, `getScroll` will take care to get the correct `scrollTop` from it</span>
</code></td></tr><tr><td id="L71" class="css-a4x74f"><span>71</span></td><td id="LC71" class="css-1dcdqdg"><code>  <span class="code-keyword">if</span> (!element) {
</code></td></tr><tr><td id="L72" class="css-a4x74f"><span>72</span></td><td id="LC72" class="css-1dcdqdg"><code>    <span class="code-keyword">return</span> <span class="code-built_in">document</span>.body;
</code></td></tr><tr><td id="L73" class="css-a4x74f"><span>73</span></td><td id="LC73" class="css-1dcdqdg"><code>  }
</code></td></tr><tr><td id="L74" class="css-a4x74f"><span>74</span></td><td id="LC74" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L75" class="css-a4x74f"><span>75</span></td><td id="LC75" class="css-1dcdqdg"><code>  <span class="code-keyword">switch</span> (element.nodeName) {
</code></td></tr><tr><td id="L76" class="css-a4x74f"><span>76</span></td><td id="LC76" class="css-1dcdqdg"><code>    <span class="code-keyword">case</span> <span class="code-string">'HTML'</span>:
</code></td></tr><tr><td id="L77" class="css-a4x74f"><span>77</span></td><td id="LC77" class="css-1dcdqdg"><code>    <span class="code-keyword">case</span> <span class="code-string">'BODY'</span>:
</code></td></tr><tr><td id="L78" class="css-a4x74f"><span>78</span></td><td id="LC78" class="css-1dcdqdg"><code>      <span class="code-keyword">return</span> element.ownerDocument.body;
</code></td></tr><tr><td id="L79" class="css-a4x74f"><span>79</span></td><td id="LC79" class="css-1dcdqdg"><code>    <span class="code-keyword">case</span> <span class="code-string">'#document'</span>:
</code></td></tr><tr><td id="L80" class="css-a4x74f"><span>80</span></td><td id="LC80" class="css-1dcdqdg"><code>      <span class="code-keyword">return</span> element.body;
</code></td></tr><tr><td id="L81" class="css-a4x74f"><span>81</span></td><td id="LC81" class="css-1dcdqdg"><code>  }
</code></td></tr><tr><td id="L82" class="css-a4x74f"><span>82</span></td><td id="LC82" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L83" class="css-a4x74f"><span>83</span></td><td id="LC83" class="css-1dcdqdg"><code>  <span class="code-comment">// Firefox want us to check `-x` and `-y` variations as well</span>
</code></td></tr><tr><td id="L84" class="css-a4x74f"><span>84</span></td><td id="LC84" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L85" class="css-a4x74f"><span>85</span></td><td id="LC85" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> _getStyleComputedProp = getStyleComputedProperty(element),
</code></td></tr><tr><td id="L86" class="css-a4x74f"><span>86</span></td><td id="LC86" class="css-1dcdqdg"><code>      overflow = _getStyleComputedProp.overflow,
</code></td></tr><tr><td id="L87" class="css-a4x74f"><span>87</span></td><td id="LC87" class="css-1dcdqdg"><code>      overflowX = _getStyleComputedProp.overflowX,
</code></td></tr><tr><td id="L88" class="css-a4x74f"><span>88</span></td><td id="LC88" class="css-1dcdqdg"><code>      overflowY = _getStyleComputedProp.overflowY;
</code></td></tr><tr><td id="L89" class="css-a4x74f"><span>89</span></td><td id="LC89" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L90" class="css-a4x74f"><span>90</span></td><td id="LC90" class="css-1dcdqdg"><code>  <span class="code-keyword">if</span> (<span class="code-regexp">/(auto|scroll|overlay)/</span>.test(overflow + overflowY + overflowX)) {
</code></td></tr><tr><td id="L91" class="css-a4x74f"><span>91</span></td><td id="LC91" class="css-1dcdqdg"><code>    <span class="code-keyword">return</span> element;
</code></td></tr><tr><td id="L92" class="css-a4x74f"><span>92</span></td><td id="LC92" class="css-1dcdqdg"><code>  }
</code></td></tr><tr><td id="L93" class="css-a4x74f"><span>93</span></td><td id="LC93" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L94" class="css-a4x74f"><span>94</span></td><td id="LC94" class="css-1dcdqdg"><code>  <span class="code-keyword">return</span> getScrollParent(getParentNode(element));
</code></td></tr><tr><td id="L95" class="css-a4x74f"><span>95</span></td><td id="LC95" class="css-1dcdqdg"><code>}
</code></td></tr><tr><td id="L96" class="css-a4x74f"><span>96</span></td><td id="LC96" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L97" class="css-a4x74f"><span>97</span></td><td id="LC97" class="css-1dcdqdg"><code><span class="code-comment">/**
</span></code></td></tr><tr><td id="L98" class="css-a4x74f"><span>98</span></td><td id="LC98" class="css-1dcdqdg"><code><span class="code-comment"> * Returns the reference node of the reference object, or the reference object itself.
</span></code></td></tr><tr><td id="L99" class="css-a4x74f"><span>99</span></td><td id="LC99" class="css-1dcdqdg"><code><span class="code-comment"> * @method
</span></code></td></tr><tr><td id="L100" class="css-a4x74f"><span>100</span></td><td id="LC100" class="css-1dcdqdg"><code><span class="code-comment"> * @memberof Popper.Utils
</span></code></td></tr><tr><td id="L101" class="css-a4x74f"><span>101</span></td><td id="LC101" class="css-1dcdqdg"><code><span class="code-comment"> * @param {Element|Object} reference - the reference element (the popper will be relative to this)
</span></code></td></tr><tr><td id="L102" class="css-a4x74f"><span>102</span></td><td id="LC102" class="css-1dcdqdg"><code><span class="code-comment"> * @returns {Element} parent
</span></code></td></tr><tr><td id="L103" class="css-a4x74f"><span>103</span></td><td id="LC103" class="css-1dcdqdg"><code><span class="code-comment"> */</span>
</code></td></tr><tr><td id="L104" class="css-a4x74f"><span>104</span></td><td id="LC104" class="css-1dcdqdg"><code><span class="code-function"><span class="code-keyword">function</span> <span class="code-title">getReferenceNode</span>(<span class="code-params">reference</span>) </span>{
</code></td></tr><tr><td id="L105" class="css-a4x74f"><span>105</span></td><td id="LC105" class="css-1dcdqdg"><code>  <span class="code-keyword">return</span> reference &amp;&amp; reference.referenceNode ? reference.referenceNode : reference;
</code></td></tr><tr><td id="L106" class="css-a4x74f"><span>106</span></td><td id="LC106" class="css-1dcdqdg"><code>}
</code></td></tr><tr><td id="L107" class="css-a4x74f"><span>107</span></td><td id="LC107" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L108" class="css-a4x74f"><span>108</span></td><td id="LC108" class="css-1dcdqdg"><code><span class="code-keyword">var</span> isBrowser = <span class="code-keyword">typeof</span> <span class="code-built_in">window</span> !== <span class="code-string">'undefined'</span> &amp;&amp; <span class="code-keyword">typeof</span> <span class="code-built_in">document</span> !== <span class="code-string">'undefined'</span> &amp;&amp; <span class="code-keyword">typeof</span> navigator !== <span class="code-string">'undefined'</span>;
</code></td></tr><tr><td id="L109" class="css-a4x74f"><span>109</span></td><td id="LC109" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L110" class="css-a4x74f"><span>110</span></td><td id="LC110" class="css-1dcdqdg"><code><span class="code-keyword">var</span> isIE11 = isBrowser &amp;&amp; !!(<span class="code-built_in">window</span>.MSInputMethodContext &amp;&amp; <span class="code-built_in">document</span>.documentMode);
</code></td></tr><tr><td id="L111" class="css-a4x74f"><span>111</span></td><td id="LC111" class="css-1dcdqdg"><code><span class="code-keyword">var</span> isIE10 = isBrowser &amp;&amp; <span class="code-regexp">/MSIE 10/</span>.test(navigator.userAgent);
</code></td></tr><tr><td id="L112" class="css-a4x74f"><span>112</span></td><td id="LC112" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L113" class="css-a4x74f"><span>113</span></td><td id="LC113" class="css-1dcdqdg"><code><span class="code-comment">/**
</span></code></td></tr><tr><td id="L114" class="css-a4x74f"><span>114</span></td><td id="LC114" class="css-1dcdqdg"><code><span class="code-comment"> * Determines if the browser is Internet Explorer
</span></code></td></tr><tr><td id="L115" class="css-a4x74f"><span>115</span></td><td id="LC115" class="css-1dcdqdg"><code><span class="code-comment"> * @method
</span></code></td></tr><tr><td id="L116" class="css-a4x74f"><span>116</span></td><td id="LC116" class="css-1dcdqdg"><code><span class="code-comment"> * @memberof Popper.Utils
</span></code></td></tr><tr><td id="L117" class="css-a4x74f"><span>117</span></td><td id="LC117" class="css-1dcdqdg"><code><span class="code-comment"> * @param {Number} version to check
</span></code></td></tr><tr><td id="L118" class="css-a4x74f"><span>118</span></td><td id="LC118" class="css-1dcdqdg"><code><span class="code-comment"> * @returns {Boolean} isIE
</span></code></td></tr><tr><td id="L119" class="css-a4x74f"><span>119</span></td><td id="LC119" class="css-1dcdqdg"><code><span class="code-comment"> */</span>
</code></td></tr><tr><td id="L120" class="css-a4x74f"><span>120</span></td><td id="LC120" class="css-1dcdqdg"><code><span class="code-function"><span class="code-keyword">function</span> <span class="code-title">isIE</span>(<span class="code-params">version</span>) </span>{
</code></td></tr><tr><td id="L121" class="css-a4x74f"><span>121</span></td><td id="LC121" class="css-1dcdqdg"><code>  <span class="code-keyword">if</span> (version === <span class="code-number">11</span>) {
</code></td></tr><tr><td id="L122" class="css-a4x74f"><span>122</span></td><td id="LC122" class="css-1dcdqdg"><code>    <span class="code-keyword">return</span> isIE11;
</code></td></tr><tr><td id="L123" class="css-a4x74f"><span>123</span></td><td id="LC123" class="css-1dcdqdg"><code>  }
</code></td></tr><tr><td id="L124" class="css-a4x74f"><span>124</span></td><td id="LC124" class="css-1dcdqdg"><code>  <span class="code-keyword">if</span> (version === <span class="code-number">10</span>) {
</code></td></tr><tr><td id="L125" class="css-a4x74f"><span>125</span></td><td id="LC125" class="css-1dcdqdg"><code>    <span class="code-keyword">return</span> isIE10;
</code></td></tr><tr><td id="L126" class="css-a4x74f"><span>126</span></td><td id="LC126" class="css-1dcdqdg"><code>  }
</code></td></tr><tr><td id="L127" class="css-a4x74f"><span>127</span></td><td id="LC127" class="css-1dcdqdg"><code>  <span class="code-keyword">return</span> isIE11 || isIE10;
</code></td></tr><tr><td id="L128" class="css-a4x74f"><span>128</span></td><td id="LC128" class="css-1dcdqdg"><code>}
</code></td></tr><tr><td id="L129" class="css-a4x74f"><span>129</span></td><td id="LC129" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L130" class="css-a4x74f"><span>130</span></td><td id="LC130" class="css-1dcdqdg"><code><span class="code-comment">/**
</span></code></td></tr><tr><td id="L131" class="css-a4x74f"><span>131</span></td><td id="LC131" class="css-1dcdqdg"><code><span class="code-comment"> * Returns the offset parent of the given element
</span></code></td></tr><tr><td id="L132" class="css-a4x74f"><span>132</span></td><td id="LC132" class="css-1dcdqdg"><code><span class="code-comment"> * @method
</span></code></td></tr><tr><td id="L133" class="css-a4x74f"><span>133</span></td><td id="LC133" class="css-1dcdqdg"><code><span class="code-comment"> * @memberof Popper.Utils
</span></code></td></tr><tr><td id="L134" class="css-a4x74f"><span>134</span></td><td id="LC134" class="css-1dcdqdg"><code><span class="code-comment"> * @argument {Element} element
</span></code></td></tr><tr><td id="L135" class="css-a4x74f"><span>135</span></td><td id="LC135" class="css-1dcdqdg"><code><span class="code-comment"> * @returns {Element} offset parent
</span></code></td></tr><tr><td id="L136" class="css-a4x74f"><span>136</span></td><td id="LC136" class="css-1dcdqdg"><code><span class="code-comment"> */</span>
</code></td></tr><tr><td id="L137" class="css-a4x74f"><span>137</span></td><td id="LC137" class="css-1dcdqdg"><code><span class="code-function"><span class="code-keyword">function</span> <span class="code-title">getOffsetParent</span>(<span class="code-params">element</span>) </span>{
</code></td></tr><tr><td id="L138" class="css-a4x74f"><span>138</span></td><td id="LC138" class="css-1dcdqdg"><code>  <span class="code-keyword">if</span> (!element) {
</code></td></tr><tr><td id="L139" class="css-a4x74f"><span>139</span></td><td id="LC139" class="css-1dcdqdg"><code>    <span class="code-keyword">return</span> <span class="code-built_in">document</span>.documentElement;
</code></td></tr><tr><td id="L140" class="css-a4x74f"><span>140</span></td><td id="LC140" class="css-1dcdqdg"><code>  }
</code></td></tr><tr><td id="L141" class="css-a4x74f"><span>141</span></td><td id="LC141" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L142" class="css-a4x74f"><span>142</span></td><td id="LC142" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> noOffsetParent = isIE(<span class="code-number">10</span>) ? <span class="code-built_in">document</span>.body : <span class="code-literal">null</span>;
</code></td></tr><tr><td id="L143" class="css-a4x74f"><span>143</span></td><td id="LC143" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L144" class="css-a4x74f"><span>144</span></td><td id="LC144" class="css-1dcdqdg"><code>  <span class="code-comment">// <span class="code-doctag">NOTE:</span> 1 DOM access here</span>
</code></td></tr><tr><td id="L145" class="css-a4x74f"><span>145</span></td><td id="LC145" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> offsetParent = element.offsetParent || <span class="code-literal">null</span>;
</code></td></tr><tr><td id="L146" class="css-a4x74f"><span>146</span></td><td id="LC146" class="css-1dcdqdg"><code>  <span class="code-comment">// Skip hidden elements which don't have an offsetParent</span>
</code></td></tr><tr><td id="L147" class="css-a4x74f"><span>147</span></td><td id="LC147" class="css-1dcdqdg"><code>  <span class="code-keyword">while</span> (offsetParent === noOffsetParent &amp;&amp; element.nextElementSibling) {
</code></td></tr><tr><td id="L148" class="css-a4x74f"><span>148</span></td><td id="LC148" class="css-1dcdqdg"><code>    offsetParent = (element = element.nextElementSibling).offsetParent;
</code></td></tr><tr><td id="L149" class="css-a4x74f"><span>149</span></td><td id="LC149" class="css-1dcdqdg"><code>  }
</code></td></tr><tr><td id="L150" class="css-a4x74f"><span>150</span></td><td id="LC150" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L151" class="css-a4x74f"><span>151</span></td><td id="LC151" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> nodeName = offsetParent &amp;&amp; offsetParent.nodeName;
</code></td></tr><tr><td id="L152" class="css-a4x74f"><span>152</span></td><td id="LC152" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L153" class="css-a4x74f"><span>153</span></td><td id="LC153" class="css-1dcdqdg"><code>  <span class="code-keyword">if</span> (!nodeName || nodeName === <span class="code-string">'BODY'</span> || nodeName === <span class="code-string">'HTML'</span>) {
</code></td></tr><tr><td id="L154" class="css-a4x74f"><span>154</span></td><td id="LC154" class="css-1dcdqdg"><code>    <span class="code-keyword">return</span> element ? element.ownerDocument.documentElement : <span class="code-built_in">document</span>.documentElement;
</code></td></tr><tr><td id="L155" class="css-a4x74f"><span>155</span></td><td id="LC155" class="css-1dcdqdg"><code>  }
</code></td></tr><tr><td id="L156" class="css-a4x74f"><span>156</span></td><td id="LC156" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L157" class="css-a4x74f"><span>157</span></td><td id="LC157" class="css-1dcdqdg"><code>  <span class="code-comment">// .offsetParent will return the closest TH, TD or TABLE in case</span>
</code></td></tr><tr><td id="L158" class="css-a4x74f"><span>158</span></td><td id="LC158" class="css-1dcdqdg"><code>  <span class="code-comment">// no offsetParent is present, I hate this job...</span>
</code></td></tr><tr><td id="L159" class="css-a4x74f"><span>159</span></td><td id="LC159" class="css-1dcdqdg"><code>  <span class="code-keyword">if</span> ([<span class="code-string">'TH'</span>, <span class="code-string">'TD'</span>, <span class="code-string">'TABLE'</span>].indexOf(offsetParent.nodeName) !== <span class="code-number">-1</span> &amp;&amp; getStyleComputedProperty(offsetParent, <span class="code-string">'position'</span>) === <span class="code-string">'static'</span>) {
</code></td></tr><tr><td id="L160" class="css-a4x74f"><span>160</span></td><td id="LC160" class="css-1dcdqdg"><code>    <span class="code-keyword">return</span> getOffsetParent(offsetParent);
</code></td></tr><tr><td id="L161" class="css-a4x74f"><span>161</span></td><td id="LC161" class="css-1dcdqdg"><code>  }
</code></td></tr><tr><td id="L162" class="css-a4x74f"><span>162</span></td><td id="LC162" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L163" class="css-a4x74f"><span>163</span></td><td id="LC163" class="css-1dcdqdg"><code>  <span class="code-keyword">return</span> offsetParent;
</code></td></tr><tr><td id="L164" class="css-a4x74f"><span>164</span></td><td id="LC164" class="css-1dcdqdg"><code>}
</code></td></tr><tr><td id="L165" class="css-a4x74f"><span>165</span></td><td id="LC165" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L166" class="css-a4x74f"><span>166</span></td><td id="LC166" class="css-1dcdqdg"><code><span class="code-function"><span class="code-keyword">function</span> <span class="code-title">isOffsetContainer</span>(<span class="code-params">element</span>) </span>{
</code></td></tr><tr><td id="L167" class="css-a4x74f"><span>167</span></td><td id="LC167" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> nodeName = element.nodeName;
</code></td></tr><tr><td id="L168" class="css-a4x74f"><span>168</span></td><td id="LC168" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L169" class="css-a4x74f"><span>169</span></td><td id="LC169" class="css-1dcdqdg"><code>  <span class="code-keyword">if</span> (nodeName === <span class="code-string">'BODY'</span>) {
</code></td></tr><tr><td id="L170" class="css-a4x74f"><span>170</span></td><td id="LC170" class="css-1dcdqdg"><code>    <span class="code-keyword">return</span> <span class="code-literal">false</span>;
</code></td></tr><tr><td id="L171" class="css-a4x74f"><span>171</span></td><td id="LC171" class="css-1dcdqdg"><code>  }
</code></td></tr><tr><td id="L172" class="css-a4x74f"><span>172</span></td><td id="LC172" class="css-1dcdqdg"><code>  <span class="code-keyword">return</span> nodeName === <span class="code-string">'HTML'</span> || getOffsetParent(element.firstElementChild) === element;
</code></td></tr><tr><td id="L173" class="css-a4x74f"><span>173</span></td><td id="LC173" class="css-1dcdqdg"><code>}
</code></td></tr><tr><td id="L174" class="css-a4x74f"><span>174</span></td><td id="LC174" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L175" class="css-a4x74f"><span>175</span></td><td id="LC175" class="css-1dcdqdg"><code><span class="code-comment">/**
</span></code></td></tr><tr><td id="L176" class="css-a4x74f"><span>176</span></td><td id="LC176" class="css-1dcdqdg"><code><span class="code-comment"> * Finds the root node (document, shadowDOM root) of the given element
</span></code></td></tr><tr><td id="L177" class="css-a4x74f"><span>177</span></td><td id="LC177" class="css-1dcdqdg"><code><span class="code-comment"> * @method
</span></code></td></tr><tr><td id="L178" class="css-a4x74f"><span>178</span></td><td id="LC178" class="css-1dcdqdg"><code><span class="code-comment"> * @memberof Popper.Utils
</span></code></td></tr><tr><td id="L179" class="css-a4x74f"><span>179</span></td><td id="LC179" class="css-1dcdqdg"><code><span class="code-comment"> * @argument {Element} node
</span></code></td></tr><tr><td id="L180" class="css-a4x74f"><span>180</span></td><td id="LC180" class="css-1dcdqdg"><code><span class="code-comment"> * @returns {Element} root node
</span></code></td></tr><tr><td id="L181" class="css-a4x74f"><span>181</span></td><td id="LC181" class="css-1dcdqdg"><code><span class="code-comment"> */</span>
</code></td></tr><tr><td id="L182" class="css-a4x74f"><span>182</span></td><td id="LC182" class="css-1dcdqdg"><code><span class="code-function"><span class="code-keyword">function</span> <span class="code-title">getRoot</span>(<span class="code-params">node</span>) </span>{
</code></td></tr><tr><td id="L183" class="css-a4x74f"><span>183</span></td><td id="LC183" class="css-1dcdqdg"><code>  <span class="code-keyword">if</span> (node.parentNode !== <span class="code-literal">null</span>) {
</code></td></tr><tr><td id="L184" class="css-a4x74f"><span>184</span></td><td id="LC184" class="css-1dcdqdg"><code>    <span class="code-keyword">return</span> getRoot(node.parentNode);
</code></td></tr><tr><td id="L185" class="css-a4x74f"><span>185</span></td><td id="LC185" class="css-1dcdqdg"><code>  }
</code></td></tr><tr><td id="L186" class="css-a4x74f"><span>186</span></td><td id="LC186" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L187" class="css-a4x74f"><span>187</span></td><td id="LC187" class="css-1dcdqdg"><code>  <span class="code-keyword">return</span> node;
</code></td></tr><tr><td id="L188" class="css-a4x74f"><span>188</span></td><td id="LC188" class="css-1dcdqdg"><code>}
</code></td></tr><tr><td id="L189" class="css-a4x74f"><span>189</span></td><td id="LC189" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L190" class="css-a4x74f"><span>190</span></td><td id="LC190" class="css-1dcdqdg"><code><span class="code-comment">/**
</span></code></td></tr><tr><td id="L191" class="css-a4x74f"><span>191</span></td><td id="LC191" class="css-1dcdqdg"><code><span class="code-comment"> * Finds the offset parent common to the two provided nodes
</span></code></td></tr><tr><td id="L192" class="css-a4x74f"><span>192</span></td><td id="LC192" class="css-1dcdqdg"><code><span class="code-comment"> * @method
</span></code></td></tr><tr><td id="L193" class="css-a4x74f"><span>193</span></td><td id="LC193" class="css-1dcdqdg"><code><span class="code-comment"> * @memberof Popper.Utils
</span></code></td></tr><tr><td id="L194" class="css-a4x74f"><span>194</span></td><td id="LC194" class="css-1dcdqdg"><code><span class="code-comment"> * @argument {Element} element1
</span></code></td></tr><tr><td id="L195" class="css-a4x74f"><span>195</span></td><td id="LC195" class="css-1dcdqdg"><code><span class="code-comment"> * @argument {Element} element2
</span></code></td></tr><tr><td id="L196" class="css-a4x74f"><span>196</span></td><td id="LC196" class="css-1dcdqdg"><code><span class="code-comment"> * @returns {Element} common offset parent
</span></code></td></tr><tr><td id="L197" class="css-a4x74f"><span>197</span></td><td id="LC197" class="css-1dcdqdg"><code><span class="code-comment"> */</span>
</code></td></tr><tr><td id="L198" class="css-a4x74f"><span>198</span></td><td id="LC198" class="css-1dcdqdg"><code><span class="code-function"><span class="code-keyword">function</span> <span class="code-title">findCommonOffsetParent</span>(<span class="code-params">element1, element2</span>) </span>{
</code></td></tr><tr><td id="L199" class="css-a4x74f"><span>199</span></td><td id="LC199" class="css-1dcdqdg"><code>  <span class="code-comment">// This check is needed to avoid errors in case one of the elements isn't defined for any reason</span>
</code></td></tr><tr><td id="L200" class="css-a4x74f"><span>200</span></td><td id="LC200" class="css-1dcdqdg"><code>  <span class="code-keyword">if</span> (!element1 || !element1.nodeType || !element2 || !element2.nodeType) {
</code></td></tr><tr><td id="L201" class="css-a4x74f"><span>201</span></td><td id="LC201" class="css-1dcdqdg"><code>    <span class="code-keyword">return</span> <span class="code-built_in">document</span>.documentElement;
</code></td></tr><tr><td id="L202" class="css-a4x74f"><span>202</span></td><td id="LC202" class="css-1dcdqdg"><code>  }
</code></td></tr><tr><td id="L203" class="css-a4x74f"><span>203</span></td><td id="LC203" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L204" class="css-a4x74f"><span>204</span></td><td id="LC204" class="css-1dcdqdg"><code>  <span class="code-comment">// Here we make sure to give as "start" the element that comes first in the DOM</span>
</code></td></tr><tr><td id="L205" class="css-a4x74f"><span>205</span></td><td id="LC205" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> order = element1.compareDocumentPosition(element2) &amp; Node.DOCUMENT_POSITION_FOLLOWING;
</code></td></tr><tr><td id="L206" class="css-a4x74f"><span>206</span></td><td id="LC206" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> start = order ? element1 : element2;
</code></td></tr><tr><td id="L207" class="css-a4x74f"><span>207</span></td><td id="LC207" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> end = order ? element2 : element1;
</code></td></tr><tr><td id="L208" class="css-a4x74f"><span>208</span></td><td id="LC208" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L209" class="css-a4x74f"><span>209</span></td><td id="LC209" class="css-1dcdqdg"><code>  <span class="code-comment">// Get common ancestor container</span>
</code></td></tr><tr><td id="L210" class="css-a4x74f"><span>210</span></td><td id="LC210" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> range = <span class="code-built_in">document</span>.createRange();
</code></td></tr><tr><td id="L211" class="css-a4x74f"><span>211</span></td><td id="LC211" class="css-1dcdqdg"><code>  range.setStart(start, <span class="code-number">0</span>);
</code></td></tr><tr><td id="L212" class="css-a4x74f"><span>212</span></td><td id="LC212" class="css-1dcdqdg"><code>  range.setEnd(end, <span class="code-number">0</span>);
</code></td></tr><tr><td id="L213" class="css-a4x74f"><span>213</span></td><td id="LC213" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> commonAncestorContainer = range.commonAncestorContainer;
</code></td></tr><tr><td id="L214" class="css-a4x74f"><span>214</span></td><td id="LC214" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L215" class="css-a4x74f"><span>215</span></td><td id="LC215" class="css-1dcdqdg"><code>  <span class="code-comment">// Both nodes are inside #document</span>
</code></td></tr><tr><td id="L216" class="css-a4x74f"><span>216</span></td><td id="LC216" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L217" class="css-a4x74f"><span>217</span></td><td id="LC217" class="css-1dcdqdg"><code>  <span class="code-keyword">if</span> (element1 !== commonAncestorContainer &amp;&amp; element2 !== commonAncestorContainer || start.contains(end)) {
</code></td></tr><tr><td id="L218" class="css-a4x74f"><span>218</span></td><td id="LC218" class="css-1dcdqdg"><code>    <span class="code-keyword">if</span> (isOffsetContainer(commonAncestorContainer)) {
</code></td></tr><tr><td id="L219" class="css-a4x74f"><span>219</span></td><td id="LC219" class="css-1dcdqdg"><code>      <span class="code-keyword">return</span> commonAncestorContainer;
</code></td></tr><tr><td id="L220" class="css-a4x74f"><span>220</span></td><td id="LC220" class="css-1dcdqdg"><code>    }
</code></td></tr><tr><td id="L221" class="css-a4x74f"><span>221</span></td><td id="LC221" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L222" class="css-a4x74f"><span>222</span></td><td id="LC222" class="css-1dcdqdg"><code>    <span class="code-keyword">return</span> getOffsetParent(commonAncestorContainer);
</code></td></tr><tr><td id="L223" class="css-a4x74f"><span>223</span></td><td id="LC223" class="css-1dcdqdg"><code>  }
</code></td></tr><tr><td id="L224" class="css-a4x74f"><span>224</span></td><td id="LC224" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L225" class="css-a4x74f"><span>225</span></td><td id="LC225" class="css-1dcdqdg"><code>  <span class="code-comment">// one of the nodes is inside shadowDOM, find which one</span>
</code></td></tr><tr><td id="L226" class="css-a4x74f"><span>226</span></td><td id="LC226" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> element1root = getRoot(element1);
</code></td></tr><tr><td id="L227" class="css-a4x74f"><span>227</span></td><td id="LC227" class="css-1dcdqdg"><code>  <span class="code-keyword">if</span> (element1root.host) {
</code></td></tr><tr><td id="L228" class="css-a4x74f"><span>228</span></td><td id="LC228" class="css-1dcdqdg"><code>    <span class="code-keyword">return</span> findCommonOffsetParent(element1root.host, element2);
</code></td></tr><tr><td id="L229" class="css-a4x74f"><span>229</span></td><td id="LC229" class="css-1dcdqdg"><code>  } <span class="code-keyword">else</span> {
</code></td></tr><tr><td id="L230" class="css-a4x74f"><span>230</span></td><td id="LC230" class="css-1dcdqdg"><code>    <span class="code-keyword">return</span> findCommonOffsetParent(element1, getRoot(element2).host);
</code></td></tr><tr><td id="L231" class="css-a4x74f"><span>231</span></td><td id="LC231" class="css-1dcdqdg"><code>  }
</code></td></tr><tr><td id="L232" class="css-a4x74f"><span>232</span></td><td id="LC232" class="css-1dcdqdg"><code>}
</code></td></tr><tr><td id="L233" class="css-a4x74f"><span>233</span></td><td id="LC233" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L234" class="css-a4x74f"><span>234</span></td><td id="LC234" class="css-1dcdqdg"><code><span class="code-comment">/**
</span></code></td></tr><tr><td id="L235" class="css-a4x74f"><span>235</span></td><td id="LC235" class="css-1dcdqdg"><code><span class="code-comment"> * Gets the scroll value of the given element in the given side (top and left)
</span></code></td></tr><tr><td id="L236" class="css-a4x74f"><span>236</span></td><td id="LC236" class="css-1dcdqdg"><code><span class="code-comment"> * @method
</span></code></td></tr><tr><td id="L237" class="css-a4x74f"><span>237</span></td><td id="LC237" class="css-1dcdqdg"><code><span class="code-comment"> * @memberof Popper.Utils
</span></code></td></tr><tr><td id="L238" class="css-a4x74f"><span>238</span></td><td id="LC238" class="css-1dcdqdg"><code><span class="code-comment"> * @argument {Element} element
</span></code></td></tr><tr><td id="L239" class="css-a4x74f"><span>239</span></td><td id="LC239" class="css-1dcdqdg"><code><span class="code-comment"> * @argument {String} side `top` or `left`
</span></code></td></tr><tr><td id="L240" class="css-a4x74f"><span>240</span></td><td id="LC240" class="css-1dcdqdg"><code><span class="code-comment"> * @returns {number} amount of scrolled pixels
</span></code></td></tr><tr><td id="L241" class="css-a4x74f"><span>241</span></td><td id="LC241" class="css-1dcdqdg"><code><span class="code-comment"> */</span>
</code></td></tr><tr><td id="L242" class="css-a4x74f"><span>242</span></td><td id="LC242" class="css-1dcdqdg"><code><span class="code-function"><span class="code-keyword">function</span> <span class="code-title">getScroll</span>(<span class="code-params">element</span>) </span>{
</code></td></tr><tr><td id="L243" class="css-a4x74f"><span>243</span></td><td id="LC243" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> side = <span class="code-built_in">arguments</span>.length &gt; <span class="code-number">1</span> &amp;&amp; <span class="code-built_in">arguments</span>[<span class="code-number">1</span>] !== <span class="code-literal">undefined</span> ? <span class="code-built_in">arguments</span>[<span class="code-number">1</span>] : <span class="code-string">'top'</span>;
</code></td></tr><tr><td id="L244" class="css-a4x74f"><span>244</span></td><td id="LC244" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L245" class="css-a4x74f"><span>245</span></td><td id="LC245" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> upperSide = side === <span class="code-string">'top'</span> ? <span class="code-string">'scrollTop'</span> : <span class="code-string">'scrollLeft'</span>;
</code></td></tr><tr><td id="L246" class="css-a4x74f"><span>246</span></td><td id="LC246" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> nodeName = element.nodeName;
</code></td></tr><tr><td id="L247" class="css-a4x74f"><span>247</span></td><td id="LC247" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L248" class="css-a4x74f"><span>248</span></td><td id="LC248" class="css-1dcdqdg"><code>  <span class="code-keyword">if</span> (nodeName === <span class="code-string">'BODY'</span> || nodeName === <span class="code-string">'HTML'</span>) {
</code></td></tr><tr><td id="L249" class="css-a4x74f"><span>249</span></td><td id="LC249" class="css-1dcdqdg"><code>    <span class="code-keyword">var</span> html = element.ownerDocument.documentElement;
</code></td></tr><tr><td id="L250" class="css-a4x74f"><span>250</span></td><td id="LC250" class="css-1dcdqdg"><code>    <span class="code-keyword">var</span> scrollingElement = element.ownerDocument.scrollingElement || html;
</code></td></tr><tr><td id="L251" class="css-a4x74f"><span>251</span></td><td id="LC251" class="css-1dcdqdg"><code>    <span class="code-keyword">return</span> scrollingElement[upperSide];
</code></td></tr><tr><td id="L252" class="css-a4x74f"><span>252</span></td><td id="LC252" class="css-1dcdqdg"><code>  }
</code></td></tr><tr><td id="L253" class="css-a4x74f"><span>253</span></td><td id="LC253" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L254" class="css-a4x74f"><span>254</span></td><td id="LC254" class="css-1dcdqdg"><code>  <span class="code-keyword">return</span> element[upperSide];
</code></td></tr><tr><td id="L255" class="css-a4x74f"><span>255</span></td><td id="LC255" class="css-1dcdqdg"><code>}
</code></td></tr><tr><td id="L256" class="css-a4x74f"><span>256</span></td><td id="LC256" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L257" class="css-a4x74f"><span>257</span></td><td id="LC257" class="css-1dcdqdg"><code><span class="code-comment">/*
</span></code></td></tr><tr><td id="L258" class="css-a4x74f"><span>258</span></td><td id="LC258" class="css-1dcdqdg"><code><span class="code-comment"> * Sum or subtract the element scroll values (left and top) from a given rect object
</span></code></td></tr><tr><td id="L259" class="css-a4x74f"><span>259</span></td><td id="LC259" class="css-1dcdqdg"><code><span class="code-comment"> * @method
</span></code></td></tr><tr><td id="L260" class="css-a4x74f"><span>260</span></td><td id="LC260" class="css-1dcdqdg"><code><span class="code-comment"> * @memberof Popper.Utils
</span></code></td></tr><tr><td id="L261" class="css-a4x74f"><span>261</span></td><td id="LC261" class="css-1dcdqdg"><code><span class="code-comment"> * @param {Object} rect - Rect object you want to change
</span></code></td></tr><tr><td id="L262" class="css-a4x74f"><span>262</span></td><td id="LC262" class="css-1dcdqdg"><code><span class="code-comment"> * @param {HTMLElement} element - The element from the function reads the scroll values
</span></code></td></tr><tr><td id="L263" class="css-a4x74f"><span>263</span></td><td id="LC263" class="css-1dcdqdg"><code><span class="code-comment"> * @param {Boolean} subtract - set to true if you want to subtract the scroll values
</span></code></td></tr><tr><td id="L264" class="css-a4x74f"><span>264</span></td><td id="LC264" class="css-1dcdqdg"><code><span class="code-comment"> * @return {Object} rect - The modifier rect object
</span></code></td></tr><tr><td id="L265" class="css-a4x74f"><span>265</span></td><td id="LC265" class="css-1dcdqdg"><code><span class="code-comment"> */</span>
</code></td></tr><tr><td id="L266" class="css-a4x74f"><span>266</span></td><td id="LC266" class="css-1dcdqdg"><code><span class="code-function"><span class="code-keyword">function</span> <span class="code-title">includeScroll</span>(<span class="code-params">rect, element</span>) </span>{
</code></td></tr><tr><td id="L267" class="css-a4x74f"><span>267</span></td><td id="LC267" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> subtract = <span class="code-built_in">arguments</span>.length &gt; <span class="code-number">2</span> &amp;&amp; <span class="code-built_in">arguments</span>[<span class="code-number">2</span>] !== <span class="code-literal">undefined</span> ? <span class="code-built_in">arguments</span>[<span class="code-number">2</span>] : <span class="code-literal">false</span>;
</code></td></tr><tr><td id="L268" class="css-a4x74f"><span>268</span></td><td id="LC268" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L269" class="css-a4x74f"><span>269</span></td><td id="LC269" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> scrollTop = getScroll(element, <span class="code-string">'top'</span>);
</code></td></tr><tr><td id="L270" class="css-a4x74f"><span>270</span></td><td id="LC270" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> scrollLeft = getScroll(element, <span class="code-string">'left'</span>);
</code></td></tr><tr><td id="L271" class="css-a4x74f"><span>271</span></td><td id="LC271" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> modifier = subtract ? <span class="code-number">-1</span> : <span class="code-number">1</span>;
</code></td></tr><tr><td id="L272" class="css-a4x74f"><span>272</span></td><td id="LC272" class="css-1dcdqdg"><code>  rect.top += scrollTop * modifier;
</code></td></tr><tr><td id="L273" class="css-a4x74f"><span>273</span></td><td id="LC273" class="css-1dcdqdg"><code>  rect.bottom += scrollTop * modifier;
</code></td></tr><tr><td id="L274" class="css-a4x74f"><span>274</span></td><td id="LC274" class="css-1dcdqdg"><code>  rect.left += scrollLeft * modifier;
</code></td></tr><tr><td id="L275" class="css-a4x74f"><span>275</span></td><td id="LC275" class="css-1dcdqdg"><code>  rect.right += scrollLeft * modifier;
</code></td></tr><tr><td id="L276" class="css-a4x74f"><span>276</span></td><td id="LC276" class="css-1dcdqdg"><code>  <span class="code-keyword">return</span> rect;
</code></td></tr><tr><td id="L277" class="css-a4x74f"><span>277</span></td><td id="LC277" class="css-1dcdqdg"><code>}
</code></td></tr><tr><td id="L278" class="css-a4x74f"><span>278</span></td><td id="LC278" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L279" class="css-a4x74f"><span>279</span></td><td id="LC279" class="css-1dcdqdg"><code><span class="code-comment">/*
</span></code></td></tr><tr><td id="L280" class="css-a4x74f"><span>280</span></td><td id="LC280" class="css-1dcdqdg"><code><span class="code-comment"> * Helper to detect borders of a given element
</span></code></td></tr><tr><td id="L281" class="css-a4x74f"><span>281</span></td><td id="LC281" class="css-1dcdqdg"><code><span class="code-comment"> * @method
</span></code></td></tr><tr><td id="L282" class="css-a4x74f"><span>282</span></td><td id="LC282" class="css-1dcdqdg"><code><span class="code-comment"> * @memberof Popper.Utils
</span></code></td></tr><tr><td id="L283" class="css-a4x74f"><span>283</span></td><td id="LC283" class="css-1dcdqdg"><code><span class="code-comment"> * @param {CSSStyleDeclaration} styles
</span></code></td></tr><tr><td id="L284" class="css-a4x74f"><span>284</span></td><td id="LC284" class="css-1dcdqdg"><code><span class="code-comment"> * Result of `getStyleComputedProperty` on the given element
</span></code></td></tr><tr><td id="L285" class="css-a4x74f"><span>285</span></td><td id="LC285" class="css-1dcdqdg"><code><span class="code-comment"> * @param {String} axis - `x` or `y`
</span></code></td></tr><tr><td id="L286" class="css-a4x74f"><span>286</span></td><td id="LC286" class="css-1dcdqdg"><code><span class="code-comment"> * @return {number} borders - The borders size of the given axis
</span></code></td></tr><tr><td id="L287" class="css-a4x74f"><span>287</span></td><td id="LC287" class="css-1dcdqdg"><code><span class="code-comment"> */</span>
</code></td></tr><tr><td id="L288" class="css-a4x74f"><span>288</span></td><td id="LC288" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L289" class="css-a4x74f"><span>289</span></td><td id="LC289" class="css-1dcdqdg"><code><span class="code-function"><span class="code-keyword">function</span> <span class="code-title">getBordersSize</span>(<span class="code-params">styles, axis</span>) </span>{
</code></td></tr><tr><td id="L290" class="css-a4x74f"><span>290</span></td><td id="LC290" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> sideA = axis === <span class="code-string">'x'</span> ? <span class="code-string">'Left'</span> : <span class="code-string">'Top'</span>;
</code></td></tr><tr><td id="L291" class="css-a4x74f"><span>291</span></td><td id="LC291" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> sideB = sideA === <span class="code-string">'Left'</span> ? <span class="code-string">'Right'</span> : <span class="code-string">'Bottom'</span>;
</code></td></tr><tr><td id="L292" class="css-a4x74f"><span>292</span></td><td id="LC292" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L293" class="css-a4x74f"><span>293</span></td><td id="LC293" class="css-1dcdqdg"><code>  <span class="code-keyword">return</span> <span class="code-built_in">parseFloat</span>(styles[<span class="code-string">'border'</span> + sideA + <span class="code-string">'Width'</span>], <span class="code-number">10</span>) + <span class="code-built_in">parseFloat</span>(styles[<span class="code-string">'border'</span> + sideB + <span class="code-string">'Width'</span>], <span class="code-number">10</span>);
</code></td></tr><tr><td id="L294" class="css-a4x74f"><span>294</span></td><td id="LC294" class="css-1dcdqdg"><code>}
</code></td></tr><tr><td id="L295" class="css-a4x74f"><span>295</span></td><td id="LC295" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L296" class="css-a4x74f"><span>296</span></td><td id="LC296" class="css-1dcdqdg"><code><span class="code-function"><span class="code-keyword">function</span> <span class="code-title">getSize</span>(<span class="code-params">axis, body, html, computedStyle</span>) </span>{
</code></td></tr><tr><td id="L297" class="css-a4x74f"><span>297</span></td><td id="LC297" class="css-1dcdqdg"><code>  <span class="code-keyword">return</span> <span class="code-built_in">Math</span>.max(body[<span class="code-string">'offset'</span> + axis], body[<span class="code-string">'scroll'</span> + axis], html[<span class="code-string">'client'</span> + axis], html[<span class="code-string">'offset'</span> + axis], html[<span class="code-string">'scroll'</span> + axis], isIE(<span class="code-number">10</span>) ? <span class="code-built_in">parseInt</span>(html[<span class="code-string">'offset'</span> + axis]) + <span class="code-built_in">parseInt</span>(computedStyle[<span class="code-string">'margin'</span> + (axis === <span class="code-string">'Height'</span> ? <span class="code-string">'Top'</span> : <span class="code-string">'Left'</span>)]) + <span class="code-built_in">parseInt</span>(computedStyle[<span class="code-string">'margin'</span> + (axis === <span class="code-string">'Height'</span> ? <span class="code-string">'Bottom'</span> : <span class="code-string">'Right'</span>)]) : <span class="code-number">0</span>);
</code></td></tr><tr><td id="L298" class="css-a4x74f"><span>298</span></td><td id="LC298" class="css-1dcdqdg"><code>}
</code></td></tr><tr><td id="L299" class="css-a4x74f"><span>299</span></td><td id="LC299" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L300" class="css-a4x74f"><span>300</span></td><td id="LC300" class="css-1dcdqdg"><code><span class="code-function"><span class="code-keyword">function</span> <span class="code-title">getWindowSizes</span>(<span class="code-params">document</span>) </span>{
</code></td></tr><tr><td id="L301" class="css-a4x74f"><span>301</span></td><td id="LC301" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> body = <span class="code-built_in">document</span>.body;
</code></td></tr><tr><td id="L302" class="css-a4x74f"><span>302</span></td><td id="LC302" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> html = <span class="code-built_in">document</span>.documentElement;
</code></td></tr><tr><td id="L303" class="css-a4x74f"><span>303</span></td><td id="LC303" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> computedStyle = isIE(<span class="code-number">10</span>) &amp;&amp; getComputedStyle(html);
</code></td></tr><tr><td id="L304" class="css-a4x74f"><span>304</span></td><td id="LC304" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L305" class="css-a4x74f"><span>305</span></td><td id="LC305" class="css-1dcdqdg"><code>  <span class="code-keyword">return</span> {
</code></td></tr><tr><td id="L306" class="css-a4x74f"><span>306</span></td><td id="LC306" class="css-1dcdqdg"><code>    height: getSize(<span class="code-string">'Height'</span>, body, html, computedStyle),
</code></td></tr><tr><td id="L307" class="css-a4x74f"><span>307</span></td><td id="LC307" class="css-1dcdqdg"><code>    width: getSize(<span class="code-string">'Width'</span>, body, html, computedStyle)
</code></td></tr><tr><td id="L308" class="css-a4x74f"><span>308</span></td><td id="LC308" class="css-1dcdqdg"><code>  };
</code></td></tr><tr><td id="L309" class="css-a4x74f"><span>309</span></td><td id="LC309" class="css-1dcdqdg"><code>}
</code></td></tr><tr><td id="L310" class="css-a4x74f"><span>310</span></td><td id="LC310" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L311" class="css-a4x74f"><span>311</span></td><td id="LC311" class="css-1dcdqdg"><code><span class="code-keyword">var</span> _extends = <span class="code-built_in">Object</span>.assign || <span class="code-function"><span class="code-keyword">function</span> (<span class="code-params">target</span>) </span>{
</code></td></tr><tr><td id="L312" class="css-a4x74f"><span>312</span></td><td id="LC312" class="css-1dcdqdg"><code>  <span class="code-keyword">for</span> (<span class="code-keyword">var</span> i = <span class="code-number">1</span>; i &lt; <span class="code-built_in">arguments</span>.length; i++) {
</code></td></tr><tr><td id="L313" class="css-a4x74f"><span>313</span></td><td id="LC313" class="css-1dcdqdg"><code>    <span class="code-keyword">var</span> source = <span class="code-built_in">arguments</span>[i];
</code></td></tr><tr><td id="L314" class="css-a4x74f"><span>314</span></td><td id="LC314" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L315" class="css-a4x74f"><span>315</span></td><td id="LC315" class="css-1dcdqdg"><code>    <span class="code-keyword">for</span> (<span class="code-keyword">var</span> key <span class="code-keyword">in</span> source) {
</code></td></tr><tr><td id="L316" class="css-a4x74f"><span>316</span></td><td id="LC316" class="css-1dcdqdg"><code>      <span class="code-keyword">if</span> (<span class="code-built_in">Object</span>.prototype.hasOwnProperty.call(source, key)) {
</code></td></tr><tr><td id="L317" class="css-a4x74f"><span>317</span></td><td id="LC317" class="css-1dcdqdg"><code>        target[key] = source[key];
</code></td></tr><tr><td id="L318" class="css-a4x74f"><span>318</span></td><td id="LC318" class="css-1dcdqdg"><code>      }
</code></td></tr><tr><td id="L319" class="css-a4x74f"><span>319</span></td><td id="LC319" class="css-1dcdqdg"><code>    }
</code></td></tr><tr><td id="L320" class="css-a4x74f"><span>320</span></td><td id="LC320" class="css-1dcdqdg"><code>  }
</code></td></tr><tr><td id="L321" class="css-a4x74f"><span>321</span></td><td id="LC321" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L322" class="css-a4x74f"><span>322</span></td><td id="LC322" class="css-1dcdqdg"><code>  <span class="code-keyword">return</span> target;
</code></td></tr><tr><td id="L323" class="css-a4x74f"><span>323</span></td><td id="LC323" class="css-1dcdqdg"><code>};
</code></td></tr><tr><td id="L324" class="css-a4x74f"><span>324</span></td><td id="LC324" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L325" class="css-a4x74f"><span>325</span></td><td id="LC325" class="css-1dcdqdg"><code><span class="code-comment">/**
</span></code></td></tr><tr><td id="L326" class="css-a4x74f"><span>326</span></td><td id="LC326" class="css-1dcdqdg"><code><span class="code-comment"> * Given element offsets, generate an output similar to getBoundingClientRect
</span></code></td></tr><tr><td id="L327" class="css-a4x74f"><span>327</span></td><td id="LC327" class="css-1dcdqdg"><code><span class="code-comment"> * @method
</span></code></td></tr><tr><td id="L328" class="css-a4x74f"><span>328</span></td><td id="LC328" class="css-1dcdqdg"><code><span class="code-comment"> * @memberof Popper.Utils
</span></code></td></tr><tr><td id="L329" class="css-a4x74f"><span>329</span></td><td id="LC329" class="css-1dcdqdg"><code><span class="code-comment"> * @argument {Object} offsets
</span></code></td></tr><tr><td id="L330" class="css-a4x74f"><span>330</span></td><td id="LC330" class="css-1dcdqdg"><code><span class="code-comment"> * @returns {Object} ClientRect like output
</span></code></td></tr><tr><td id="L331" class="css-a4x74f"><span>331</span></td><td id="LC331" class="css-1dcdqdg"><code><span class="code-comment"> */</span>
</code></td></tr><tr><td id="L332" class="css-a4x74f"><span>332</span></td><td id="LC332" class="css-1dcdqdg"><code><span class="code-function"><span class="code-keyword">function</span> <span class="code-title">getClientRect</span>(<span class="code-params">offsets</span>) </span>{
</code></td></tr><tr><td id="L333" class="css-a4x74f"><span>333</span></td><td id="LC333" class="css-1dcdqdg"><code>  <span class="code-keyword">return</span> _extends({}, offsets, {
</code></td></tr><tr><td id="L334" class="css-a4x74f"><span>334</span></td><td id="LC334" class="css-1dcdqdg"><code>    right: offsets.left + offsets.width,
</code></td></tr><tr><td id="L335" class="css-a4x74f"><span>335</span></td><td id="LC335" class="css-1dcdqdg"><code>    bottom: offsets.top + offsets.height
</code></td></tr><tr><td id="L336" class="css-a4x74f"><span>336</span></td><td id="LC336" class="css-1dcdqdg"><code>  });
</code></td></tr><tr><td id="L337" class="css-a4x74f"><span>337</span></td><td id="LC337" class="css-1dcdqdg"><code>}
</code></td></tr><tr><td id="L338" class="css-a4x74f"><span>338</span></td><td id="LC338" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L339" class="css-a4x74f"><span>339</span></td><td id="LC339" class="css-1dcdqdg"><code><span class="code-comment">/**
</span></code></td></tr><tr><td id="L340" class="css-a4x74f"><span>340</span></td><td id="LC340" class="css-1dcdqdg"><code><span class="code-comment"> * Get bounding client rect of given element
</span></code></td></tr><tr><td id="L341" class="css-a4x74f"><span>341</span></td><td id="LC341" class="css-1dcdqdg"><code><span class="code-comment"> * @method
</span></code></td></tr><tr><td id="L342" class="css-a4x74f"><span>342</span></td><td id="LC342" class="css-1dcdqdg"><code><span class="code-comment"> * @memberof Popper.Utils
</span></code></td></tr><tr><td id="L343" class="css-a4x74f"><span>343</span></td><td id="LC343" class="css-1dcdqdg"><code><span class="code-comment"> * @param {HTMLElement} element
</span></code></td></tr><tr><td id="L344" class="css-a4x74f"><span>344</span></td><td id="LC344" class="css-1dcdqdg"><code><span class="code-comment"> * @return {Object} client rect
</span></code></td></tr><tr><td id="L345" class="css-a4x74f"><span>345</span></td><td id="LC345" class="css-1dcdqdg"><code><span class="code-comment"> */</span>
</code></td></tr><tr><td id="L346" class="css-a4x74f"><span>346</span></td><td id="LC346" class="css-1dcdqdg"><code><span class="code-function"><span class="code-keyword">function</span> <span class="code-title">getBoundingClientRect</span>(<span class="code-params">element</span>) </span>{
</code></td></tr><tr><td id="L347" class="css-a4x74f"><span>347</span></td><td id="LC347" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> rect = {};
</code></td></tr><tr><td id="L348" class="css-a4x74f"><span>348</span></td><td id="LC348" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L349" class="css-a4x74f"><span>349</span></td><td id="LC349" class="css-1dcdqdg"><code>  <span class="code-comment">// IE10 10 FIX: Please, don't ask, the element isn't</span>
</code></td></tr><tr><td id="L350" class="css-a4x74f"><span>350</span></td><td id="LC350" class="css-1dcdqdg"><code>  <span class="code-comment">// considered in DOM in some circumstances...</span>
</code></td></tr><tr><td id="L351" class="css-a4x74f"><span>351</span></td><td id="LC351" class="css-1dcdqdg"><code>  <span class="code-comment">// This isn't reproducible in IE10 compatibility mode of IE11</span>
</code></td></tr><tr><td id="L352" class="css-a4x74f"><span>352</span></td><td id="LC352" class="css-1dcdqdg"><code>  <span class="code-keyword">try</span> {
</code></td></tr><tr><td id="L353" class="css-a4x74f"><span>353</span></td><td id="LC353" class="css-1dcdqdg"><code>    <span class="code-keyword">if</span> (isIE(<span class="code-number">10</span>)) {
</code></td></tr><tr><td id="L354" class="css-a4x74f"><span>354</span></td><td id="LC354" class="css-1dcdqdg"><code>      rect = element.getBoundingClientRect();
</code></td></tr><tr><td id="L355" class="css-a4x74f"><span>355</span></td><td id="LC355" class="css-1dcdqdg"><code>      <span class="code-keyword">var</span> scrollTop = getScroll(element, <span class="code-string">'top'</span>);
</code></td></tr><tr><td id="L356" class="css-a4x74f"><span>356</span></td><td id="LC356" class="css-1dcdqdg"><code>      <span class="code-keyword">var</span> scrollLeft = getScroll(element, <span class="code-string">'left'</span>);
</code></td></tr><tr><td id="L357" class="css-a4x74f"><span>357</span></td><td id="LC357" class="css-1dcdqdg"><code>      rect.top += scrollTop;
</code></td></tr><tr><td id="L358" class="css-a4x74f"><span>358</span></td><td id="LC358" class="css-1dcdqdg"><code>      rect.left += scrollLeft;
</code></td></tr><tr><td id="L359" class="css-a4x74f"><span>359</span></td><td id="LC359" class="css-1dcdqdg"><code>      rect.bottom += scrollTop;
</code></td></tr><tr><td id="L360" class="css-a4x74f"><span>360</span></td><td id="LC360" class="css-1dcdqdg"><code>      rect.right += scrollLeft;
</code></td></tr><tr><td id="L361" class="css-a4x74f"><span>361</span></td><td id="LC361" class="css-1dcdqdg"><code>    } <span class="code-keyword">else</span> {
</code></td></tr><tr><td id="L362" class="css-a4x74f"><span>362</span></td><td id="LC362" class="css-1dcdqdg"><code>      rect = element.getBoundingClientRect();
</code></td></tr><tr><td id="L363" class="css-a4x74f"><span>363</span></td><td id="LC363" class="css-1dcdqdg"><code>    }
</code></td></tr><tr><td id="L364" class="css-a4x74f"><span>364</span></td><td id="LC364" class="css-1dcdqdg"><code>  } <span class="code-keyword">catch</span> (e) {}
</code></td></tr><tr><td id="L365" class="css-a4x74f"><span>365</span></td><td id="LC365" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L366" class="css-a4x74f"><span>366</span></td><td id="LC366" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> result = {
</code></td></tr><tr><td id="L367" class="css-a4x74f"><span>367</span></td><td id="LC367" class="css-1dcdqdg"><code>    left: rect.left,
</code></td></tr><tr><td id="L368" class="css-a4x74f"><span>368</span></td><td id="LC368" class="css-1dcdqdg"><code>    top: rect.top,
</code></td></tr><tr><td id="L369" class="css-a4x74f"><span>369</span></td><td id="LC369" class="css-1dcdqdg"><code>    width: rect.right - rect.left,
</code></td></tr><tr><td id="L370" class="css-a4x74f"><span>370</span></td><td id="LC370" class="css-1dcdqdg"><code>    height: rect.bottom - rect.top
</code></td></tr><tr><td id="L371" class="css-a4x74f"><span>371</span></td><td id="LC371" class="css-1dcdqdg"><code>  };
</code></td></tr><tr><td id="L372" class="css-a4x74f"><span>372</span></td><td id="LC372" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L373" class="css-a4x74f"><span>373</span></td><td id="LC373" class="css-1dcdqdg"><code>  <span class="code-comment">// subtract scrollbar size from sizes</span>
</code></td></tr><tr><td id="L374" class="css-a4x74f"><span>374</span></td><td id="LC374" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> sizes = element.nodeName === <span class="code-string">'HTML'</span> ? getWindowSizes(element.ownerDocument) : {};
</code></td></tr><tr><td id="L375" class="css-a4x74f"><span>375</span></td><td id="LC375" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> width = sizes.width || element.clientWidth || result.width;
</code></td></tr><tr><td id="L376" class="css-a4x74f"><span>376</span></td><td id="LC376" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> height = sizes.height || element.clientHeight || result.height;
</code></td></tr><tr><td id="L377" class="css-a4x74f"><span>377</span></td><td id="LC377" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L378" class="css-a4x74f"><span>378</span></td><td id="LC378" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> horizScrollbar = element.offsetWidth - width;
</code></td></tr><tr><td id="L379" class="css-a4x74f"><span>379</span></td><td id="LC379" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> vertScrollbar = element.offsetHeight - height;
</code></td></tr><tr><td id="L380" class="css-a4x74f"><span>380</span></td><td id="LC380" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L381" class="css-a4x74f"><span>381</span></td><td id="LC381" class="css-1dcdqdg"><code>  <span class="code-comment">// if an hypothetical scrollbar is detected, we must be sure it's not a `border`</span>
</code></td></tr><tr><td id="L382" class="css-a4x74f"><span>382</span></td><td id="LC382" class="css-1dcdqdg"><code>  <span class="code-comment">// we make this check conditional for performance reasons</span>
</code></td></tr><tr><td id="L383" class="css-a4x74f"><span>383</span></td><td id="LC383" class="css-1dcdqdg"><code>  <span class="code-keyword">if</span> (horizScrollbar || vertScrollbar) {
</code></td></tr><tr><td id="L384" class="css-a4x74f"><span>384</span></td><td id="LC384" class="css-1dcdqdg"><code>    <span class="code-keyword">var</span> styles = getStyleComputedProperty(element);
</code></td></tr><tr><td id="L385" class="css-a4x74f"><span>385</span></td><td id="LC385" class="css-1dcdqdg"><code>    horizScrollbar -= getBordersSize(styles, <span class="code-string">'x'</span>);
</code></td></tr><tr><td id="L386" class="css-a4x74f"><span>386</span></td><td id="LC386" class="css-1dcdqdg"><code>    vertScrollbar -= getBordersSize(styles, <span class="code-string">'y'</span>);
</code></td></tr><tr><td id="L387" class="css-a4x74f"><span>387</span></td><td id="LC387" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L388" class="css-a4x74f"><span>388</span></td><td id="LC388" class="css-1dcdqdg"><code>    result.width -= horizScrollbar;
</code></td></tr><tr><td id="L389" class="css-a4x74f"><span>389</span></td><td id="LC389" class="css-1dcdqdg"><code>    result.height -= vertScrollbar;
</code></td></tr><tr><td id="L390" class="css-a4x74f"><span>390</span></td><td id="LC390" class="css-1dcdqdg"><code>  }
</code></td></tr><tr><td id="L391" class="css-a4x74f"><span>391</span></td><td id="LC391" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L392" class="css-a4x74f"><span>392</span></td><td id="LC392" class="css-1dcdqdg"><code>  <span class="code-keyword">return</span> getClientRect(result);
</code></td></tr><tr><td id="L393" class="css-a4x74f"><span>393</span></td><td id="LC393" class="css-1dcdqdg"><code>}
</code></td></tr><tr><td id="L394" class="css-a4x74f"><span>394</span></td><td id="LC394" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L395" class="css-a4x74f"><span>395</span></td><td id="LC395" class="css-1dcdqdg"><code><span class="code-function"><span class="code-keyword">function</span> <span class="code-title">getOffsetRectRelativeToArbitraryNode</span>(<span class="code-params">children, parent</span>) </span>{
</code></td></tr><tr><td id="L396" class="css-a4x74f"><span>396</span></td><td id="LC396" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> fixedPosition = <span class="code-built_in">arguments</span>.length &gt; <span class="code-number">2</span> &amp;&amp; <span class="code-built_in">arguments</span>[<span class="code-number">2</span>] !== <span class="code-literal">undefined</span> ? <span class="code-built_in">arguments</span>[<span class="code-number">2</span>] : <span class="code-literal">false</span>;
</code></td></tr><tr><td id="L397" class="css-a4x74f"><span>397</span></td><td id="LC397" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L398" class="css-a4x74f"><span>398</span></td><td id="LC398" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> isIE10 = isIE(<span class="code-number">10</span>);
</code></td></tr><tr><td id="L399" class="css-a4x74f"><span>399</span></td><td id="LC399" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> isHTML = parent.nodeName === <span class="code-string">'HTML'</span>;
</code></td></tr><tr><td id="L400" class="css-a4x74f"><span>400</span></td><td id="LC400" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> childrenRect = getBoundingClientRect(children);
</code></td></tr><tr><td id="L401" class="css-a4x74f"><span>401</span></td><td id="LC401" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> parentRect = getBoundingClientRect(parent);
</code></td></tr><tr><td id="L402" class="css-a4x74f"><span>402</span></td><td id="LC402" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> scrollParent = getScrollParent(children);
</code></td></tr><tr><td id="L403" class="css-a4x74f"><span>403</span></td><td id="LC403" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L404" class="css-a4x74f"><span>404</span></td><td id="LC404" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> styles = getStyleComputedProperty(parent);
</code></td></tr><tr><td id="L405" class="css-a4x74f"><span>405</span></td><td id="LC405" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> borderTopWidth = <span class="code-built_in">parseFloat</span>(styles.borderTopWidth, <span class="code-number">10</span>);
</code></td></tr><tr><td id="L406" class="css-a4x74f"><span>406</span></td><td id="LC406" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> borderLeftWidth = <span class="code-built_in">parseFloat</span>(styles.borderLeftWidth, <span class="code-number">10</span>);
</code></td></tr><tr><td id="L407" class="css-a4x74f"><span>407</span></td><td id="LC407" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L408" class="css-a4x74f"><span>408</span></td><td id="LC408" class="css-1dcdqdg"><code>  <span class="code-comment">// In cases where the parent is fixed, we must ignore negative scroll in offset calc</span>
</code></td></tr><tr><td id="L409" class="css-a4x74f"><span>409</span></td><td id="LC409" class="css-1dcdqdg"><code>  <span class="code-keyword">if</span> (fixedPosition &amp;&amp; isHTML) {
</code></td></tr><tr><td id="L410" class="css-a4x74f"><span>410</span></td><td id="LC410" class="css-1dcdqdg"><code>    parentRect.top = <span class="code-built_in">Math</span>.max(parentRect.top, <span class="code-number">0</span>);
</code></td></tr><tr><td id="L411" class="css-a4x74f"><span>411</span></td><td id="LC411" class="css-1dcdqdg"><code>    parentRect.left = <span class="code-built_in">Math</span>.max(parentRect.left, <span class="code-number">0</span>);
</code></td></tr><tr><td id="L412" class="css-a4x74f"><span>412</span></td><td id="LC412" class="css-1dcdqdg"><code>  }
</code></td></tr><tr><td id="L413" class="css-a4x74f"><span>413</span></td><td id="LC413" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> offsets = getClientRect({
</code></td></tr><tr><td id="L414" class="css-a4x74f"><span>414</span></td><td id="LC414" class="css-1dcdqdg"><code>    top: childrenRect.top - parentRect.top - borderTopWidth,
</code></td></tr><tr><td id="L415" class="css-a4x74f"><span>415</span></td><td id="LC415" class="css-1dcdqdg"><code>    left: childrenRect.left - parentRect.left - borderLeftWidth,
</code></td></tr><tr><td id="L416" class="css-a4x74f"><span>416</span></td><td id="LC416" class="css-1dcdqdg"><code>    width: childrenRect.width,
</code></td></tr><tr><td id="L417" class="css-a4x74f"><span>417</span></td><td id="LC417" class="css-1dcdqdg"><code>    height: childrenRect.height
</code></td></tr><tr><td id="L418" class="css-a4x74f"><span>418</span></td><td id="LC418" class="css-1dcdqdg"><code>  });
</code></td></tr><tr><td id="L419" class="css-a4x74f"><span>419</span></td><td id="LC419" class="css-1dcdqdg"><code>  offsets.marginTop = <span class="code-number">0</span>;
</code></td></tr><tr><td id="L420" class="css-a4x74f"><span>420</span></td><td id="LC420" class="css-1dcdqdg"><code>  offsets.marginLeft = <span class="code-number">0</span>;
</code></td></tr><tr><td id="L421" class="css-a4x74f"><span>421</span></td><td id="LC421" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L422" class="css-a4x74f"><span>422</span></td><td id="LC422" class="css-1dcdqdg"><code>  <span class="code-comment">// Subtract margins of documentElement in case it's being used as parent</span>
</code></td></tr><tr><td id="L423" class="css-a4x74f"><span>423</span></td><td id="LC423" class="css-1dcdqdg"><code>  <span class="code-comment">// we do this only on HTML because it's the only element that behaves</span>
</code></td></tr><tr><td id="L424" class="css-a4x74f"><span>424</span></td><td id="LC424" class="css-1dcdqdg"><code>  <span class="code-comment">// differently when margins are applied to it. The margins are included in</span>
</code></td></tr><tr><td id="L425" class="css-a4x74f"><span>425</span></td><td id="LC425" class="css-1dcdqdg"><code>  <span class="code-comment">// the box of the documentElement, in the other cases not.</span>
</code></td></tr><tr><td id="L426" class="css-a4x74f"><span>426</span></td><td id="LC426" class="css-1dcdqdg"><code>  <span class="code-keyword">if</span> (!isIE10 &amp;&amp; isHTML) {
</code></td></tr><tr><td id="L427" class="css-a4x74f"><span>427</span></td><td id="LC427" class="css-1dcdqdg"><code>    <span class="code-keyword">var</span> marginTop = <span class="code-built_in">parseFloat</span>(styles.marginTop, <span class="code-number">10</span>);
</code></td></tr><tr><td id="L428" class="css-a4x74f"><span>428</span></td><td id="LC428" class="css-1dcdqdg"><code>    <span class="code-keyword">var</span> marginLeft = <span class="code-built_in">parseFloat</span>(styles.marginLeft, <span class="code-number">10</span>);
</code></td></tr><tr><td id="L429" class="css-a4x74f"><span>429</span></td><td id="LC429" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L430" class="css-a4x74f"><span>430</span></td><td id="LC430" class="css-1dcdqdg"><code>    offsets.top -= borderTopWidth - marginTop;
</code></td></tr><tr><td id="L431" class="css-a4x74f"><span>431</span></td><td id="LC431" class="css-1dcdqdg"><code>    offsets.bottom -= borderTopWidth - marginTop;
</code></td></tr><tr><td id="L432" class="css-a4x74f"><span>432</span></td><td id="LC432" class="css-1dcdqdg"><code>    offsets.left -= borderLeftWidth - marginLeft;
</code></td></tr><tr><td id="L433" class="css-a4x74f"><span>433</span></td><td id="LC433" class="css-1dcdqdg"><code>    offsets.right -= borderLeftWidth - marginLeft;
</code></td></tr><tr><td id="L434" class="css-a4x74f"><span>434</span></td><td id="LC434" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L435" class="css-a4x74f"><span>435</span></td><td id="LC435" class="css-1dcdqdg"><code>    <span class="code-comment">// Attach marginTop and marginLeft because in some circumstances we may need them</span>
</code></td></tr><tr><td id="L436" class="css-a4x74f"><span>436</span></td><td id="LC436" class="css-1dcdqdg"><code>    offsets.marginTop = marginTop;
</code></td></tr><tr><td id="L437" class="css-a4x74f"><span>437</span></td><td id="LC437" class="css-1dcdqdg"><code>    offsets.marginLeft = marginLeft;
</code></td></tr><tr><td id="L438" class="css-a4x74f"><span>438</span></td><td id="LC438" class="css-1dcdqdg"><code>  }
</code></td></tr><tr><td id="L439" class="css-a4x74f"><span>439</span></td><td id="LC439" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L440" class="css-a4x74f"><span>440</span></td><td id="LC440" class="css-1dcdqdg"><code>  <span class="code-keyword">if</span> (isIE10 &amp;&amp; !fixedPosition ? parent.contains(scrollParent) : parent === scrollParent &amp;&amp; scrollParent.nodeName !== <span class="code-string">'BODY'</span>) {
</code></td></tr><tr><td id="L441" class="css-a4x74f"><span>441</span></td><td id="LC441" class="css-1dcdqdg"><code>    offsets = includeScroll(offsets, parent);
</code></td></tr><tr><td id="L442" class="css-a4x74f"><span>442</span></td><td id="LC442" class="css-1dcdqdg"><code>  }
</code></td></tr><tr><td id="L443" class="css-a4x74f"><span>443</span></td><td id="LC443" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L444" class="css-a4x74f"><span>444</span></td><td id="LC444" class="css-1dcdqdg"><code>  <span class="code-keyword">return</span> offsets;
</code></td></tr><tr><td id="L445" class="css-a4x74f"><span>445</span></td><td id="LC445" class="css-1dcdqdg"><code>}
</code></td></tr><tr><td id="L446" class="css-a4x74f"><span>446</span></td><td id="LC446" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L447" class="css-a4x74f"><span>447</span></td><td id="LC447" class="css-1dcdqdg"><code><span class="code-function"><span class="code-keyword">function</span> <span class="code-title">getViewportOffsetRectRelativeToArtbitraryNode</span>(<span class="code-params">element</span>) </span>{
</code></td></tr><tr><td id="L448" class="css-a4x74f"><span>448</span></td><td id="LC448" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> excludeScroll = <span class="code-built_in">arguments</span>.length &gt; <span class="code-number">1</span> &amp;&amp; <span class="code-built_in">arguments</span>[<span class="code-number">1</span>] !== <span class="code-literal">undefined</span> ? <span class="code-built_in">arguments</span>[<span class="code-number">1</span>] : <span class="code-literal">false</span>;
</code></td></tr><tr><td id="L449" class="css-a4x74f"><span>449</span></td><td id="LC449" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L450" class="css-a4x74f"><span>450</span></td><td id="LC450" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> html = element.ownerDocument.documentElement;
</code></td></tr><tr><td id="L451" class="css-a4x74f"><span>451</span></td><td id="LC451" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> relativeOffset = getOffsetRectRelativeToArbitraryNode(element, html);
</code></td></tr><tr><td id="L452" class="css-a4x74f"><span>452</span></td><td id="LC452" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> width = <span class="code-built_in">Math</span>.max(html.clientWidth, <span class="code-built_in">window</span>.innerWidth || <span class="code-number">0</span>);
</code></td></tr><tr><td id="L453" class="css-a4x74f"><span>453</span></td><td id="LC453" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> height = <span class="code-built_in">Math</span>.max(html.clientHeight, <span class="code-built_in">window</span>.innerHeight || <span class="code-number">0</span>);
</code></td></tr><tr><td id="L454" class="css-a4x74f"><span>454</span></td><td id="LC454" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L455" class="css-a4x74f"><span>455</span></td><td id="LC455" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> scrollTop = !excludeScroll ? getScroll(html) : <span class="code-number">0</span>;
</code></td></tr><tr><td id="L456" class="css-a4x74f"><span>456</span></td><td id="LC456" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> scrollLeft = !excludeScroll ? getScroll(html, <span class="code-string">'left'</span>) : <span class="code-number">0</span>;
</code></td></tr><tr><td id="L457" class="css-a4x74f"><span>457</span></td><td id="LC457" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L458" class="css-a4x74f"><span>458</span></td><td id="LC458" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> offset = {
</code></td></tr><tr><td id="L459" class="css-a4x74f"><span>459</span></td><td id="LC459" class="css-1dcdqdg"><code>    top: scrollTop - relativeOffset.top + relativeOffset.marginTop,
</code></td></tr><tr><td id="L460" class="css-a4x74f"><span>460</span></td><td id="LC460" class="css-1dcdqdg"><code>    left: scrollLeft - relativeOffset.left + relativeOffset.marginLeft,
</code></td></tr><tr><td id="L461" class="css-a4x74f"><span>461</span></td><td id="LC461" class="css-1dcdqdg"><code>    width: width,
</code></td></tr><tr><td id="L462" class="css-a4x74f"><span>462</span></td><td id="LC462" class="css-1dcdqdg"><code>    height: height
</code></td></tr><tr><td id="L463" class="css-a4x74f"><span>463</span></td><td id="LC463" class="css-1dcdqdg"><code>  };
</code></td></tr><tr><td id="L464" class="css-a4x74f"><span>464</span></td><td id="LC464" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L465" class="css-a4x74f"><span>465</span></td><td id="LC465" class="css-1dcdqdg"><code>  <span class="code-keyword">return</span> getClientRect(offset);
</code></td></tr><tr><td id="L466" class="css-a4x74f"><span>466</span></td><td id="LC466" class="css-1dcdqdg"><code>}
</code></td></tr><tr><td id="L467" class="css-a4x74f"><span>467</span></td><td id="LC467" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L468" class="css-a4x74f"><span>468</span></td><td id="LC468" class="css-1dcdqdg"><code><span class="code-comment">/**
</span></code></td></tr><tr><td id="L469" class="css-a4x74f"><span>469</span></td><td id="LC469" class="css-1dcdqdg"><code><span class="code-comment"> * Check if the given element is fixed or is inside a fixed parent
</span></code></td></tr><tr><td id="L470" class="css-a4x74f"><span>470</span></td><td id="LC470" class="css-1dcdqdg"><code><span class="code-comment"> * @method
</span></code></td></tr><tr><td id="L471" class="css-a4x74f"><span>471</span></td><td id="LC471" class="css-1dcdqdg"><code><span class="code-comment"> * @memberof Popper.Utils
</span></code></td></tr><tr><td id="L472" class="css-a4x74f"><span>472</span></td><td id="LC472" class="css-1dcdqdg"><code><span class="code-comment"> * @argument {Element} element
</span></code></td></tr><tr><td id="L473" class="css-a4x74f"><span>473</span></td><td id="LC473" class="css-1dcdqdg"><code><span class="code-comment"> * @argument {Element} customContainer
</span></code></td></tr><tr><td id="L474" class="css-a4x74f"><span>474</span></td><td id="LC474" class="css-1dcdqdg"><code><span class="code-comment"> * @returns {Boolean} answer to "isFixed?"
</span></code></td></tr><tr><td id="L475" class="css-a4x74f"><span>475</span></td><td id="LC475" class="css-1dcdqdg"><code><span class="code-comment"> */</span>
</code></td></tr><tr><td id="L476" class="css-a4x74f"><span>476</span></td><td id="LC476" class="css-1dcdqdg"><code><span class="code-function"><span class="code-keyword">function</span> <span class="code-title">isFixed</span>(<span class="code-params">element</span>) </span>{
</code></td></tr><tr><td id="L477" class="css-a4x74f"><span>477</span></td><td id="LC477" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> nodeName = element.nodeName;
</code></td></tr><tr><td id="L478" class="css-a4x74f"><span>478</span></td><td id="LC478" class="css-1dcdqdg"><code>  <span class="code-keyword">if</span> (nodeName === <span class="code-string">'BODY'</span> || nodeName === <span class="code-string">'HTML'</span>) {
</code></td></tr><tr><td id="L479" class="css-a4x74f"><span>479</span></td><td id="LC479" class="css-1dcdqdg"><code>    <span class="code-keyword">return</span> <span class="code-literal">false</span>;
</code></td></tr><tr><td id="L480" class="css-a4x74f"><span>480</span></td><td id="LC480" class="css-1dcdqdg"><code>  }
</code></td></tr><tr><td id="L481" class="css-a4x74f"><span>481</span></td><td id="LC481" class="css-1dcdqdg"><code>  <span class="code-keyword">if</span> (getStyleComputedProperty(element, <span class="code-string">'position'</span>) === <span class="code-string">'fixed'</span>) {
</code></td></tr><tr><td id="L482" class="css-a4x74f"><span>482</span></td><td id="LC482" class="css-1dcdqdg"><code>    <span class="code-keyword">return</span> <span class="code-literal">true</span>;
</code></td></tr><tr><td id="L483" class="css-a4x74f"><span>483</span></td><td id="LC483" class="css-1dcdqdg"><code>  }
</code></td></tr><tr><td id="L484" class="css-a4x74f"><span>484</span></td><td id="LC484" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> parentNode = getParentNode(element);
</code></td></tr><tr><td id="L485" class="css-a4x74f"><span>485</span></td><td id="LC485" class="css-1dcdqdg"><code>  <span class="code-keyword">if</span> (!parentNode) {
</code></td></tr><tr><td id="L486" class="css-a4x74f"><span>486</span></td><td id="LC486" class="css-1dcdqdg"><code>    <span class="code-keyword">return</span> <span class="code-literal">false</span>;
</code></td></tr><tr><td id="L487" class="css-a4x74f"><span>487</span></td><td id="LC487" class="css-1dcdqdg"><code>  }
</code></td></tr><tr><td id="L488" class="css-a4x74f"><span>488</span></td><td id="LC488" class="css-1dcdqdg"><code>  <span class="code-keyword">return</span> isFixed(parentNode);
</code></td></tr><tr><td id="L489" class="css-a4x74f"><span>489</span></td><td id="LC489" class="css-1dcdqdg"><code>}
</code></td></tr><tr><td id="L490" class="css-a4x74f"><span>490</span></td><td id="LC490" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L491" class="css-a4x74f"><span>491</span></td><td id="LC491" class="css-1dcdqdg"><code><span class="code-comment">/**
</span></code></td></tr><tr><td id="L492" class="css-a4x74f"><span>492</span></td><td id="LC492" class="css-1dcdqdg"><code><span class="code-comment"> * Finds the first parent of an element that has a transformed property defined
</span></code></td></tr><tr><td id="L493" class="css-a4x74f"><span>493</span></td><td id="LC493" class="css-1dcdqdg"><code><span class="code-comment"> * @method
</span></code></td></tr><tr><td id="L494" class="css-a4x74f"><span>494</span></td><td id="LC494" class="css-1dcdqdg"><code><span class="code-comment"> * @memberof Popper.Utils
</span></code></td></tr><tr><td id="L495" class="css-a4x74f"><span>495</span></td><td id="LC495" class="css-1dcdqdg"><code><span class="code-comment"> * @argument {Element} element
</span></code></td></tr><tr><td id="L496" class="css-a4x74f"><span>496</span></td><td id="LC496" class="css-1dcdqdg"><code><span class="code-comment"> * @returns {Element} first transformed parent or documentElement
</span></code></td></tr><tr><td id="L497" class="css-a4x74f"><span>497</span></td><td id="LC497" class="css-1dcdqdg"><code><span class="code-comment"> */</span>
</code></td></tr><tr><td id="L498" class="css-a4x74f"><span>498</span></td><td id="LC498" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L499" class="css-a4x74f"><span>499</span></td><td id="LC499" class="css-1dcdqdg"><code><span class="code-function"><span class="code-keyword">function</span> <span class="code-title">getFixedPositionOffsetParent</span>(<span class="code-params">element</span>) </span>{
</code></td></tr><tr><td id="L500" class="css-a4x74f"><span>500</span></td><td id="LC500" class="css-1dcdqdg"><code>  <span class="code-comment">// This check is needed to avoid errors in case one of the elements isn't defined for any reason</span>
</code></td></tr><tr><td id="L501" class="css-a4x74f"><span>501</span></td><td id="LC501" class="css-1dcdqdg"><code>  <span class="code-keyword">if</span> (!element || !element.parentElement || isIE()) {
</code></td></tr><tr><td id="L502" class="css-a4x74f"><span>502</span></td><td id="LC502" class="css-1dcdqdg"><code>    <span class="code-keyword">return</span> <span class="code-built_in">document</span>.documentElement;
</code></td></tr><tr><td id="L503" class="css-a4x74f"><span>503</span></td><td id="LC503" class="css-1dcdqdg"><code>  }
</code></td></tr><tr><td id="L504" class="css-a4x74f"><span>504</span></td><td id="LC504" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> el = element.parentElement;
</code></td></tr><tr><td id="L505" class="css-a4x74f"><span>505</span></td><td id="LC505" class="css-1dcdqdg"><code>  <span class="code-keyword">while</span> (el &amp;&amp; getStyleComputedProperty(el, <span class="code-string">'transform'</span>) === <span class="code-string">'none'</span>) {
</code></td></tr><tr><td id="L506" class="css-a4x74f"><span>506</span></td><td id="LC506" class="css-1dcdqdg"><code>    el = el.parentElement;
</code></td></tr><tr><td id="L507" class="css-a4x74f"><span>507</span></td><td id="LC507" class="css-1dcdqdg"><code>  }
</code></td></tr><tr><td id="L508" class="css-a4x74f"><span>508</span></td><td id="LC508" class="css-1dcdqdg"><code>  <span class="code-keyword">return</span> el || <span class="code-built_in">document</span>.documentElement;
</code></td></tr><tr><td id="L509" class="css-a4x74f"><span>509</span></td><td id="LC509" class="css-1dcdqdg"><code>}
</code></td></tr><tr><td id="L510" class="css-a4x74f"><span>510</span></td><td id="LC510" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L511" class="css-a4x74f"><span>511</span></td><td id="LC511" class="css-1dcdqdg"><code><span class="code-comment">/**
</span></code></td></tr><tr><td id="L512" class="css-a4x74f"><span>512</span></td><td id="LC512" class="css-1dcdqdg"><code><span class="code-comment"> * Computed the boundaries limits and return them
</span></code></td></tr><tr><td id="L513" class="css-a4x74f"><span>513</span></td><td id="LC513" class="css-1dcdqdg"><code><span class="code-comment"> * @method
</span></code></td></tr><tr><td id="L514" class="css-a4x74f"><span>514</span></td><td id="LC514" class="css-1dcdqdg"><code><span class="code-comment"> * @memberof Popper.Utils
</span></code></td></tr><tr><td id="L515" class="css-a4x74f"><span>515</span></td><td id="LC515" class="css-1dcdqdg"><code><span class="code-comment"> * @param {HTMLElement} popper
</span></code></td></tr><tr><td id="L516" class="css-a4x74f"><span>516</span></td><td id="LC516" class="css-1dcdqdg"><code><span class="code-comment"> * @param {HTMLElement} reference
</span></code></td></tr><tr><td id="L517" class="css-a4x74f"><span>517</span></td><td id="LC517" class="css-1dcdqdg"><code><span class="code-comment"> * @param {number} padding
</span></code></td></tr><tr><td id="L518" class="css-a4x74f"><span>518</span></td><td id="LC518" class="css-1dcdqdg"><code><span class="code-comment"> * @param {HTMLElement} boundariesElement - Element used to define the boundaries
</span></code></td></tr><tr><td id="L519" class="css-a4x74f"><span>519</span></td><td id="LC519" class="css-1dcdqdg"><code><span class="code-comment"> * @param {Boolean} fixedPosition - Is in fixed position mode
</span></code></td></tr><tr><td id="L520" class="css-a4x74f"><span>520</span></td><td id="LC520" class="css-1dcdqdg"><code><span class="code-comment"> * @returns {Object} Coordinates of the boundaries
</span></code></td></tr><tr><td id="L521" class="css-a4x74f"><span>521</span></td><td id="LC521" class="css-1dcdqdg"><code><span class="code-comment"> */</span>
</code></td></tr><tr><td id="L522" class="css-a4x74f"><span>522</span></td><td id="LC522" class="css-1dcdqdg"><code><span class="code-function"><span class="code-keyword">function</span> <span class="code-title">getBoundaries</span>(<span class="code-params">popper, reference, padding, boundariesElement</span>) </span>{
</code></td></tr><tr><td id="L523" class="css-a4x74f"><span>523</span></td><td id="LC523" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> fixedPosition = <span class="code-built_in">arguments</span>.length &gt; <span class="code-number">4</span> &amp;&amp; <span class="code-built_in">arguments</span>[<span class="code-number">4</span>] !== <span class="code-literal">undefined</span> ? <span class="code-built_in">arguments</span>[<span class="code-number">4</span>] : <span class="code-literal">false</span>;
</code></td></tr><tr><td id="L524" class="css-a4x74f"><span>524</span></td><td id="LC524" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L525" class="css-a4x74f"><span>525</span></td><td id="LC525" class="css-1dcdqdg"><code>  <span class="code-comment">// <span class="code-doctag">NOTE:</span> 1 DOM access here</span>
</code></td></tr><tr><td id="L526" class="css-a4x74f"><span>526</span></td><td id="LC526" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L527" class="css-a4x74f"><span>527</span></td><td id="LC527" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> boundaries = { <span class="code-attr">top</span>: <span class="code-number">0</span>, <span class="code-attr">left</span>: <span class="code-number">0</span> };
</code></td></tr><tr><td id="L528" class="css-a4x74f"><span>528</span></td><td id="LC528" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> offsetParent = fixedPosition ? getFixedPositionOffsetParent(popper) : findCommonOffsetParent(popper, getReferenceNode(reference));
</code></td></tr><tr><td id="L529" class="css-a4x74f"><span>529</span></td><td id="LC529" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L530" class="css-a4x74f"><span>530</span></td><td id="LC530" class="css-1dcdqdg"><code>  <span class="code-comment">// Handle viewport case</span>
</code></td></tr><tr><td id="L531" class="css-a4x74f"><span>531</span></td><td id="LC531" class="css-1dcdqdg"><code>  <span class="code-keyword">if</span> (boundariesElement === <span class="code-string">'viewport'</span>) {
</code></td></tr><tr><td id="L532" class="css-a4x74f"><span>532</span></td><td id="LC532" class="css-1dcdqdg"><code>    boundaries = getViewportOffsetRectRelativeToArtbitraryNode(offsetParent, fixedPosition);
</code></td></tr><tr><td id="L533" class="css-a4x74f"><span>533</span></td><td id="LC533" class="css-1dcdqdg"><code>  } <span class="code-keyword">else</span> {
</code></td></tr><tr><td id="L534" class="css-a4x74f"><span>534</span></td><td id="LC534" class="css-1dcdqdg"><code>    <span class="code-comment">// Handle other cases based on DOM element used as boundaries</span>
</code></td></tr><tr><td id="L535" class="css-a4x74f"><span>535</span></td><td id="LC535" class="css-1dcdqdg"><code>    <span class="code-keyword">var</span> boundariesNode = <span class="code-keyword">void</span> <span class="code-number">0</span>;
</code></td></tr><tr><td id="L536" class="css-a4x74f"><span>536</span></td><td id="LC536" class="css-1dcdqdg"><code>    <span class="code-keyword">if</span> (boundariesElement === <span class="code-string">'scrollParent'</span>) {
</code></td></tr><tr><td id="L537" class="css-a4x74f"><span>537</span></td><td id="LC537" class="css-1dcdqdg"><code>      boundariesNode = getScrollParent(getParentNode(reference));
</code></td></tr><tr><td id="L538" class="css-a4x74f"><span>538</span></td><td id="LC538" class="css-1dcdqdg"><code>      <span class="code-keyword">if</span> (boundariesNode.nodeName === <span class="code-string">'BODY'</span>) {
</code></td></tr><tr><td id="L539" class="css-a4x74f"><span>539</span></td><td id="LC539" class="css-1dcdqdg"><code>        boundariesNode = popper.ownerDocument.documentElement;
</code></td></tr><tr><td id="L540" class="css-a4x74f"><span>540</span></td><td id="LC540" class="css-1dcdqdg"><code>      }
</code></td></tr><tr><td id="L541" class="css-a4x74f"><span>541</span></td><td id="LC541" class="css-1dcdqdg"><code>    } <span class="code-keyword">else</span> <span class="code-keyword">if</span> (boundariesElement === <span class="code-string">'window'</span>) {
</code></td></tr><tr><td id="L542" class="css-a4x74f"><span>542</span></td><td id="LC542" class="css-1dcdqdg"><code>      boundariesNode = popper.ownerDocument.documentElement;
</code></td></tr><tr><td id="L543" class="css-a4x74f"><span>543</span></td><td id="LC543" class="css-1dcdqdg"><code>    } <span class="code-keyword">else</span> {
</code></td></tr><tr><td id="L544" class="css-a4x74f"><span>544</span></td><td id="LC544" class="css-1dcdqdg"><code>      boundariesNode = boundariesElement;
</code></td></tr><tr><td id="L545" class="css-a4x74f"><span>545</span></td><td id="LC545" class="css-1dcdqdg"><code>    }
</code></td></tr><tr><td id="L546" class="css-a4x74f"><span>546</span></td><td id="LC546" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L547" class="css-a4x74f"><span>547</span></td><td id="LC547" class="css-1dcdqdg"><code>    <span class="code-keyword">var</span> offsets = getOffsetRectRelativeToArbitraryNode(boundariesNode, offsetParent, fixedPosition);
</code></td></tr><tr><td id="L548" class="css-a4x74f"><span>548</span></td><td id="LC548" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L549" class="css-a4x74f"><span>549</span></td><td id="LC549" class="css-1dcdqdg"><code>    <span class="code-comment">// In case of HTML, we need a different computation</span>
</code></td></tr><tr><td id="L550" class="css-a4x74f"><span>550</span></td><td id="LC550" class="css-1dcdqdg"><code>    <span class="code-keyword">if</span> (boundariesNode.nodeName === <span class="code-string">'HTML'</span> &amp;&amp; !isFixed(offsetParent)) {
</code></td></tr><tr><td id="L551" class="css-a4x74f"><span>551</span></td><td id="LC551" class="css-1dcdqdg"><code>      <span class="code-keyword">var</span> _getWindowSizes = getWindowSizes(popper.ownerDocument),
</code></td></tr><tr><td id="L552" class="css-a4x74f"><span>552</span></td><td id="LC552" class="css-1dcdqdg"><code>          height = _getWindowSizes.height,
</code></td></tr><tr><td id="L553" class="css-a4x74f"><span>553</span></td><td id="LC553" class="css-1dcdqdg"><code>          width = _getWindowSizes.width;
</code></td></tr><tr><td id="L554" class="css-a4x74f"><span>554</span></td><td id="LC554" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L555" class="css-a4x74f"><span>555</span></td><td id="LC555" class="css-1dcdqdg"><code>      boundaries.top += offsets.top - offsets.marginTop;
</code></td></tr><tr><td id="L556" class="css-a4x74f"><span>556</span></td><td id="LC556" class="css-1dcdqdg"><code>      boundaries.bottom = height + offsets.top;
</code></td></tr><tr><td id="L557" class="css-a4x74f"><span>557</span></td><td id="LC557" class="css-1dcdqdg"><code>      boundaries.left += offsets.left - offsets.marginLeft;
</code></td></tr><tr><td id="L558" class="css-a4x74f"><span>558</span></td><td id="LC558" class="css-1dcdqdg"><code>      boundaries.right = width + offsets.left;
</code></td></tr><tr><td id="L559" class="css-a4x74f"><span>559</span></td><td id="LC559" class="css-1dcdqdg"><code>    } <span class="code-keyword">else</span> {
</code></td></tr><tr><td id="L560" class="css-a4x74f"><span>560</span></td><td id="LC560" class="css-1dcdqdg"><code>      <span class="code-comment">// for all the other DOM elements, this one is good</span>
</code></td></tr><tr><td id="L561" class="css-a4x74f"><span>561</span></td><td id="LC561" class="css-1dcdqdg"><code>      boundaries = offsets;
</code></td></tr><tr><td id="L562" class="css-a4x74f"><span>562</span></td><td id="LC562" class="css-1dcdqdg"><code>    }
</code></td></tr><tr><td id="L563" class="css-a4x74f"><span>563</span></td><td id="LC563" class="css-1dcdqdg"><code>  }
</code></td></tr><tr><td id="L564" class="css-a4x74f"><span>564</span></td><td id="LC564" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L565" class="css-a4x74f"><span>565</span></td><td id="LC565" class="css-1dcdqdg"><code>  <span class="code-comment">// Add paddings</span>
</code></td></tr><tr><td id="L566" class="css-a4x74f"><span>566</span></td><td id="LC566" class="css-1dcdqdg"><code>  padding = padding || <span class="code-number">0</span>;
</code></td></tr><tr><td id="L567" class="css-a4x74f"><span>567</span></td><td id="LC567" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> isPaddingNumber = <span class="code-keyword">typeof</span> padding === <span class="code-string">'number'</span>;
</code></td></tr><tr><td id="L568" class="css-a4x74f"><span>568</span></td><td id="LC568" class="css-1dcdqdg"><code>  boundaries.left += isPaddingNumber ? padding : padding.left || <span class="code-number">0</span>;
</code></td></tr><tr><td id="L569" class="css-a4x74f"><span>569</span></td><td id="LC569" class="css-1dcdqdg"><code>  boundaries.top += isPaddingNumber ? padding : padding.top || <span class="code-number">0</span>;
</code></td></tr><tr><td id="L570" class="css-a4x74f"><span>570</span></td><td id="LC570" class="css-1dcdqdg"><code>  boundaries.right -= isPaddingNumber ? padding : padding.right || <span class="code-number">0</span>;
</code></td></tr><tr><td id="L571" class="css-a4x74f"><span>571</span></td><td id="LC571" class="css-1dcdqdg"><code>  boundaries.bottom -= isPaddingNumber ? padding : padding.bottom || <span class="code-number">0</span>;
</code></td></tr><tr><td id="L572" class="css-a4x74f"><span>572</span></td><td id="LC572" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L573" class="css-a4x74f"><span>573</span></td><td id="LC573" class="css-1dcdqdg"><code>  <span class="code-keyword">return</span> boundaries;
</code></td></tr><tr><td id="L574" class="css-a4x74f"><span>574</span></td><td id="LC574" class="css-1dcdqdg"><code>}
</code></td></tr><tr><td id="L575" class="css-a4x74f"><span>575</span></td><td id="LC575" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L576" class="css-a4x74f"><span>576</span></td><td id="LC576" class="css-1dcdqdg"><code><span class="code-function"><span class="code-keyword">function</span> <span class="code-title">getArea</span>(<span class="code-params">_ref</span>) </span>{
</code></td></tr><tr><td id="L577" class="css-a4x74f"><span>577</span></td><td id="LC577" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> width = _ref.width,
</code></td></tr><tr><td id="L578" class="css-a4x74f"><span>578</span></td><td id="LC578" class="css-1dcdqdg"><code>      height = _ref.height;
</code></td></tr><tr><td id="L579" class="css-a4x74f"><span>579</span></td><td id="LC579" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L580" class="css-a4x74f"><span>580</span></td><td id="LC580" class="css-1dcdqdg"><code>  <span class="code-keyword">return</span> width * height;
</code></td></tr><tr><td id="L581" class="css-a4x74f"><span>581</span></td><td id="LC581" class="css-1dcdqdg"><code>}
</code></td></tr><tr><td id="L582" class="css-a4x74f"><span>582</span></td><td id="LC582" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L583" class="css-a4x74f"><span>583</span></td><td id="LC583" class="css-1dcdqdg"><code><span class="code-comment">/**
</span></code></td></tr><tr><td id="L584" class="css-a4x74f"><span>584</span></td><td id="LC584" class="css-1dcdqdg"><code><span class="code-comment"> * Utility used to transform the `auto` placement to the placement with more
</span></code></td></tr><tr><td id="L585" class="css-a4x74f"><span>585</span></td><td id="LC585" class="css-1dcdqdg"><code><span class="code-comment"> * available space.
</span></code></td></tr><tr><td id="L586" class="css-a4x74f"><span>586</span></td><td id="LC586" class="css-1dcdqdg"><code><span class="code-comment"> * @method
</span></code></td></tr><tr><td id="L587" class="css-a4x74f"><span>587</span></td><td id="LC587" class="css-1dcdqdg"><code><span class="code-comment"> * @memberof Popper.Utils
</span></code></td></tr><tr><td id="L588" class="css-a4x74f"><span>588</span></td><td id="LC588" class="css-1dcdqdg"><code><span class="code-comment"> * @argument {Object} data - The data object generated by update method
</span></code></td></tr><tr><td id="L589" class="css-a4x74f"><span>589</span></td><td id="LC589" class="css-1dcdqdg"><code><span class="code-comment"> * @argument {Object} options - Modifiers configuration and options
</span></code></td></tr><tr><td id="L590" class="css-a4x74f"><span>590</span></td><td id="LC590" class="css-1dcdqdg"><code><span class="code-comment"> * @returns {Object} The data object, properly modified
</span></code></td></tr><tr><td id="L591" class="css-a4x74f"><span>591</span></td><td id="LC591" class="css-1dcdqdg"><code><span class="code-comment"> */</span>
</code></td></tr><tr><td id="L592" class="css-a4x74f"><span>592</span></td><td id="LC592" class="css-1dcdqdg"><code><span class="code-function"><span class="code-keyword">function</span> <span class="code-title">computeAutoPlacement</span>(<span class="code-params">placement, refRect, popper, reference, boundariesElement</span>) </span>{
</code></td></tr><tr><td id="L593" class="css-a4x74f"><span>593</span></td><td id="LC593" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> padding = <span class="code-built_in">arguments</span>.length &gt; <span class="code-number">5</span> &amp;&amp; <span class="code-built_in">arguments</span>[<span class="code-number">5</span>] !== <span class="code-literal">undefined</span> ? <span class="code-built_in">arguments</span>[<span class="code-number">5</span>] : <span class="code-number">0</span>;
</code></td></tr><tr><td id="L594" class="css-a4x74f"><span>594</span></td><td id="LC594" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L595" class="css-a4x74f"><span>595</span></td><td id="LC595" class="css-1dcdqdg"><code>  <span class="code-keyword">if</span> (placement.indexOf(<span class="code-string">'auto'</span>) === <span class="code-number">-1</span>) {
</code></td></tr><tr><td id="L596" class="css-a4x74f"><span>596</span></td><td id="LC596" class="css-1dcdqdg"><code>    <span class="code-keyword">return</span> placement;
</code></td></tr><tr><td id="L597" class="css-a4x74f"><span>597</span></td><td id="LC597" class="css-1dcdqdg"><code>  }
</code></td></tr><tr><td id="L598" class="css-a4x74f"><span>598</span></td><td id="LC598" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L599" class="css-a4x74f"><span>599</span></td><td id="LC599" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> boundaries = getBoundaries(popper, reference, padding, boundariesElement);
</code></td></tr><tr><td id="L600" class="css-a4x74f"><span>600</span></td><td id="LC600" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L601" class="css-a4x74f"><span>601</span></td><td id="LC601" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> rects = {
</code></td></tr><tr><td id="L602" class="css-a4x74f"><span>602</span></td><td id="LC602" class="css-1dcdqdg"><code>    top: {
</code></td></tr><tr><td id="L603" class="css-a4x74f"><span>603</span></td><td id="LC603" class="css-1dcdqdg"><code>      width: boundaries.width,
</code></td></tr><tr><td id="L604" class="css-a4x74f"><span>604</span></td><td id="LC604" class="css-1dcdqdg"><code>      height: refRect.top - boundaries.top
</code></td></tr><tr><td id="L605" class="css-a4x74f"><span>605</span></td><td id="LC605" class="css-1dcdqdg"><code>    },
</code></td></tr><tr><td id="L606" class="css-a4x74f"><span>606</span></td><td id="LC606" class="css-1dcdqdg"><code>    right: {
</code></td></tr><tr><td id="L607" class="css-a4x74f"><span>607</span></td><td id="LC607" class="css-1dcdqdg"><code>      width: boundaries.right - refRect.right,
</code></td></tr><tr><td id="L608" class="css-a4x74f"><span>608</span></td><td id="LC608" class="css-1dcdqdg"><code>      height: boundaries.height
</code></td></tr><tr><td id="L609" class="css-a4x74f"><span>609</span></td><td id="LC609" class="css-1dcdqdg"><code>    },
</code></td></tr><tr><td id="L610" class="css-a4x74f"><span>610</span></td><td id="LC610" class="css-1dcdqdg"><code>    bottom: {
</code></td></tr><tr><td id="L611" class="css-a4x74f"><span>611</span></td><td id="LC611" class="css-1dcdqdg"><code>      width: boundaries.width,
</code></td></tr><tr><td id="L612" class="css-a4x74f"><span>612</span></td><td id="LC612" class="css-1dcdqdg"><code>      height: boundaries.bottom - refRect.bottom
</code></td></tr><tr><td id="L613" class="css-a4x74f"><span>613</span></td><td id="LC613" class="css-1dcdqdg"><code>    },
</code></td></tr><tr><td id="L614" class="css-a4x74f"><span>614</span></td><td id="LC614" class="css-1dcdqdg"><code>    left: {
</code></td></tr><tr><td id="L615" class="css-a4x74f"><span>615</span></td><td id="LC615" class="css-1dcdqdg"><code>      width: refRect.left - boundaries.left,
</code></td></tr><tr><td id="L616" class="css-a4x74f"><span>616</span></td><td id="LC616" class="css-1dcdqdg"><code>      height: boundaries.height
</code></td></tr><tr><td id="L617" class="css-a4x74f"><span>617</span></td><td id="LC617" class="css-1dcdqdg"><code>    }
</code></td></tr><tr><td id="L618" class="css-a4x74f"><span>618</span></td><td id="LC618" class="css-1dcdqdg"><code>  };
</code></td></tr><tr><td id="L619" class="css-a4x74f"><span>619</span></td><td id="LC619" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L620" class="css-a4x74f"><span>620</span></td><td id="LC620" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> sortedAreas = <span class="code-built_in">Object</span>.keys(rects).map(<span class="code-function"><span class="code-keyword">function</span> (<span class="code-params">key</span>) </span>{
</code></td></tr><tr><td id="L621" class="css-a4x74f"><span>621</span></td><td id="LC621" class="css-1dcdqdg"><code>    <span class="code-keyword">return</span> _extends({
</code></td></tr><tr><td id="L622" class="css-a4x74f"><span>622</span></td><td id="LC622" class="css-1dcdqdg"><code>      key: key
</code></td></tr><tr><td id="L623" class="css-a4x74f"><span>623</span></td><td id="LC623" class="css-1dcdqdg"><code>    }, rects[key], {
</code></td></tr><tr><td id="L624" class="css-a4x74f"><span>624</span></td><td id="LC624" class="css-1dcdqdg"><code>      area: getArea(rects[key])
</code></td></tr><tr><td id="L625" class="css-a4x74f"><span>625</span></td><td id="LC625" class="css-1dcdqdg"><code>    });
</code></td></tr><tr><td id="L626" class="css-a4x74f"><span>626</span></td><td id="LC626" class="css-1dcdqdg"><code>  }).sort(<span class="code-function"><span class="code-keyword">function</span> (<span class="code-params">a, b</span>) </span>{
</code></td></tr><tr><td id="L627" class="css-a4x74f"><span>627</span></td><td id="LC627" class="css-1dcdqdg"><code>    <span class="code-keyword">return</span> b.area - a.area;
</code></td></tr><tr><td id="L628" class="css-a4x74f"><span>628</span></td><td id="LC628" class="css-1dcdqdg"><code>  });
</code></td></tr><tr><td id="L629" class="css-a4x74f"><span>629</span></td><td id="LC629" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L630" class="css-a4x74f"><span>630</span></td><td id="LC630" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> filteredAreas = sortedAreas.filter(<span class="code-function"><span class="code-keyword">function</span> (<span class="code-params">_ref2</span>) </span>{
</code></td></tr><tr><td id="L631" class="css-a4x74f"><span>631</span></td><td id="LC631" class="css-1dcdqdg"><code>    <span class="code-keyword">var</span> width = _ref2.width,
</code></td></tr><tr><td id="L632" class="css-a4x74f"><span>632</span></td><td id="LC632" class="css-1dcdqdg"><code>        height = _ref2.height;
</code></td></tr><tr><td id="L633" class="css-a4x74f"><span>633</span></td><td id="LC633" class="css-1dcdqdg"><code>    <span class="code-keyword">return</span> width &gt;= popper.clientWidth &amp;&amp; height &gt;= popper.clientHeight;
</code></td></tr><tr><td id="L634" class="css-a4x74f"><span>634</span></td><td id="LC634" class="css-1dcdqdg"><code>  });
</code></td></tr><tr><td id="L635" class="css-a4x74f"><span>635</span></td><td id="LC635" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L636" class="css-a4x74f"><span>636</span></td><td id="LC636" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> computedPlacement = filteredAreas.length &gt; <span class="code-number">0</span> ? filteredAreas[<span class="code-number">0</span>].key : sortedAreas[<span class="code-number">0</span>].key;
</code></td></tr><tr><td id="L637" class="css-a4x74f"><span>637</span></td><td id="LC637" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L638" class="css-a4x74f"><span>638</span></td><td id="LC638" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> variation = placement.split(<span class="code-string">'-'</span>)[<span class="code-number">1</span>];
</code></td></tr><tr><td id="L639" class="css-a4x74f"><span>639</span></td><td id="LC639" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L640" class="css-a4x74f"><span>640</span></td><td id="LC640" class="css-1dcdqdg"><code>  <span class="code-keyword">return</span> computedPlacement + (variation ? <span class="code-string">'-'</span> + variation : <span class="code-string">''</span>);
</code></td></tr><tr><td id="L641" class="css-a4x74f"><span>641</span></td><td id="LC641" class="css-1dcdqdg"><code>}
</code></td></tr><tr><td id="L642" class="css-a4x74f"><span>642</span></td><td id="LC642" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L643" class="css-a4x74f"><span>643</span></td><td id="LC643" class="css-1dcdqdg"><code><span class="code-keyword">var</span> timeoutDuration = <span class="code-function"><span class="code-keyword">function</span> (<span class="code-params"></span>) </span>{
</code></td></tr><tr><td id="L644" class="css-a4x74f"><span>644</span></td><td id="LC644" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> longerTimeoutBrowsers = [<span class="code-string">'Edge'</span>, <span class="code-string">'Trident'</span>, <span class="code-string">'Firefox'</span>];
</code></td></tr><tr><td id="L645" class="css-a4x74f"><span>645</span></td><td id="LC645" class="css-1dcdqdg"><code>  <span class="code-keyword">for</span> (<span class="code-keyword">var</span> i = <span class="code-number">0</span>; i &lt; longerTimeoutBrowsers.length; i += <span class="code-number">1</span>) {
</code></td></tr><tr><td id="L646" class="css-a4x74f"><span>646</span></td><td id="LC646" class="css-1dcdqdg"><code>    <span class="code-keyword">if</span> (isBrowser &amp;&amp; navigator.userAgent.indexOf(longerTimeoutBrowsers[i]) &gt;= <span class="code-number">0</span>) {
</code></td></tr><tr><td id="L647" class="css-a4x74f"><span>647</span></td><td id="LC647" class="css-1dcdqdg"><code>      <span class="code-keyword">return</span> <span class="code-number">1</span>;
</code></td></tr><tr><td id="L648" class="css-a4x74f"><span>648</span></td><td id="LC648" class="css-1dcdqdg"><code>    }
</code></td></tr><tr><td id="L649" class="css-a4x74f"><span>649</span></td><td id="LC649" class="css-1dcdqdg"><code>  }
</code></td></tr><tr><td id="L650" class="css-a4x74f"><span>650</span></td><td id="LC650" class="css-1dcdqdg"><code>  <span class="code-keyword">return</span> <span class="code-number">0</span>;
</code></td></tr><tr><td id="L651" class="css-a4x74f"><span>651</span></td><td id="LC651" class="css-1dcdqdg"><code>}();
</code></td></tr><tr><td id="L652" class="css-a4x74f"><span>652</span></td><td id="LC652" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L653" class="css-a4x74f"><span>653</span></td><td id="LC653" class="css-1dcdqdg"><code><span class="code-function"><span class="code-keyword">function</span> <span class="code-title">microtaskDebounce</span>(<span class="code-params">fn</span>) </span>{
</code></td></tr><tr><td id="L654" class="css-a4x74f"><span>654</span></td><td id="LC654" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> called = <span class="code-literal">false</span>;
</code></td></tr><tr><td id="L655" class="css-a4x74f"><span>655</span></td><td id="LC655" class="css-1dcdqdg"><code>  <span class="code-keyword">return</span> <span class="code-function"><span class="code-keyword">function</span> (<span class="code-params"></span>) </span>{
</code></td></tr><tr><td id="L656" class="css-a4x74f"><span>656</span></td><td id="LC656" class="css-1dcdqdg"><code>    <span class="code-keyword">if</span> (called) {
</code></td></tr><tr><td id="L657" class="css-a4x74f"><span>657</span></td><td id="LC657" class="css-1dcdqdg"><code>      <span class="code-keyword">return</span>;
</code></td></tr><tr><td id="L658" class="css-a4x74f"><span>658</span></td><td id="LC658" class="css-1dcdqdg"><code>    }
</code></td></tr><tr><td id="L659" class="css-a4x74f"><span>659</span></td><td id="LC659" class="css-1dcdqdg"><code>    called = <span class="code-literal">true</span>;
</code></td></tr><tr><td id="L660" class="css-a4x74f"><span>660</span></td><td id="LC660" class="css-1dcdqdg"><code>    <span class="code-built_in">window</span>.Promise.resolve().then(<span class="code-function"><span class="code-keyword">function</span> (<span class="code-params"></span>) </span>{
</code></td></tr><tr><td id="L661" class="css-a4x74f"><span>661</span></td><td id="LC661" class="css-1dcdqdg"><code>      called = <span class="code-literal">false</span>;
</code></td></tr><tr><td id="L662" class="css-a4x74f"><span>662</span></td><td id="LC662" class="css-1dcdqdg"><code>      fn();
</code></td></tr><tr><td id="L663" class="css-a4x74f"><span>663</span></td><td id="LC663" class="css-1dcdqdg"><code>    });
</code></td></tr><tr><td id="L664" class="css-a4x74f"><span>664</span></td><td id="LC664" class="css-1dcdqdg"><code>  };
</code></td></tr><tr><td id="L665" class="css-a4x74f"><span>665</span></td><td id="LC665" class="css-1dcdqdg"><code>}
</code></td></tr><tr><td id="L666" class="css-a4x74f"><span>666</span></td><td id="LC666" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L667" class="css-a4x74f"><span>667</span></td><td id="LC667" class="css-1dcdqdg"><code><span class="code-function"><span class="code-keyword">function</span> <span class="code-title">taskDebounce</span>(<span class="code-params">fn</span>) </span>{
</code></td></tr><tr><td id="L668" class="css-a4x74f"><span>668</span></td><td id="LC668" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> scheduled = <span class="code-literal">false</span>;
</code></td></tr><tr><td id="L669" class="css-a4x74f"><span>669</span></td><td id="LC669" class="css-1dcdqdg"><code>  <span class="code-keyword">return</span> <span class="code-function"><span class="code-keyword">function</span> (<span class="code-params"></span>) </span>{
</code></td></tr><tr><td id="L670" class="css-a4x74f"><span>670</span></td><td id="LC670" class="css-1dcdqdg"><code>    <span class="code-keyword">if</span> (!scheduled) {
</code></td></tr><tr><td id="L671" class="css-a4x74f"><span>671</span></td><td id="LC671" class="css-1dcdqdg"><code>      scheduled = <span class="code-literal">true</span>;
</code></td></tr><tr><td id="L672" class="css-a4x74f"><span>672</span></td><td id="LC672" class="css-1dcdqdg"><code>      setTimeout(<span class="code-function"><span class="code-keyword">function</span> (<span class="code-params"></span>) </span>{
</code></td></tr><tr><td id="L673" class="css-a4x74f"><span>673</span></td><td id="LC673" class="css-1dcdqdg"><code>        scheduled = <span class="code-literal">false</span>;
</code></td></tr><tr><td id="L674" class="css-a4x74f"><span>674</span></td><td id="LC674" class="css-1dcdqdg"><code>        fn();
</code></td></tr><tr><td id="L675" class="css-a4x74f"><span>675</span></td><td id="LC675" class="css-1dcdqdg"><code>      }, timeoutDuration);
</code></td></tr><tr><td id="L676" class="css-a4x74f"><span>676</span></td><td id="LC676" class="css-1dcdqdg"><code>    }
</code></td></tr><tr><td id="L677" class="css-a4x74f"><span>677</span></td><td id="LC677" class="css-1dcdqdg"><code>  };
</code></td></tr><tr><td id="L678" class="css-a4x74f"><span>678</span></td><td id="LC678" class="css-1dcdqdg"><code>}
</code></td></tr><tr><td id="L679" class="css-a4x74f"><span>679</span></td><td id="LC679" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L680" class="css-a4x74f"><span>680</span></td><td id="LC680" class="css-1dcdqdg"><code><span class="code-keyword">var</span> supportsMicroTasks = isBrowser &amp;&amp; <span class="code-built_in">window</span>.Promise;
</code></td></tr><tr><td id="L681" class="css-a4x74f"><span>681</span></td><td id="LC681" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L682" class="css-a4x74f"><span>682</span></td><td id="LC682" class="css-1dcdqdg"><code><span class="code-comment">/**
</span></code></td></tr><tr><td id="L683" class="css-a4x74f"><span>683</span></td><td id="LC683" class="css-1dcdqdg"><code><span class="code-comment">* Create a debounced version of a method, that's asynchronously deferred
</span></code></td></tr><tr><td id="L684" class="css-a4x74f"><span>684</span></td><td id="LC684" class="css-1dcdqdg"><code><span class="code-comment">* but called in the minimum time possible.
</span></code></td></tr><tr><td id="L685" class="css-a4x74f"><span>685</span></td><td id="LC685" class="css-1dcdqdg"><code><span class="code-comment">*
</span></code></td></tr><tr><td id="L686" class="css-a4x74f"><span>686</span></td><td id="LC686" class="css-1dcdqdg"><code><span class="code-comment">* @method
</span></code></td></tr><tr><td id="L687" class="css-a4x74f"><span>687</span></td><td id="LC687" class="css-1dcdqdg"><code><span class="code-comment">* @memberof Popper.Utils
</span></code></td></tr><tr><td id="L688" class="css-a4x74f"><span>688</span></td><td id="LC688" class="css-1dcdqdg"><code><span class="code-comment">* @argument {Function} fn
</span></code></td></tr><tr><td id="L689" class="css-a4x74f"><span>689</span></td><td id="LC689" class="css-1dcdqdg"><code><span class="code-comment">* @returns {Function}
</span></code></td></tr><tr><td id="L690" class="css-a4x74f"><span>690</span></td><td id="LC690" class="css-1dcdqdg"><code><span class="code-comment">*/</span>
</code></td></tr><tr><td id="L691" class="css-a4x74f"><span>691</span></td><td id="LC691" class="css-1dcdqdg"><code><span class="code-keyword">var</span> debounce = supportsMicroTasks ? microtaskDebounce : taskDebounce;
</code></td></tr><tr><td id="L692" class="css-a4x74f"><span>692</span></td><td id="LC692" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L693" class="css-a4x74f"><span>693</span></td><td id="LC693" class="css-1dcdqdg"><code><span class="code-comment">/**
</span></code></td></tr><tr><td id="L694" class="css-a4x74f"><span>694</span></td><td id="LC694" class="css-1dcdqdg"><code><span class="code-comment"> * Mimics the `find` method of Array
</span></code></td></tr><tr><td id="L695" class="css-a4x74f"><span>695</span></td><td id="LC695" class="css-1dcdqdg"><code><span class="code-comment"> * @method
</span></code></td></tr><tr><td id="L696" class="css-a4x74f"><span>696</span></td><td id="LC696" class="css-1dcdqdg"><code><span class="code-comment"> * @memberof Popper.Utils
</span></code></td></tr><tr><td id="L697" class="css-a4x74f"><span>697</span></td><td id="LC697" class="css-1dcdqdg"><code><span class="code-comment"> * @argument {Array} arr
</span></code></td></tr><tr><td id="L698" class="css-a4x74f"><span>698</span></td><td id="LC698" class="css-1dcdqdg"><code><span class="code-comment"> * @argument prop
</span></code></td></tr><tr><td id="L699" class="css-a4x74f"><span>699</span></td><td id="LC699" class="css-1dcdqdg"><code><span class="code-comment"> * @argument value
</span></code></td></tr><tr><td id="L700" class="css-a4x74f"><span>700</span></td><td id="LC700" class="css-1dcdqdg"><code><span class="code-comment"> * @returns index or -1
</span></code></td></tr><tr><td id="L701" class="css-a4x74f"><span>701</span></td><td id="LC701" class="css-1dcdqdg"><code><span class="code-comment"> */</span>
</code></td></tr><tr><td id="L702" class="css-a4x74f"><span>702</span></td><td id="LC702" class="css-1dcdqdg"><code><span class="code-function"><span class="code-keyword">function</span> <span class="code-title">find</span>(<span class="code-params">arr, check</span>) </span>{
</code></td></tr><tr><td id="L703" class="css-a4x74f"><span>703</span></td><td id="LC703" class="css-1dcdqdg"><code>  <span class="code-comment">// use native find if supported</span>
</code></td></tr><tr><td id="L704" class="css-a4x74f"><span>704</span></td><td id="LC704" class="css-1dcdqdg"><code>  <span class="code-keyword">if</span> (<span class="code-built_in">Array</span>.prototype.find) {
</code></td></tr><tr><td id="L705" class="css-a4x74f"><span>705</span></td><td id="LC705" class="css-1dcdqdg"><code>    <span class="code-keyword">return</span> arr.find(check);
</code></td></tr><tr><td id="L706" class="css-a4x74f"><span>706</span></td><td id="LC706" class="css-1dcdqdg"><code>  }
</code></td></tr><tr><td id="L707" class="css-a4x74f"><span>707</span></td><td id="LC707" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L708" class="css-a4x74f"><span>708</span></td><td id="LC708" class="css-1dcdqdg"><code>  <span class="code-comment">// use `filter` to obtain the same behavior of `find`</span>
</code></td></tr><tr><td id="L709" class="css-a4x74f"><span>709</span></td><td id="LC709" class="css-1dcdqdg"><code>  <span class="code-keyword">return</span> arr.filter(check)[<span class="code-number">0</span>];
</code></td></tr><tr><td id="L710" class="css-a4x74f"><span>710</span></td><td id="LC710" class="css-1dcdqdg"><code>}
</code></td></tr><tr><td id="L711" class="css-a4x74f"><span>711</span></td><td id="LC711" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L712" class="css-a4x74f"><span>712</span></td><td id="LC712" class="css-1dcdqdg"><code><span class="code-comment">/**
</span></code></td></tr><tr><td id="L713" class="css-a4x74f"><span>713</span></td><td id="LC713" class="css-1dcdqdg"><code><span class="code-comment"> * Return the index of the matching object
</span></code></td></tr><tr><td id="L714" class="css-a4x74f"><span>714</span></td><td id="LC714" class="css-1dcdqdg"><code><span class="code-comment"> * @method
</span></code></td></tr><tr><td id="L715" class="css-a4x74f"><span>715</span></td><td id="LC715" class="css-1dcdqdg"><code><span class="code-comment"> * @memberof Popper.Utils
</span></code></td></tr><tr><td id="L716" class="css-a4x74f"><span>716</span></td><td id="LC716" class="css-1dcdqdg"><code><span class="code-comment"> * @argument {Array} arr
</span></code></td></tr><tr><td id="L717" class="css-a4x74f"><span>717</span></td><td id="LC717" class="css-1dcdqdg"><code><span class="code-comment"> * @argument prop
</span></code></td></tr><tr><td id="L718" class="css-a4x74f"><span>718</span></td><td id="LC718" class="css-1dcdqdg"><code><span class="code-comment"> * @argument value
</span></code></td></tr><tr><td id="L719" class="css-a4x74f"><span>719</span></td><td id="LC719" class="css-1dcdqdg"><code><span class="code-comment"> * @returns index or -1
</span></code></td></tr><tr><td id="L720" class="css-a4x74f"><span>720</span></td><td id="LC720" class="css-1dcdqdg"><code><span class="code-comment"> */</span>
</code></td></tr><tr><td id="L721" class="css-a4x74f"><span>721</span></td><td id="LC721" class="css-1dcdqdg"><code><span class="code-function"><span class="code-keyword">function</span> <span class="code-title">findIndex</span>(<span class="code-params">arr, prop, value</span>) </span>{
</code></td></tr><tr><td id="L722" class="css-a4x74f"><span>722</span></td><td id="LC722" class="css-1dcdqdg"><code>  <span class="code-comment">// use native findIndex if supported</span>
</code></td></tr><tr><td id="L723" class="css-a4x74f"><span>723</span></td><td id="LC723" class="css-1dcdqdg"><code>  <span class="code-keyword">if</span> (<span class="code-built_in">Array</span>.prototype.findIndex) {
</code></td></tr><tr><td id="L724" class="css-a4x74f"><span>724</span></td><td id="LC724" class="css-1dcdqdg"><code>    <span class="code-keyword">return</span> arr.findIndex(<span class="code-function"><span class="code-keyword">function</span> (<span class="code-params">cur</span>) </span>{
</code></td></tr><tr><td id="L725" class="css-a4x74f"><span>725</span></td><td id="LC725" class="css-1dcdqdg"><code>      <span class="code-keyword">return</span> cur[prop] === value;
</code></td></tr><tr><td id="L726" class="css-a4x74f"><span>726</span></td><td id="LC726" class="css-1dcdqdg"><code>    });
</code></td></tr><tr><td id="L727" class="css-a4x74f"><span>727</span></td><td id="LC727" class="css-1dcdqdg"><code>  }
</code></td></tr><tr><td id="L728" class="css-a4x74f"><span>728</span></td><td id="LC728" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L729" class="css-a4x74f"><span>729</span></td><td id="LC729" class="css-1dcdqdg"><code>  <span class="code-comment">// use `find` + `indexOf` if `findIndex` isn't supported</span>
</code></td></tr><tr><td id="L730" class="css-a4x74f"><span>730</span></td><td id="LC730" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> match = find(arr, <span class="code-function"><span class="code-keyword">function</span> (<span class="code-params">obj</span>) </span>{
</code></td></tr><tr><td id="L731" class="css-a4x74f"><span>731</span></td><td id="LC731" class="css-1dcdqdg"><code>    <span class="code-keyword">return</span> obj[prop] === value;
</code></td></tr><tr><td id="L732" class="css-a4x74f"><span>732</span></td><td id="LC732" class="css-1dcdqdg"><code>  });
</code></td></tr><tr><td id="L733" class="css-a4x74f"><span>733</span></td><td id="LC733" class="css-1dcdqdg"><code>  <span class="code-keyword">return</span> arr.indexOf(match);
</code></td></tr><tr><td id="L734" class="css-a4x74f"><span>734</span></td><td id="LC734" class="css-1dcdqdg"><code>}
</code></td></tr><tr><td id="L735" class="css-a4x74f"><span>735</span></td><td id="LC735" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L736" class="css-a4x74f"><span>736</span></td><td id="LC736" class="css-1dcdqdg"><code><span class="code-comment">/**
</span></code></td></tr><tr><td id="L737" class="css-a4x74f"><span>737</span></td><td id="LC737" class="css-1dcdqdg"><code><span class="code-comment"> * Get the position of the given element, relative to its offset parent
</span></code></td></tr><tr><td id="L738" class="css-a4x74f"><span>738</span></td><td id="LC738" class="css-1dcdqdg"><code><span class="code-comment"> * @method
</span></code></td></tr><tr><td id="L739" class="css-a4x74f"><span>739</span></td><td id="LC739" class="css-1dcdqdg"><code><span class="code-comment"> * @memberof Popper.Utils
</span></code></td></tr><tr><td id="L740" class="css-a4x74f"><span>740</span></td><td id="LC740" class="css-1dcdqdg"><code><span class="code-comment"> * @param {Element} element
</span></code></td></tr><tr><td id="L741" class="css-a4x74f"><span>741</span></td><td id="LC741" class="css-1dcdqdg"><code><span class="code-comment"> * @return {Object} position - Coordinates of the element and its `scrollTop`
</span></code></td></tr><tr><td id="L742" class="css-a4x74f"><span>742</span></td><td id="LC742" class="css-1dcdqdg"><code><span class="code-comment"> */</span>
</code></td></tr><tr><td id="L743" class="css-a4x74f"><span>743</span></td><td id="LC743" class="css-1dcdqdg"><code><span class="code-function"><span class="code-keyword">function</span> <span class="code-title">getOffsetRect</span>(<span class="code-params">element</span>) </span>{
</code></td></tr><tr><td id="L744" class="css-a4x74f"><span>744</span></td><td id="LC744" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> elementRect = <span class="code-keyword">void</span> <span class="code-number">0</span>;
</code></td></tr><tr><td id="L745" class="css-a4x74f"><span>745</span></td><td id="LC745" class="css-1dcdqdg"><code>  <span class="code-keyword">if</span> (element.nodeName === <span class="code-string">'HTML'</span>) {
</code></td></tr><tr><td id="L746" class="css-a4x74f"><span>746</span></td><td id="LC746" class="css-1dcdqdg"><code>    <span class="code-keyword">var</span> _getWindowSizes = getWindowSizes(element.ownerDocument),
</code></td></tr><tr><td id="L747" class="css-a4x74f"><span>747</span></td><td id="LC747" class="css-1dcdqdg"><code>        width = _getWindowSizes.width,
</code></td></tr><tr><td id="L748" class="css-a4x74f"><span>748</span></td><td id="LC748" class="css-1dcdqdg"><code>        height = _getWindowSizes.height;
</code></td></tr><tr><td id="L749" class="css-a4x74f"><span>749</span></td><td id="LC749" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L750" class="css-a4x74f"><span>750</span></td><td id="LC750" class="css-1dcdqdg"><code>    elementRect = {
</code></td></tr><tr><td id="L751" class="css-a4x74f"><span>751</span></td><td id="LC751" class="css-1dcdqdg"><code>      width: width,
</code></td></tr><tr><td id="L752" class="css-a4x74f"><span>752</span></td><td id="LC752" class="css-1dcdqdg"><code>      height: height,
</code></td></tr><tr><td id="L753" class="css-a4x74f"><span>753</span></td><td id="LC753" class="css-1dcdqdg"><code>      left: <span class="code-number">0</span>,
</code></td></tr><tr><td id="L754" class="css-a4x74f"><span>754</span></td><td id="LC754" class="css-1dcdqdg"><code>      top: <span class="code-number">0</span>
</code></td></tr><tr><td id="L755" class="css-a4x74f"><span>755</span></td><td id="LC755" class="css-1dcdqdg"><code>    };
</code></td></tr><tr><td id="L756" class="css-a4x74f"><span>756</span></td><td id="LC756" class="css-1dcdqdg"><code>  } <span class="code-keyword">else</span> {
</code></td></tr><tr><td id="L757" class="css-a4x74f"><span>757</span></td><td id="LC757" class="css-1dcdqdg"><code>    elementRect = {
</code></td></tr><tr><td id="L758" class="css-a4x74f"><span>758</span></td><td id="LC758" class="css-1dcdqdg"><code>      width: element.offsetWidth,
</code></td></tr><tr><td id="L759" class="css-a4x74f"><span>759</span></td><td id="LC759" class="css-1dcdqdg"><code>      height: element.offsetHeight,
</code></td></tr><tr><td id="L760" class="css-a4x74f"><span>760</span></td><td id="LC760" class="css-1dcdqdg"><code>      left: element.offsetLeft,
</code></td></tr><tr><td id="L761" class="css-a4x74f"><span>761</span></td><td id="LC761" class="css-1dcdqdg"><code>      top: element.offsetTop
</code></td></tr><tr><td id="L762" class="css-a4x74f"><span>762</span></td><td id="LC762" class="css-1dcdqdg"><code>    };
</code></td></tr><tr><td id="L763" class="css-a4x74f"><span>763</span></td><td id="LC763" class="css-1dcdqdg"><code>  }
</code></td></tr><tr><td id="L764" class="css-a4x74f"><span>764</span></td><td id="LC764" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L765" class="css-a4x74f"><span>765</span></td><td id="LC765" class="css-1dcdqdg"><code>  <span class="code-comment">// position</span>
</code></td></tr><tr><td id="L766" class="css-a4x74f"><span>766</span></td><td id="LC766" class="css-1dcdqdg"><code>  <span class="code-keyword">return</span> getClientRect(elementRect);
</code></td></tr><tr><td id="L767" class="css-a4x74f"><span>767</span></td><td id="LC767" class="css-1dcdqdg"><code>}
</code></td></tr><tr><td id="L768" class="css-a4x74f"><span>768</span></td><td id="LC768" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L769" class="css-a4x74f"><span>769</span></td><td id="LC769" class="css-1dcdqdg"><code><span class="code-comment">/**
</span></code></td></tr><tr><td id="L770" class="css-a4x74f"><span>770</span></td><td id="LC770" class="css-1dcdqdg"><code><span class="code-comment"> * Get the outer sizes of the given element (offset size + margins)
</span></code></td></tr><tr><td id="L771" class="css-a4x74f"><span>771</span></td><td id="LC771" class="css-1dcdqdg"><code><span class="code-comment"> * @method
</span></code></td></tr><tr><td id="L772" class="css-a4x74f"><span>772</span></td><td id="LC772" class="css-1dcdqdg"><code><span class="code-comment"> * @memberof Popper.Utils
</span></code></td></tr><tr><td id="L773" class="css-a4x74f"><span>773</span></td><td id="LC773" class="css-1dcdqdg"><code><span class="code-comment"> * @argument {Element} element
</span></code></td></tr><tr><td id="L774" class="css-a4x74f"><span>774</span></td><td id="LC774" class="css-1dcdqdg"><code><span class="code-comment"> * @returns {Object} object containing width and height properties
</span></code></td></tr><tr><td id="L775" class="css-a4x74f"><span>775</span></td><td id="LC775" class="css-1dcdqdg"><code><span class="code-comment"> */</span>
</code></td></tr><tr><td id="L776" class="css-a4x74f"><span>776</span></td><td id="LC776" class="css-1dcdqdg"><code><span class="code-function"><span class="code-keyword">function</span> <span class="code-title">getOuterSizes</span>(<span class="code-params">element</span>) </span>{
</code></td></tr><tr><td id="L777" class="css-a4x74f"><span>777</span></td><td id="LC777" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> <span class="code-built_in">window</span> = element.ownerDocument.defaultView;
</code></td></tr><tr><td id="L778" class="css-a4x74f"><span>778</span></td><td id="LC778" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> styles = <span class="code-built_in">window</span>.getComputedStyle(element);
</code></td></tr><tr><td id="L779" class="css-a4x74f"><span>779</span></td><td id="LC779" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> x = <span class="code-built_in">parseFloat</span>(styles.marginTop || <span class="code-number">0</span>) + <span class="code-built_in">parseFloat</span>(styles.marginBottom || <span class="code-number">0</span>);
</code></td></tr><tr><td id="L780" class="css-a4x74f"><span>780</span></td><td id="LC780" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> y = <span class="code-built_in">parseFloat</span>(styles.marginLeft || <span class="code-number">0</span>) + <span class="code-built_in">parseFloat</span>(styles.marginRight || <span class="code-number">0</span>);
</code></td></tr><tr><td id="L781" class="css-a4x74f"><span>781</span></td><td id="LC781" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> result = {
</code></td></tr><tr><td id="L782" class="css-a4x74f"><span>782</span></td><td id="LC782" class="css-1dcdqdg"><code>    width: element.offsetWidth + y,
</code></td></tr><tr><td id="L783" class="css-a4x74f"><span>783</span></td><td id="LC783" class="css-1dcdqdg"><code>    height: element.offsetHeight + x
</code></td></tr><tr><td id="L784" class="css-a4x74f"><span>784</span></td><td id="LC784" class="css-1dcdqdg"><code>  };
</code></td></tr><tr><td id="L785" class="css-a4x74f"><span>785</span></td><td id="LC785" class="css-1dcdqdg"><code>  <span class="code-keyword">return</span> result;
</code></td></tr><tr><td id="L786" class="css-a4x74f"><span>786</span></td><td id="LC786" class="css-1dcdqdg"><code>}
</code></td></tr><tr><td id="L787" class="css-a4x74f"><span>787</span></td><td id="LC787" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L788" class="css-a4x74f"><span>788</span></td><td id="LC788" class="css-1dcdqdg"><code><span class="code-comment">/**
</span></code></td></tr><tr><td id="L789" class="css-a4x74f"><span>789</span></td><td id="LC789" class="css-1dcdqdg"><code><span class="code-comment"> * Get the opposite placement of the given one
</span></code></td></tr><tr><td id="L790" class="css-a4x74f"><span>790</span></td><td id="LC790" class="css-1dcdqdg"><code><span class="code-comment"> * @method
</span></code></td></tr><tr><td id="L791" class="css-a4x74f"><span>791</span></td><td id="LC791" class="css-1dcdqdg"><code><span class="code-comment"> * @memberof Popper.Utils
</span></code></td></tr><tr><td id="L792" class="css-a4x74f"><span>792</span></td><td id="LC792" class="css-1dcdqdg"><code><span class="code-comment"> * @argument {String} placement
</span></code></td></tr><tr><td id="L793" class="css-a4x74f"><span>793</span></td><td id="LC793" class="css-1dcdqdg"><code><span class="code-comment"> * @returns {String} flipped placement
</span></code></td></tr><tr><td id="L794" class="css-a4x74f"><span>794</span></td><td id="LC794" class="css-1dcdqdg"><code><span class="code-comment"> */</span>
</code></td></tr><tr><td id="L795" class="css-a4x74f"><span>795</span></td><td id="LC795" class="css-1dcdqdg"><code><span class="code-function"><span class="code-keyword">function</span> <span class="code-title">getOppositePlacement</span>(<span class="code-params">placement</span>) </span>{
</code></td></tr><tr><td id="L796" class="css-a4x74f"><span>796</span></td><td id="LC796" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> hash = { <span class="code-attr">left</span>: <span class="code-string">'right'</span>, <span class="code-attr">right</span>: <span class="code-string">'left'</span>, <span class="code-attr">bottom</span>: <span class="code-string">'top'</span>, <span class="code-attr">top</span>: <span class="code-string">'bottom'</span> };
</code></td></tr><tr><td id="L797" class="css-a4x74f"><span>797</span></td><td id="LC797" class="css-1dcdqdg"><code>  <span class="code-keyword">return</span> placement.replace(<span class="code-regexp">/left|right|bottom|top/g</span>, <span class="code-function"><span class="code-keyword">function</span> (<span class="code-params">matched</span>) </span>{
</code></td></tr><tr><td id="L798" class="css-a4x74f"><span>798</span></td><td id="LC798" class="css-1dcdqdg"><code>    <span class="code-keyword">return</span> hash[matched];
</code></td></tr><tr><td id="L799" class="css-a4x74f"><span>799</span></td><td id="LC799" class="css-1dcdqdg"><code>  });
</code></td></tr><tr><td id="L800" class="css-a4x74f"><span>800</span></td><td id="LC800" class="css-1dcdqdg"><code>}
</code></td></tr><tr><td id="L801" class="css-a4x74f"><span>801</span></td><td id="LC801" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L802" class="css-a4x74f"><span>802</span></td><td id="LC802" class="css-1dcdqdg"><code><span class="code-comment">/**
</span></code></td></tr><tr><td id="L803" class="css-a4x74f"><span>803</span></td><td id="LC803" class="css-1dcdqdg"><code><span class="code-comment"> * Get offsets to the popper
</span></code></td></tr><tr><td id="L804" class="css-a4x74f"><span>804</span></td><td id="LC804" class="css-1dcdqdg"><code><span class="code-comment"> * @method
</span></code></td></tr><tr><td id="L805" class="css-a4x74f"><span>805</span></td><td id="LC805" class="css-1dcdqdg"><code><span class="code-comment"> * @memberof Popper.Utils
</span></code></td></tr><tr><td id="L806" class="css-a4x74f"><span>806</span></td><td id="LC806" class="css-1dcdqdg"><code><span class="code-comment"> * @param {Object} position - CSS position the Popper will get applied
</span></code></td></tr><tr><td id="L807" class="css-a4x74f"><span>807</span></td><td id="LC807" class="css-1dcdqdg"><code><span class="code-comment"> * @param {HTMLElement} popper - the popper element
</span></code></td></tr><tr><td id="L808" class="css-a4x74f"><span>808</span></td><td id="LC808" class="css-1dcdqdg"><code><span class="code-comment"> * @param {Object} referenceOffsets - the reference offsets (the popper will be relative to this)
</span></code></td></tr><tr><td id="L809" class="css-a4x74f"><span>809</span></td><td id="LC809" class="css-1dcdqdg"><code><span class="code-comment"> * @param {String} placement - one of the valid placement options
</span></code></td></tr><tr><td id="L810" class="css-a4x74f"><span>810</span></td><td id="LC810" class="css-1dcdqdg"><code><span class="code-comment"> * @returns {Object} popperOffsets - An object containing the offsets which will be applied to the popper
</span></code></td></tr><tr><td id="L811" class="css-a4x74f"><span>811</span></td><td id="LC811" class="css-1dcdqdg"><code><span class="code-comment"> */</span>
</code></td></tr><tr><td id="L812" class="css-a4x74f"><span>812</span></td><td id="LC812" class="css-1dcdqdg"><code><span class="code-function"><span class="code-keyword">function</span> <span class="code-title">getPopperOffsets</span>(<span class="code-params">popper, referenceOffsets, placement</span>) </span>{
</code></td></tr><tr><td id="L813" class="css-a4x74f"><span>813</span></td><td id="LC813" class="css-1dcdqdg"><code>  placement = placement.split(<span class="code-string">'-'</span>)[<span class="code-number">0</span>];
</code></td></tr><tr><td id="L814" class="css-a4x74f"><span>814</span></td><td id="LC814" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L815" class="css-a4x74f"><span>815</span></td><td id="LC815" class="css-1dcdqdg"><code>  <span class="code-comment">// Get popper node sizes</span>
</code></td></tr><tr><td id="L816" class="css-a4x74f"><span>816</span></td><td id="LC816" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> popperRect = getOuterSizes(popper);
</code></td></tr><tr><td id="L817" class="css-a4x74f"><span>817</span></td><td id="LC817" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L818" class="css-a4x74f"><span>818</span></td><td id="LC818" class="css-1dcdqdg"><code>  <span class="code-comment">// Add position, width and height to our offsets object</span>
</code></td></tr><tr><td id="L819" class="css-a4x74f"><span>819</span></td><td id="LC819" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> popperOffsets = {
</code></td></tr><tr><td id="L820" class="css-a4x74f"><span>820</span></td><td id="LC820" class="css-1dcdqdg"><code>    width: popperRect.width,
</code></td></tr><tr><td id="L821" class="css-a4x74f"><span>821</span></td><td id="LC821" class="css-1dcdqdg"><code>    height: popperRect.height
</code></td></tr><tr><td id="L822" class="css-a4x74f"><span>822</span></td><td id="LC822" class="css-1dcdqdg"><code>  };
</code></td></tr><tr><td id="L823" class="css-a4x74f"><span>823</span></td><td id="LC823" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L824" class="css-a4x74f"><span>824</span></td><td id="LC824" class="css-1dcdqdg"><code>  <span class="code-comment">// depending by the popper placement we have to compute its offsets slightly differently</span>
</code></td></tr><tr><td id="L825" class="css-a4x74f"><span>825</span></td><td id="LC825" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> isHoriz = [<span class="code-string">'right'</span>, <span class="code-string">'left'</span>].indexOf(placement) !== <span class="code-number">-1</span>;
</code></td></tr><tr><td id="L826" class="css-a4x74f"><span>826</span></td><td id="LC826" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> mainSide = isHoriz ? <span class="code-string">'top'</span> : <span class="code-string">'left'</span>;
</code></td></tr><tr><td id="L827" class="css-a4x74f"><span>827</span></td><td id="LC827" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> secondarySide = isHoriz ? <span class="code-string">'left'</span> : <span class="code-string">'top'</span>;
</code></td></tr><tr><td id="L828" class="css-a4x74f"><span>828</span></td><td id="LC828" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> measurement = isHoriz ? <span class="code-string">'height'</span> : <span class="code-string">'width'</span>;
</code></td></tr><tr><td id="L829" class="css-a4x74f"><span>829</span></td><td id="LC829" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> secondaryMeasurement = !isHoriz ? <span class="code-string">'height'</span> : <span class="code-string">'width'</span>;
</code></td></tr><tr><td id="L830" class="css-a4x74f"><span>830</span></td><td id="LC830" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L831" class="css-a4x74f"><span>831</span></td><td id="LC831" class="css-1dcdqdg"><code>  popperOffsets[mainSide] = referenceOffsets[mainSide] + referenceOffsets[measurement] / <span class="code-number">2</span> - popperRect[measurement] / <span class="code-number">2</span>;
</code></td></tr><tr><td id="L832" class="css-a4x74f"><span>832</span></td><td id="LC832" class="css-1dcdqdg"><code>  <span class="code-keyword">if</span> (placement === secondarySide) {
</code></td></tr><tr><td id="L833" class="css-a4x74f"><span>833</span></td><td id="LC833" class="css-1dcdqdg"><code>    popperOffsets[secondarySide] = referenceOffsets[secondarySide] - popperRect[secondaryMeasurement];
</code></td></tr><tr><td id="L834" class="css-a4x74f"><span>834</span></td><td id="LC834" class="css-1dcdqdg"><code>  } <span class="code-keyword">else</span> {
</code></td></tr><tr><td id="L835" class="css-a4x74f"><span>835</span></td><td id="LC835" class="css-1dcdqdg"><code>    popperOffsets[secondarySide] = referenceOffsets[getOppositePlacement(secondarySide)];
</code></td></tr><tr><td id="L836" class="css-a4x74f"><span>836</span></td><td id="LC836" class="css-1dcdqdg"><code>  }
</code></td></tr><tr><td id="L837" class="css-a4x74f"><span>837</span></td><td id="LC837" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L838" class="css-a4x74f"><span>838</span></td><td id="LC838" class="css-1dcdqdg"><code>  <span class="code-keyword">return</span> popperOffsets;
</code></td></tr><tr><td id="L839" class="css-a4x74f"><span>839</span></td><td id="LC839" class="css-1dcdqdg"><code>}
</code></td></tr><tr><td id="L840" class="css-a4x74f"><span>840</span></td><td id="LC840" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L841" class="css-a4x74f"><span>841</span></td><td id="LC841" class="css-1dcdqdg"><code><span class="code-comment">/**
</span></code></td></tr><tr><td id="L842" class="css-a4x74f"><span>842</span></td><td id="LC842" class="css-1dcdqdg"><code><span class="code-comment"> * Get offsets to the reference element
</span></code></td></tr><tr><td id="L843" class="css-a4x74f"><span>843</span></td><td id="LC843" class="css-1dcdqdg"><code><span class="code-comment"> * @method
</span></code></td></tr><tr><td id="L844" class="css-a4x74f"><span>844</span></td><td id="LC844" class="css-1dcdqdg"><code><span class="code-comment"> * @memberof Popper.Utils
</span></code></td></tr><tr><td id="L845" class="css-a4x74f"><span>845</span></td><td id="LC845" class="css-1dcdqdg"><code><span class="code-comment"> * @param {Object} state
</span></code></td></tr><tr><td id="L846" class="css-a4x74f"><span>846</span></td><td id="LC846" class="css-1dcdqdg"><code><span class="code-comment"> * @param {Element} popper - the popper element
</span></code></td></tr><tr><td id="L847" class="css-a4x74f"><span>847</span></td><td id="LC847" class="css-1dcdqdg"><code><span class="code-comment"> * @param {Element} reference - the reference element (the popper will be relative to this)
</span></code></td></tr><tr><td id="L848" class="css-a4x74f"><span>848</span></td><td id="LC848" class="css-1dcdqdg"><code><span class="code-comment"> * @param {Element} fixedPosition - is in fixed position mode
</span></code></td></tr><tr><td id="L849" class="css-a4x74f"><span>849</span></td><td id="LC849" class="css-1dcdqdg"><code><span class="code-comment"> * @returns {Object} An object containing the offsets which will be applied to the popper
</span></code></td></tr><tr><td id="L850" class="css-a4x74f"><span>850</span></td><td id="LC850" class="css-1dcdqdg"><code><span class="code-comment"> */</span>
</code></td></tr><tr><td id="L851" class="css-a4x74f"><span>851</span></td><td id="LC851" class="css-1dcdqdg"><code><span class="code-function"><span class="code-keyword">function</span> <span class="code-title">getReferenceOffsets</span>(<span class="code-params">state, popper, reference</span>) </span>{
</code></td></tr><tr><td id="L852" class="css-a4x74f"><span>852</span></td><td id="LC852" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> fixedPosition = <span class="code-built_in">arguments</span>.length &gt; <span class="code-number">3</span> &amp;&amp; <span class="code-built_in">arguments</span>[<span class="code-number">3</span>] !== <span class="code-literal">undefined</span> ? <span class="code-built_in">arguments</span>[<span class="code-number">3</span>] : <span class="code-literal">null</span>;
</code></td></tr><tr><td id="L853" class="css-a4x74f"><span>853</span></td><td id="LC853" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L854" class="css-a4x74f"><span>854</span></td><td id="LC854" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> commonOffsetParent = fixedPosition ? getFixedPositionOffsetParent(popper) : findCommonOffsetParent(popper, getReferenceNode(reference));
</code></td></tr><tr><td id="L855" class="css-a4x74f"><span>855</span></td><td id="LC855" class="css-1dcdqdg"><code>  <span class="code-keyword">return</span> getOffsetRectRelativeToArbitraryNode(reference, commonOffsetParent, fixedPosition);
</code></td></tr><tr><td id="L856" class="css-a4x74f"><span>856</span></td><td id="LC856" class="css-1dcdqdg"><code>}
</code></td></tr><tr><td id="L857" class="css-a4x74f"><span>857</span></td><td id="LC857" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L858" class="css-a4x74f"><span>858</span></td><td id="LC858" class="css-1dcdqdg"><code><span class="code-comment">/**
</span></code></td></tr><tr><td id="L859" class="css-a4x74f"><span>859</span></td><td id="LC859" class="css-1dcdqdg"><code><span class="code-comment"> * Get the prefixed supported property name
</span></code></td></tr><tr><td id="L860" class="css-a4x74f"><span>860</span></td><td id="LC860" class="css-1dcdqdg"><code><span class="code-comment"> * @method
</span></code></td></tr><tr><td id="L861" class="css-a4x74f"><span>861</span></td><td id="LC861" class="css-1dcdqdg"><code><span class="code-comment"> * @memberof Popper.Utils
</span></code></td></tr><tr><td id="L862" class="css-a4x74f"><span>862</span></td><td id="LC862" class="css-1dcdqdg"><code><span class="code-comment"> * @argument {String} property (camelCase)
</span></code></td></tr><tr><td id="L863" class="css-a4x74f"><span>863</span></td><td id="LC863" class="css-1dcdqdg"><code><span class="code-comment"> * @returns {String} prefixed property (camelCase or PascalCase, depending on the vendor prefix)
</span></code></td></tr><tr><td id="L864" class="css-a4x74f"><span>864</span></td><td id="LC864" class="css-1dcdqdg"><code><span class="code-comment"> */</span>
</code></td></tr><tr><td id="L865" class="css-a4x74f"><span>865</span></td><td id="LC865" class="css-1dcdqdg"><code><span class="code-function"><span class="code-keyword">function</span> <span class="code-title">getSupportedPropertyName</span>(<span class="code-params">property</span>) </span>{
</code></td></tr><tr><td id="L866" class="css-a4x74f"><span>866</span></td><td id="LC866" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> prefixes = [<span class="code-literal">false</span>, <span class="code-string">'ms'</span>, <span class="code-string">'Webkit'</span>, <span class="code-string">'Moz'</span>, <span class="code-string">'O'</span>];
</code></td></tr><tr><td id="L867" class="css-a4x74f"><span>867</span></td><td id="LC867" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> upperProp = property.charAt(<span class="code-number">0</span>).toUpperCase() + property.slice(<span class="code-number">1</span>);
</code></td></tr><tr><td id="L868" class="css-a4x74f"><span>868</span></td><td id="LC868" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L869" class="css-a4x74f"><span>869</span></td><td id="LC869" class="css-1dcdqdg"><code>  <span class="code-keyword">for</span> (<span class="code-keyword">var</span> i = <span class="code-number">0</span>; i &lt; prefixes.length; i++) {
</code></td></tr><tr><td id="L870" class="css-a4x74f"><span>870</span></td><td id="LC870" class="css-1dcdqdg"><code>    <span class="code-keyword">var</span> prefix = prefixes[i];
</code></td></tr><tr><td id="L871" class="css-a4x74f"><span>871</span></td><td id="LC871" class="css-1dcdqdg"><code>    <span class="code-keyword">var</span> toCheck = prefix ? <span class="code-string">''</span> + prefix + upperProp : property;
</code></td></tr><tr><td id="L872" class="css-a4x74f"><span>872</span></td><td id="LC872" class="css-1dcdqdg"><code>    <span class="code-keyword">if</span> (<span class="code-keyword">typeof</span> <span class="code-built_in">document</span>.body.style[toCheck] !== <span class="code-string">'undefined'</span>) {
</code></td></tr><tr><td id="L873" class="css-a4x74f"><span>873</span></td><td id="LC873" class="css-1dcdqdg"><code>      <span class="code-keyword">return</span> toCheck;
</code></td></tr><tr><td id="L874" class="css-a4x74f"><span>874</span></td><td id="LC874" class="css-1dcdqdg"><code>    }
</code></td></tr><tr><td id="L875" class="css-a4x74f"><span>875</span></td><td id="LC875" class="css-1dcdqdg"><code>  }
</code></td></tr><tr><td id="L876" class="css-a4x74f"><span>876</span></td><td id="LC876" class="css-1dcdqdg"><code>  <span class="code-keyword">return</span> <span class="code-literal">null</span>;
</code></td></tr><tr><td id="L877" class="css-a4x74f"><span>877</span></td><td id="LC877" class="css-1dcdqdg"><code>}
</code></td></tr><tr><td id="L878" class="css-a4x74f"><span>878</span></td><td id="LC878" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L879" class="css-a4x74f"><span>879</span></td><td id="LC879" class="css-1dcdqdg"><code><span class="code-comment">/**
</span></code></td></tr><tr><td id="L880" class="css-a4x74f"><span>880</span></td><td id="LC880" class="css-1dcdqdg"><code><span class="code-comment"> * Check if the given variable is a function
</span></code></td></tr><tr><td id="L881" class="css-a4x74f"><span>881</span></td><td id="LC881" class="css-1dcdqdg"><code><span class="code-comment"> * @method
</span></code></td></tr><tr><td id="L882" class="css-a4x74f"><span>882</span></td><td id="LC882" class="css-1dcdqdg"><code><span class="code-comment"> * @memberof Popper.Utils
</span></code></td></tr><tr><td id="L883" class="css-a4x74f"><span>883</span></td><td id="LC883" class="css-1dcdqdg"><code><span class="code-comment"> * @argument {Any} functionToCheck - variable to check
</span></code></td></tr><tr><td id="L884" class="css-a4x74f"><span>884</span></td><td id="LC884" class="css-1dcdqdg"><code><span class="code-comment"> * @returns {Boolean} answer to: is a function?
</span></code></td></tr><tr><td id="L885" class="css-a4x74f"><span>885</span></td><td id="LC885" class="css-1dcdqdg"><code><span class="code-comment"> */</span>
</code></td></tr><tr><td id="L886" class="css-a4x74f"><span>886</span></td><td id="LC886" class="css-1dcdqdg"><code><span class="code-function"><span class="code-keyword">function</span> <span class="code-title">isFunction</span>(<span class="code-params">functionToCheck</span>) </span>{
</code></td></tr><tr><td id="L887" class="css-a4x74f"><span>887</span></td><td id="LC887" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> getType = {};
</code></td></tr><tr><td id="L888" class="css-a4x74f"><span>888</span></td><td id="LC888" class="css-1dcdqdg"><code>  <span class="code-keyword">return</span> functionToCheck &amp;&amp; getType.toString.call(functionToCheck) === <span class="code-string">'[object Function]'</span>;
</code></td></tr><tr><td id="L889" class="css-a4x74f"><span>889</span></td><td id="LC889" class="css-1dcdqdg"><code>}
</code></td></tr><tr><td id="L890" class="css-a4x74f"><span>890</span></td><td id="LC890" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L891" class="css-a4x74f"><span>891</span></td><td id="LC891" class="css-1dcdqdg"><code><span class="code-comment">/**
</span></code></td></tr><tr><td id="L892" class="css-a4x74f"><span>892</span></td><td id="LC892" class="css-1dcdqdg"><code><span class="code-comment"> * Helper used to know if the given modifier is enabled.
</span></code></td></tr><tr><td id="L893" class="css-a4x74f"><span>893</span></td><td id="LC893" class="css-1dcdqdg"><code><span class="code-comment"> * @method
</span></code></td></tr><tr><td id="L894" class="css-a4x74f"><span>894</span></td><td id="LC894" class="css-1dcdqdg"><code><span class="code-comment"> * @memberof Popper.Utils
</span></code></td></tr><tr><td id="L895" class="css-a4x74f"><span>895</span></td><td id="LC895" class="css-1dcdqdg"><code><span class="code-comment"> * @returns {Boolean}
</span></code></td></tr><tr><td id="L896" class="css-a4x74f"><span>896</span></td><td id="LC896" class="css-1dcdqdg"><code><span class="code-comment"> */</span>
</code></td></tr><tr><td id="L897" class="css-a4x74f"><span>897</span></td><td id="LC897" class="css-1dcdqdg"><code><span class="code-function"><span class="code-keyword">function</span> <span class="code-title">isModifierEnabled</span>(<span class="code-params">modifiers, modifierName</span>) </span>{
</code></td></tr><tr><td id="L898" class="css-a4x74f"><span>898</span></td><td id="LC898" class="css-1dcdqdg"><code>  <span class="code-keyword">return</span> modifiers.some(<span class="code-function"><span class="code-keyword">function</span> (<span class="code-params">_ref</span>) </span>{
</code></td></tr><tr><td id="L899" class="css-a4x74f"><span>899</span></td><td id="LC899" class="css-1dcdqdg"><code>    <span class="code-keyword">var</span> name = _ref.name,
</code></td></tr><tr><td id="L900" class="css-a4x74f"><span>900</span></td><td id="LC900" class="css-1dcdqdg"><code>        enabled = _ref.enabled;
</code></td></tr><tr><td id="L901" class="css-a4x74f"><span>901</span></td><td id="LC901" class="css-1dcdqdg"><code>    <span class="code-keyword">return</span> enabled &amp;&amp; name === modifierName;
</code></td></tr><tr><td id="L902" class="css-a4x74f"><span>902</span></td><td id="LC902" class="css-1dcdqdg"><code>  });
</code></td></tr><tr><td id="L903" class="css-a4x74f"><span>903</span></td><td id="LC903" class="css-1dcdqdg"><code>}
</code></td></tr><tr><td id="L904" class="css-a4x74f"><span>904</span></td><td id="LC904" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L905" class="css-a4x74f"><span>905</span></td><td id="LC905" class="css-1dcdqdg"><code><span class="code-comment">/**
</span></code></td></tr><tr><td id="L906" class="css-a4x74f"><span>906</span></td><td id="LC906" class="css-1dcdqdg"><code><span class="code-comment"> * Helper used to know if the given modifier depends from another one.&lt;br /&gt;
</span></code></td></tr><tr><td id="L907" class="css-a4x74f"><span>907</span></td><td id="LC907" class="css-1dcdqdg"><code><span class="code-comment"> * It checks if the needed modifier is listed and enabled.
</span></code></td></tr><tr><td id="L908" class="css-a4x74f"><span>908</span></td><td id="LC908" class="css-1dcdqdg"><code><span class="code-comment"> * @method
</span></code></td></tr><tr><td id="L909" class="css-a4x74f"><span>909</span></td><td id="LC909" class="css-1dcdqdg"><code><span class="code-comment"> * @memberof Popper.Utils
</span></code></td></tr><tr><td id="L910" class="css-a4x74f"><span>910</span></td><td id="LC910" class="css-1dcdqdg"><code><span class="code-comment"> * @param {Array} modifiers - list of modifiers
</span></code></td></tr><tr><td id="L911" class="css-a4x74f"><span>911</span></td><td id="LC911" class="css-1dcdqdg"><code><span class="code-comment"> * @param {String} requestingName - name of requesting modifier
</span></code></td></tr><tr><td id="L912" class="css-a4x74f"><span>912</span></td><td id="LC912" class="css-1dcdqdg"><code><span class="code-comment"> * @param {String} requestedName - name of requested modifier
</span></code></td></tr><tr><td id="L913" class="css-a4x74f"><span>913</span></td><td id="LC913" class="css-1dcdqdg"><code><span class="code-comment"> * @returns {Boolean}
</span></code></td></tr><tr><td id="L914" class="css-a4x74f"><span>914</span></td><td id="LC914" class="css-1dcdqdg"><code><span class="code-comment"> */</span>
</code></td></tr><tr><td id="L915" class="css-a4x74f"><span>915</span></td><td id="LC915" class="css-1dcdqdg"><code><span class="code-function"><span class="code-keyword">function</span> <span class="code-title">isModifierRequired</span>(<span class="code-params">modifiers, requestingName, requestedName</span>) </span>{
</code></td></tr><tr><td id="L916" class="css-a4x74f"><span>916</span></td><td id="LC916" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> requesting = find(modifiers, <span class="code-function"><span class="code-keyword">function</span> (<span class="code-params">_ref</span>) </span>{
</code></td></tr><tr><td id="L917" class="css-a4x74f"><span>917</span></td><td id="LC917" class="css-1dcdqdg"><code>    <span class="code-keyword">var</span> name = _ref.name;
</code></td></tr><tr><td id="L918" class="css-a4x74f"><span>918</span></td><td id="LC918" class="css-1dcdqdg"><code>    <span class="code-keyword">return</span> name === requestingName;
</code></td></tr><tr><td id="L919" class="css-a4x74f"><span>919</span></td><td id="LC919" class="css-1dcdqdg"><code>  });
</code></td></tr><tr><td id="L920" class="css-a4x74f"><span>920</span></td><td id="LC920" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L921" class="css-a4x74f"><span>921</span></td><td id="LC921" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> isRequired = !!requesting &amp;&amp; modifiers.some(<span class="code-function"><span class="code-keyword">function</span> (<span class="code-params">modifier</span>) </span>{
</code></td></tr><tr><td id="L922" class="css-a4x74f"><span>922</span></td><td id="LC922" class="css-1dcdqdg"><code>    <span class="code-keyword">return</span> modifier.name === requestedName &amp;&amp; modifier.enabled &amp;&amp; modifier.order &lt; requesting.order;
</code></td></tr><tr><td id="L923" class="css-a4x74f"><span>923</span></td><td id="LC923" class="css-1dcdqdg"><code>  });
</code></td></tr><tr><td id="L924" class="css-a4x74f"><span>924</span></td><td id="LC924" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L925" class="css-a4x74f"><span>925</span></td><td id="LC925" class="css-1dcdqdg"><code>  <span class="code-keyword">if</span> (!isRequired) {
</code></td></tr><tr><td id="L926" class="css-a4x74f"><span>926</span></td><td id="LC926" class="css-1dcdqdg"><code>    <span class="code-keyword">var</span> _requesting = <span class="code-string">'`'</span> + requestingName + <span class="code-string">'`'</span>;
</code></td></tr><tr><td id="L927" class="css-a4x74f"><span>927</span></td><td id="LC927" class="css-1dcdqdg"><code>    <span class="code-keyword">var</span> requested = <span class="code-string">'`'</span> + requestedName + <span class="code-string">'`'</span>;
</code></td></tr><tr><td id="L928" class="css-a4x74f"><span>928</span></td><td id="LC928" class="css-1dcdqdg"><code>    <span class="code-built_in">console</span>.warn(requested + <span class="code-string">' modifier is required by '</span> + _requesting + <span class="code-string">' modifier in order to work, be sure to include it before '</span> + _requesting + <span class="code-string">'!'</span>);
</code></td></tr><tr><td id="L929" class="css-a4x74f"><span>929</span></td><td id="LC929" class="css-1dcdqdg"><code>  }
</code></td></tr><tr><td id="L930" class="css-a4x74f"><span>930</span></td><td id="LC930" class="css-1dcdqdg"><code>  <span class="code-keyword">return</span> isRequired;
</code></td></tr><tr><td id="L931" class="css-a4x74f"><span>931</span></td><td id="LC931" class="css-1dcdqdg"><code>}
</code></td></tr><tr><td id="L932" class="css-a4x74f"><span>932</span></td><td id="LC932" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L933" class="css-a4x74f"><span>933</span></td><td id="LC933" class="css-1dcdqdg"><code><span class="code-comment">/**
</span></code></td></tr><tr><td id="L934" class="css-a4x74f"><span>934</span></td><td id="LC934" class="css-1dcdqdg"><code><span class="code-comment"> * Tells if a given input is a number
</span></code></td></tr><tr><td id="L935" class="css-a4x74f"><span>935</span></td><td id="LC935" class="css-1dcdqdg"><code><span class="code-comment"> * @method
</span></code></td></tr><tr><td id="L936" class="css-a4x74f"><span>936</span></td><td id="LC936" class="css-1dcdqdg"><code><span class="code-comment"> * @memberof Popper.Utils
</span></code></td></tr><tr><td id="L937" class="css-a4x74f"><span>937</span></td><td id="LC937" class="css-1dcdqdg"><code><span class="code-comment"> * @param {*} input to check
</span></code></td></tr><tr><td id="L938" class="css-a4x74f"><span>938</span></td><td id="LC938" class="css-1dcdqdg"><code><span class="code-comment"> * @return {Boolean}
</span></code></td></tr><tr><td id="L939" class="css-a4x74f"><span>939</span></td><td id="LC939" class="css-1dcdqdg"><code><span class="code-comment"> */</span>
</code></td></tr><tr><td id="L940" class="css-a4x74f"><span>940</span></td><td id="LC940" class="css-1dcdqdg"><code><span class="code-function"><span class="code-keyword">function</span> <span class="code-title">isNumeric</span>(<span class="code-params">n</span>) </span>{
</code></td></tr><tr><td id="L941" class="css-a4x74f"><span>941</span></td><td id="LC941" class="css-1dcdqdg"><code>  <span class="code-keyword">return</span> n !== <span class="code-string">''</span> &amp;&amp; !<span class="code-built_in">isNaN</span>(<span class="code-built_in">parseFloat</span>(n)) &amp;&amp; <span class="code-built_in">isFinite</span>(n);
</code></td></tr><tr><td id="L942" class="css-a4x74f"><span>942</span></td><td id="LC942" class="css-1dcdqdg"><code>}
</code></td></tr><tr><td id="L943" class="css-a4x74f"><span>943</span></td><td id="LC943" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L944" class="css-a4x74f"><span>944</span></td><td id="LC944" class="css-1dcdqdg"><code><span class="code-comment">/**
</span></code></td></tr><tr><td id="L945" class="css-a4x74f"><span>945</span></td><td id="LC945" class="css-1dcdqdg"><code><span class="code-comment"> * Get the window associated with the element
</span></code></td></tr><tr><td id="L946" class="css-a4x74f"><span>946</span></td><td id="LC946" class="css-1dcdqdg"><code><span class="code-comment"> * @argument {Element} element
</span></code></td></tr><tr><td id="L947" class="css-a4x74f"><span>947</span></td><td id="LC947" class="css-1dcdqdg"><code><span class="code-comment"> * @returns {Window}
</span></code></td></tr><tr><td id="L948" class="css-a4x74f"><span>948</span></td><td id="LC948" class="css-1dcdqdg"><code><span class="code-comment"> */</span>
</code></td></tr><tr><td id="L949" class="css-a4x74f"><span>949</span></td><td id="LC949" class="css-1dcdqdg"><code><span class="code-function"><span class="code-keyword">function</span> <span class="code-title">getWindow</span>(<span class="code-params">element</span>) </span>{
</code></td></tr><tr><td id="L950" class="css-a4x74f"><span>950</span></td><td id="LC950" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> ownerDocument = element.ownerDocument;
</code></td></tr><tr><td id="L951" class="css-a4x74f"><span>951</span></td><td id="LC951" class="css-1dcdqdg"><code>  <span class="code-keyword">return</span> ownerDocument ? ownerDocument.defaultView : <span class="code-built_in">window</span>;
</code></td></tr><tr><td id="L952" class="css-a4x74f"><span>952</span></td><td id="LC952" class="css-1dcdqdg"><code>}
</code></td></tr><tr><td id="L953" class="css-a4x74f"><span>953</span></td><td id="LC953" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L954" class="css-a4x74f"><span>954</span></td><td id="LC954" class="css-1dcdqdg"><code><span class="code-comment">/**
</span></code></td></tr><tr><td id="L955" class="css-a4x74f"><span>955</span></td><td id="LC955" class="css-1dcdqdg"><code><span class="code-comment"> * Remove event listeners used to update the popper position
</span></code></td></tr><tr><td id="L956" class="css-a4x74f"><span>956</span></td><td id="LC956" class="css-1dcdqdg"><code><span class="code-comment"> * @method
</span></code></td></tr><tr><td id="L957" class="css-a4x74f"><span>957</span></td><td id="LC957" class="css-1dcdqdg"><code><span class="code-comment"> * @memberof Popper.Utils
</span></code></td></tr><tr><td id="L958" class="css-a4x74f"><span>958</span></td><td id="LC958" class="css-1dcdqdg"><code><span class="code-comment"> * @private
</span></code></td></tr><tr><td id="L959" class="css-a4x74f"><span>959</span></td><td id="LC959" class="css-1dcdqdg"><code><span class="code-comment"> */</span>
</code></td></tr><tr><td id="L960" class="css-a4x74f"><span>960</span></td><td id="LC960" class="css-1dcdqdg"><code><span class="code-function"><span class="code-keyword">function</span> <span class="code-title">removeEventListeners</span>(<span class="code-params">reference, state</span>) </span>{
</code></td></tr><tr><td id="L961" class="css-a4x74f"><span>961</span></td><td id="LC961" class="css-1dcdqdg"><code>  <span class="code-comment">// Remove resize event listener on window</span>
</code></td></tr><tr><td id="L962" class="css-a4x74f"><span>962</span></td><td id="LC962" class="css-1dcdqdg"><code>  getWindow(reference).removeEventListener(<span class="code-string">'resize'</span>, state.updateBound);
</code></td></tr><tr><td id="L963" class="css-a4x74f"><span>963</span></td><td id="LC963" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L964" class="css-a4x74f"><span>964</span></td><td id="LC964" class="css-1dcdqdg"><code>  <span class="code-comment">// Remove scroll event listener on scroll parents</span>
</code></td></tr><tr><td id="L965" class="css-a4x74f"><span>965</span></td><td id="LC965" class="css-1dcdqdg"><code>  state.scrollParents.forEach(<span class="code-function"><span class="code-keyword">function</span> (<span class="code-params">target</span>) </span>{
</code></td></tr><tr><td id="L966" class="css-a4x74f"><span>966</span></td><td id="LC966" class="css-1dcdqdg"><code>    target.removeEventListener(<span class="code-string">'scroll'</span>, state.updateBound);
</code></td></tr><tr><td id="L967" class="css-a4x74f"><span>967</span></td><td id="LC967" class="css-1dcdqdg"><code>  });
</code></td></tr><tr><td id="L968" class="css-a4x74f"><span>968</span></td><td id="LC968" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L969" class="css-a4x74f"><span>969</span></td><td id="LC969" class="css-1dcdqdg"><code>  <span class="code-comment">// Reset state</span>
</code></td></tr><tr><td id="L970" class="css-a4x74f"><span>970</span></td><td id="LC970" class="css-1dcdqdg"><code>  state.updateBound = <span class="code-literal">null</span>;
</code></td></tr><tr><td id="L971" class="css-a4x74f"><span>971</span></td><td id="LC971" class="css-1dcdqdg"><code>  state.scrollParents = [];
</code></td></tr><tr><td id="L972" class="css-a4x74f"><span>972</span></td><td id="LC972" class="css-1dcdqdg"><code>  state.scrollElement = <span class="code-literal">null</span>;
</code></td></tr><tr><td id="L973" class="css-a4x74f"><span>973</span></td><td id="LC973" class="css-1dcdqdg"><code>  state.eventsEnabled = <span class="code-literal">false</span>;
</code></td></tr><tr><td id="L974" class="css-a4x74f"><span>974</span></td><td id="LC974" class="css-1dcdqdg"><code>  <span class="code-keyword">return</span> state;
</code></td></tr><tr><td id="L975" class="css-a4x74f"><span>975</span></td><td id="LC975" class="css-1dcdqdg"><code>}
</code></td></tr><tr><td id="L976" class="css-a4x74f"><span>976</span></td><td id="LC976" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L977" class="css-a4x74f"><span>977</span></td><td id="LC977" class="css-1dcdqdg"><code><span class="code-comment">/**
</span></code></td></tr><tr><td id="L978" class="css-a4x74f"><span>978</span></td><td id="LC978" class="css-1dcdqdg"><code><span class="code-comment"> * Loop trough the list of modifiers and run them in order,
</span></code></td></tr><tr><td id="L979" class="css-a4x74f"><span>979</span></td><td id="LC979" class="css-1dcdqdg"><code><span class="code-comment"> * each of them will then edit the data object.
</span></code></td></tr><tr><td id="L980" class="css-a4x74f"><span>980</span></td><td id="LC980" class="css-1dcdqdg"><code><span class="code-comment"> * @method
</span></code></td></tr><tr><td id="L981" class="css-a4x74f"><span>981</span></td><td id="LC981" class="css-1dcdqdg"><code><span class="code-comment"> * @memberof Popper.Utils
</span></code></td></tr><tr><td id="L982" class="css-a4x74f"><span>982</span></td><td id="LC982" class="css-1dcdqdg"><code><span class="code-comment"> * @param {dataObject} data
</span></code></td></tr><tr><td id="L983" class="css-a4x74f"><span>983</span></td><td id="LC983" class="css-1dcdqdg"><code><span class="code-comment"> * @param {Array} modifiers
</span></code></td></tr><tr><td id="L984" class="css-a4x74f"><span>984</span></td><td id="LC984" class="css-1dcdqdg"><code><span class="code-comment"> * @param {String} ends - Optional modifier name used as stopper
</span></code></td></tr><tr><td id="L985" class="css-a4x74f"><span>985</span></td><td id="LC985" class="css-1dcdqdg"><code><span class="code-comment"> * @returns {dataObject}
</span></code></td></tr><tr><td id="L986" class="css-a4x74f"><span>986</span></td><td id="LC986" class="css-1dcdqdg"><code><span class="code-comment"> */</span>
</code></td></tr><tr><td id="L987" class="css-a4x74f"><span>987</span></td><td id="LC987" class="css-1dcdqdg"><code><span class="code-function"><span class="code-keyword">function</span> <span class="code-title">runModifiers</span>(<span class="code-params">modifiers, data, ends</span>) </span>{
</code></td></tr><tr><td id="L988" class="css-a4x74f"><span>988</span></td><td id="LC988" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> modifiersToRun = ends === <span class="code-literal">undefined</span> ? modifiers : modifiers.slice(<span class="code-number">0</span>, findIndex(modifiers, <span class="code-string">'name'</span>, ends));
</code></td></tr><tr><td id="L989" class="css-a4x74f"><span>989</span></td><td id="LC989" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L990" class="css-a4x74f"><span>990</span></td><td id="LC990" class="css-1dcdqdg"><code>  modifiersToRun.forEach(<span class="code-function"><span class="code-keyword">function</span> (<span class="code-params">modifier</span>) </span>{
</code></td></tr><tr><td id="L991" class="css-a4x74f"><span>991</span></td><td id="LC991" class="css-1dcdqdg"><code>    <span class="code-keyword">if</span> (modifier[<span class="code-string">'function'</span>]) {
</code></td></tr><tr><td id="L992" class="css-a4x74f"><span>992</span></td><td id="LC992" class="css-1dcdqdg"><code>      <span class="code-comment">// eslint-disable-line dot-notation</span>
</code></td></tr><tr><td id="L993" class="css-a4x74f"><span>993</span></td><td id="LC993" class="css-1dcdqdg"><code>      <span class="code-built_in">console</span>.warn(<span class="code-string">'`modifier.function` is deprecated, use `modifier.fn`!'</span>);
</code></td></tr><tr><td id="L994" class="css-a4x74f"><span>994</span></td><td id="LC994" class="css-1dcdqdg"><code>    }
</code></td></tr><tr><td id="L995" class="css-a4x74f"><span>995</span></td><td id="LC995" class="css-1dcdqdg"><code>    <span class="code-keyword">var</span> fn = modifier[<span class="code-string">'function'</span>] || modifier.fn; <span class="code-comment">// eslint-disable-line dot-notation</span>
</code></td></tr><tr><td id="L996" class="css-a4x74f"><span>996</span></td><td id="LC996" class="css-1dcdqdg"><code>    <span class="code-keyword">if</span> (modifier.enabled &amp;&amp; isFunction(fn)) {
</code></td></tr><tr><td id="L997" class="css-a4x74f"><span>997</span></td><td id="LC997" class="css-1dcdqdg"><code>      <span class="code-comment">// Add properties to offsets to make them a complete clientRect object</span>
</code></td></tr><tr><td id="L998" class="css-a4x74f"><span>998</span></td><td id="LC998" class="css-1dcdqdg"><code>      <span class="code-comment">// we do this before each modifier to make sure the previous one doesn't</span>
</code></td></tr><tr><td id="L999" class="css-a4x74f"><span>999</span></td><td id="LC999" class="css-1dcdqdg"><code>      <span class="code-comment">// mess with these values</span>
</code></td></tr><tr><td id="L1000" class="css-a4x74f"><span>1000</span></td><td id="LC1000" class="css-1dcdqdg"><code>      data.offsets.popper = getClientRect(data.offsets.popper);
</code></td></tr><tr><td id="L1001" class="css-a4x74f"><span>1001</span></td><td id="LC1001" class="css-1dcdqdg"><code>      data.offsets.reference = getClientRect(data.offsets.reference);
</code></td></tr><tr><td id="L1002" class="css-a4x74f"><span>1002</span></td><td id="LC1002" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L1003" class="css-a4x74f"><span>1003</span></td><td id="LC1003" class="css-1dcdqdg"><code>      data = fn(data, modifier);
</code></td></tr><tr><td id="L1004" class="css-a4x74f"><span>1004</span></td><td id="LC1004" class="css-1dcdqdg"><code>    }
</code></td></tr><tr><td id="L1005" class="css-a4x74f"><span>1005</span></td><td id="LC1005" class="css-1dcdqdg"><code>  });
</code></td></tr><tr><td id="L1006" class="css-a4x74f"><span>1006</span></td><td id="LC1006" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L1007" class="css-a4x74f"><span>1007</span></td><td id="LC1007" class="css-1dcdqdg"><code>  <span class="code-keyword">return</span> data;
</code></td></tr><tr><td id="L1008" class="css-a4x74f"><span>1008</span></td><td id="LC1008" class="css-1dcdqdg"><code>}
</code></td></tr><tr><td id="L1009" class="css-a4x74f"><span>1009</span></td><td id="LC1009" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L1010" class="css-a4x74f"><span>1010</span></td><td id="LC1010" class="css-1dcdqdg"><code><span class="code-comment">/**
</span></code></td></tr><tr><td id="L1011" class="css-a4x74f"><span>1011</span></td><td id="LC1011" class="css-1dcdqdg"><code><span class="code-comment"> * Set the attributes to the given popper
</span></code></td></tr><tr><td id="L1012" class="css-a4x74f"><span>1012</span></td><td id="LC1012" class="css-1dcdqdg"><code><span class="code-comment"> * @method
</span></code></td></tr><tr><td id="L1013" class="css-a4x74f"><span>1013</span></td><td id="LC1013" class="css-1dcdqdg"><code><span class="code-comment"> * @memberof Popper.Utils
</span></code></td></tr><tr><td id="L1014" class="css-a4x74f"><span>1014</span></td><td id="LC1014" class="css-1dcdqdg"><code><span class="code-comment"> * @argument {Element} element - Element to apply the attributes to
</span></code></td></tr><tr><td id="L1015" class="css-a4x74f"><span>1015</span></td><td id="LC1015" class="css-1dcdqdg"><code><span class="code-comment"> * @argument {Object} styles
</span></code></td></tr><tr><td id="L1016" class="css-a4x74f"><span>1016</span></td><td id="LC1016" class="css-1dcdqdg"><code><span class="code-comment"> * Object with a list of properties and values which will be applied to the element
</span></code></td></tr><tr><td id="L1017" class="css-a4x74f"><span>1017</span></td><td id="LC1017" class="css-1dcdqdg"><code><span class="code-comment"> */</span>
</code></td></tr><tr><td id="L1018" class="css-a4x74f"><span>1018</span></td><td id="LC1018" class="css-1dcdqdg"><code><span class="code-function"><span class="code-keyword">function</span> <span class="code-title">setAttributes</span>(<span class="code-params">element, attributes</span>) </span>{
</code></td></tr><tr><td id="L1019" class="css-a4x74f"><span>1019</span></td><td id="LC1019" class="css-1dcdqdg"><code>  <span class="code-built_in">Object</span>.keys(attributes).forEach(<span class="code-function"><span class="code-keyword">function</span> (<span class="code-params">prop</span>) </span>{
</code></td></tr><tr><td id="L1020" class="css-a4x74f"><span>1020</span></td><td id="LC1020" class="css-1dcdqdg"><code>    <span class="code-keyword">var</span> value = attributes[prop];
</code></td></tr><tr><td id="L1021" class="css-a4x74f"><span>1021</span></td><td id="LC1021" class="css-1dcdqdg"><code>    <span class="code-keyword">if</span> (value !== <span class="code-literal">false</span>) {
</code></td></tr><tr><td id="L1022" class="css-a4x74f"><span>1022</span></td><td id="LC1022" class="css-1dcdqdg"><code>      element.setAttribute(prop, attributes[prop]);
</code></td></tr><tr><td id="L1023" class="css-a4x74f"><span>1023</span></td><td id="LC1023" class="css-1dcdqdg"><code>    } <span class="code-keyword">else</span> {
</code></td></tr><tr><td id="L1024" class="css-a4x74f"><span>1024</span></td><td id="LC1024" class="css-1dcdqdg"><code>      element.removeAttribute(prop);
</code></td></tr><tr><td id="L1025" class="css-a4x74f"><span>1025</span></td><td id="LC1025" class="css-1dcdqdg"><code>    }
</code></td></tr><tr><td id="L1026" class="css-a4x74f"><span>1026</span></td><td id="LC1026" class="css-1dcdqdg"><code>  });
</code></td></tr><tr><td id="L1027" class="css-a4x74f"><span>1027</span></td><td id="LC1027" class="css-1dcdqdg"><code>}
</code></td></tr><tr><td id="L1028" class="css-a4x74f"><span>1028</span></td><td id="LC1028" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L1029" class="css-a4x74f"><span>1029</span></td><td id="LC1029" class="css-1dcdqdg"><code><span class="code-comment">/**
</span></code></td></tr><tr><td id="L1030" class="css-a4x74f"><span>1030</span></td><td id="LC1030" class="css-1dcdqdg"><code><span class="code-comment"> * Set the style to the given popper
</span></code></td></tr><tr><td id="L1031" class="css-a4x74f"><span>1031</span></td><td id="LC1031" class="css-1dcdqdg"><code><span class="code-comment"> * @method
</span></code></td></tr><tr><td id="L1032" class="css-a4x74f"><span>1032</span></td><td id="LC1032" class="css-1dcdqdg"><code><span class="code-comment"> * @memberof Popper.Utils
</span></code></td></tr><tr><td id="L1033" class="css-a4x74f"><span>1033</span></td><td id="LC1033" class="css-1dcdqdg"><code><span class="code-comment"> * @argument {Element} element - Element to apply the style to
</span></code></td></tr><tr><td id="L1034" class="css-a4x74f"><span>1034</span></td><td id="LC1034" class="css-1dcdqdg"><code><span class="code-comment"> * @argument {Object} styles
</span></code></td></tr><tr><td id="L1035" class="css-a4x74f"><span>1035</span></td><td id="LC1035" class="css-1dcdqdg"><code><span class="code-comment"> * Object with a list of properties and values which will be applied to the element
</span></code></td></tr><tr><td id="L1036" class="css-a4x74f"><span>1036</span></td><td id="LC1036" class="css-1dcdqdg"><code><span class="code-comment"> */</span>
</code></td></tr><tr><td id="L1037" class="css-a4x74f"><span>1037</span></td><td id="LC1037" class="css-1dcdqdg"><code><span class="code-function"><span class="code-keyword">function</span> <span class="code-title">setStyles</span>(<span class="code-params">element, styles</span>) </span>{
</code></td></tr><tr><td id="L1038" class="css-a4x74f"><span>1038</span></td><td id="LC1038" class="css-1dcdqdg"><code>  <span class="code-built_in">Object</span>.keys(styles).forEach(<span class="code-function"><span class="code-keyword">function</span> (<span class="code-params">prop</span>) </span>{
</code></td></tr><tr><td id="L1039" class="css-a4x74f"><span>1039</span></td><td id="LC1039" class="css-1dcdqdg"><code>    <span class="code-keyword">var</span> unit = <span class="code-string">''</span>;
</code></td></tr><tr><td id="L1040" class="css-a4x74f"><span>1040</span></td><td id="LC1040" class="css-1dcdqdg"><code>    <span class="code-comment">// add unit if the value is numeric and is one of the following</span>
</code></td></tr><tr><td id="L1041" class="css-a4x74f"><span>1041</span></td><td id="LC1041" class="css-1dcdqdg"><code>    <span class="code-keyword">if</span> ([<span class="code-string">'width'</span>, <span class="code-string">'height'</span>, <span class="code-string">'top'</span>, <span class="code-string">'right'</span>, <span class="code-string">'bottom'</span>, <span class="code-string">'left'</span>].indexOf(prop) !== <span class="code-number">-1</span> &amp;&amp; isNumeric(styles[prop])) {
</code></td></tr><tr><td id="L1042" class="css-a4x74f"><span>1042</span></td><td id="LC1042" class="css-1dcdqdg"><code>      unit = <span class="code-string">'px'</span>;
</code></td></tr><tr><td id="L1043" class="css-a4x74f"><span>1043</span></td><td id="LC1043" class="css-1dcdqdg"><code>    }
</code></td></tr><tr><td id="L1044" class="css-a4x74f"><span>1044</span></td><td id="LC1044" class="css-1dcdqdg"><code>    element.style[prop] = styles[prop] + unit;
</code></td></tr><tr><td id="L1045" class="css-a4x74f"><span>1045</span></td><td id="LC1045" class="css-1dcdqdg"><code>  });
</code></td></tr><tr><td id="L1046" class="css-a4x74f"><span>1046</span></td><td id="LC1046" class="css-1dcdqdg"><code>}
</code></td></tr><tr><td id="L1047" class="css-a4x74f"><span>1047</span></td><td id="LC1047" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L1048" class="css-a4x74f"><span>1048</span></td><td id="LC1048" class="css-1dcdqdg"><code><span class="code-function"><span class="code-keyword">function</span> <span class="code-title">attachToScrollParents</span>(<span class="code-params">scrollParent, event, callback, scrollParents</span>) </span>{
</code></td></tr><tr><td id="L1049" class="css-a4x74f"><span>1049</span></td><td id="LC1049" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> isBody = scrollParent.nodeName === <span class="code-string">'BODY'</span>;
</code></td></tr><tr><td id="L1050" class="css-a4x74f"><span>1050</span></td><td id="LC1050" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> target = isBody ? scrollParent.ownerDocument.defaultView : scrollParent;
</code></td></tr><tr><td id="L1051" class="css-a4x74f"><span>1051</span></td><td id="LC1051" class="css-1dcdqdg"><code>  target.addEventListener(event, callback, { <span class="code-attr">passive</span>: <span class="code-literal">true</span> });
</code></td></tr><tr><td id="L1052" class="css-a4x74f"><span>1052</span></td><td id="LC1052" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L1053" class="css-a4x74f"><span>1053</span></td><td id="LC1053" class="css-1dcdqdg"><code>  <span class="code-keyword">if</span> (!isBody) {
</code></td></tr><tr><td id="L1054" class="css-a4x74f"><span>1054</span></td><td id="LC1054" class="css-1dcdqdg"><code>    attachToScrollParents(getScrollParent(target.parentNode), event, callback, scrollParents);
</code></td></tr><tr><td id="L1055" class="css-a4x74f"><span>1055</span></td><td id="LC1055" class="css-1dcdqdg"><code>  }
</code></td></tr><tr><td id="L1056" class="css-a4x74f"><span>1056</span></td><td id="LC1056" class="css-1dcdqdg"><code>  scrollParents.push(target);
</code></td></tr><tr><td id="L1057" class="css-a4x74f"><span>1057</span></td><td id="LC1057" class="css-1dcdqdg"><code>}
</code></td></tr><tr><td id="L1058" class="css-a4x74f"><span>1058</span></td><td id="LC1058" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L1059" class="css-a4x74f"><span>1059</span></td><td id="LC1059" class="css-1dcdqdg"><code><span class="code-comment">/**
</span></code></td></tr><tr><td id="L1060" class="css-a4x74f"><span>1060</span></td><td id="LC1060" class="css-1dcdqdg"><code><span class="code-comment"> * Setup needed event listeners used to update the popper position
</span></code></td></tr><tr><td id="L1061" class="css-a4x74f"><span>1061</span></td><td id="LC1061" class="css-1dcdqdg"><code><span class="code-comment"> * @method
</span></code></td></tr><tr><td id="L1062" class="css-a4x74f"><span>1062</span></td><td id="LC1062" class="css-1dcdqdg"><code><span class="code-comment"> * @memberof Popper.Utils
</span></code></td></tr><tr><td id="L1063" class="css-a4x74f"><span>1063</span></td><td id="LC1063" class="css-1dcdqdg"><code><span class="code-comment"> * @private
</span></code></td></tr><tr><td id="L1064" class="css-a4x74f"><span>1064</span></td><td id="LC1064" class="css-1dcdqdg"><code><span class="code-comment"> */</span>
</code></td></tr><tr><td id="L1065" class="css-a4x74f"><span>1065</span></td><td id="LC1065" class="css-1dcdqdg"><code><span class="code-function"><span class="code-keyword">function</span> <span class="code-title">setupEventListeners</span>(<span class="code-params">reference, options, state, updateBound</span>) </span>{
</code></td></tr><tr><td id="L1066" class="css-a4x74f"><span>1066</span></td><td id="LC1066" class="css-1dcdqdg"><code>  <span class="code-comment">// Resize event listener on window</span>
</code></td></tr><tr><td id="L1067" class="css-a4x74f"><span>1067</span></td><td id="LC1067" class="css-1dcdqdg"><code>  state.updateBound = updateBound;
</code></td></tr><tr><td id="L1068" class="css-a4x74f"><span>1068</span></td><td id="LC1068" class="css-1dcdqdg"><code>  getWindow(reference).addEventListener(<span class="code-string">'resize'</span>, state.updateBound, { <span class="code-attr">passive</span>: <span class="code-literal">true</span> });
</code></td></tr><tr><td id="L1069" class="css-a4x74f"><span>1069</span></td><td id="LC1069" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L1070" class="css-a4x74f"><span>1070</span></td><td id="LC1070" class="css-1dcdqdg"><code>  <span class="code-comment">// Scroll event listener on scroll parents</span>
</code></td></tr><tr><td id="L1071" class="css-a4x74f"><span>1071</span></td><td id="LC1071" class="css-1dcdqdg"><code>  <span class="code-keyword">var</span> scrollElement = getScrollParent(reference);
</code></td></tr><tr><td id="L1072" class="css-a4x74f"><span>1072</span></td><td id="LC1072" class="css-1dcdqdg"><code>  attachToScrollParents(scrollElement, <span class="code-string">'scroll'</span>, state.updateBound, state.scrollParents);
</code></td></tr><tr><td id="L1073" class="css-a4x74f"><span>1073</span></td><td id="LC1073" class="css-1dcdqdg"><code>  state.scrollElement = scrollElement;
</code></td></tr><tr><td id="L1074" class="css-a4x74f"><span>1074</span></td><td id="LC1074" class="css-1dcdqdg"><code>  state.eventsEnabled = <span class="code-literal">true</span>;
</code></td></tr><tr><td id="L1075" class="css-a4x74f"><span>1075</span></td><td id="LC1075" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L1076" class="css-a4x74f"><span>1076</span></td><td id="LC1076" class="css-1dcdqdg"><code>  <span class="code-keyword">return</span> state;
</code></td></tr><tr><td id="L1077" class="css-a4x74f"><span>1077</span></td><td id="LC1077" class="css-1dcdqdg"><code>}
</code></td></tr><tr><td id="L1078" class="css-a4x74f"><span>1078</span></td><td id="LC1078" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L1079" class="css-a4x74f"><span>1079</span></td><td id="LC1079" class="css-1dcdqdg"><code><span class="code-comment">// This is here just for backward compatibility with versions lower than v1.10.3</span>
</code></td></tr><tr><td id="L1080" class="css-a4x74f"><span>1080</span></td><td id="LC1080" class="css-1dcdqdg"><code><span class="code-comment">// you should import the utilities using named exports, if you want them all use:</span>
</code></td></tr><tr><td id="L1081" class="css-a4x74f"><span>1081</span></td><td id="LC1081" class="css-1dcdqdg"><code><span class="code-comment">// ```</span>
</code></td></tr><tr><td id="L1082" class="css-a4x74f"><span>1082</span></td><td id="LC1082" class="css-1dcdqdg"><code><span class="code-comment">// import * as PopperUtils from 'popper-utils';</span>
</code></td></tr><tr><td id="L1083" class="css-a4x74f"><span>1083</span></td><td id="LC1083" class="css-1dcdqdg"><code><span class="code-comment">// ```</span>
</code></td></tr><tr><td id="L1084" class="css-a4x74f"><span>1084</span></td><td id="LC1084" class="css-1dcdqdg"><code><span class="code-comment">// The default export will be removed in the next major version.</span>
</code></td></tr><tr><td id="L1085" class="css-a4x74f"><span>1085</span></td><td id="LC1085" class="css-1dcdqdg"><code><span class="code-keyword">var</span> index = {
</code></td></tr><tr><td id="L1086" class="css-a4x74f"><span>1086</span></td><td id="LC1086" class="css-1dcdqdg"><code>  computeAutoPlacement: computeAutoPlacement,
</code></td></tr><tr><td id="L1087" class="css-a4x74f"><span>1087</span></td><td id="LC1087" class="css-1dcdqdg"><code>  debounce: debounce,
</code></td></tr><tr><td id="L1088" class="css-a4x74f"><span>1088</span></td><td id="LC1088" class="css-1dcdqdg"><code>  findIndex: findIndex,
</code></td></tr><tr><td id="L1089" class="css-a4x74f"><span>1089</span></td><td id="LC1089" class="css-1dcdqdg"><code>  getBordersSize: getBordersSize,
</code></td></tr><tr><td id="L1090" class="css-a4x74f"><span>1090</span></td><td id="LC1090" class="css-1dcdqdg"><code>  getBoundaries: getBoundaries,
</code></td></tr><tr><td id="L1091" class="css-a4x74f"><span>1091</span></td><td id="LC1091" class="css-1dcdqdg"><code>  getBoundingClientRect: getBoundingClientRect,
</code></td></tr><tr><td id="L1092" class="css-a4x74f"><span>1092</span></td><td id="LC1092" class="css-1dcdqdg"><code>  getClientRect: getClientRect,
</code></td></tr><tr><td id="L1093" class="css-a4x74f"><span>1093</span></td><td id="LC1093" class="css-1dcdqdg"><code>  getOffsetParent: getOffsetParent,
</code></td></tr><tr><td id="L1094" class="css-a4x74f"><span>1094</span></td><td id="LC1094" class="css-1dcdqdg"><code>  getOffsetRect: getOffsetRect,
</code></td></tr><tr><td id="L1095" class="css-a4x74f"><span>1095</span></td><td id="LC1095" class="css-1dcdqdg"><code>  getOffsetRectRelativeToArbitraryNode: getOffsetRectRelativeToArbitraryNode,
</code></td></tr><tr><td id="L1096" class="css-a4x74f"><span>1096</span></td><td id="LC1096" class="css-1dcdqdg"><code>  getOuterSizes: getOuterSizes,
</code></td></tr><tr><td id="L1097" class="css-a4x74f"><span>1097</span></td><td id="LC1097" class="css-1dcdqdg"><code>  getParentNode: getParentNode,
</code></td></tr><tr><td id="L1098" class="css-a4x74f"><span>1098</span></td><td id="LC1098" class="css-1dcdqdg"><code>  getPopperOffsets: getPopperOffsets,
</code></td></tr><tr><td id="L1099" class="css-a4x74f"><span>1099</span></td><td id="LC1099" class="css-1dcdqdg"><code>  getReferenceOffsets: getReferenceOffsets,
</code></td></tr><tr><td id="L1100" class="css-a4x74f"><span>1100</span></td><td id="LC1100" class="css-1dcdqdg"><code>  getScroll: getScroll,
</code></td></tr><tr><td id="L1101" class="css-a4x74f"><span>1101</span></td><td id="LC1101" class="css-1dcdqdg"><code>  getScrollParent: getScrollParent,
</code></td></tr><tr><td id="L1102" class="css-a4x74f"><span>1102</span></td><td id="LC1102" class="css-1dcdqdg"><code>  getStyleComputedProperty: getStyleComputedProperty,
</code></td></tr><tr><td id="L1103" class="css-a4x74f"><span>1103</span></td><td id="LC1103" class="css-1dcdqdg"><code>  getSupportedPropertyName: getSupportedPropertyName,
</code></td></tr><tr><td id="L1104" class="css-a4x74f"><span>1104</span></td><td id="LC1104" class="css-1dcdqdg"><code>  getWindowSizes: getWindowSizes,
</code></td></tr><tr><td id="L1105" class="css-a4x74f"><span>1105</span></td><td id="LC1105" class="css-1dcdqdg"><code>  isFixed: isFixed,
</code></td></tr><tr><td id="L1106" class="css-a4x74f"><span>1106</span></td><td id="LC1106" class="css-1dcdqdg"><code>  isFunction: isFunction,
</code></td></tr><tr><td id="L1107" class="css-a4x74f"><span>1107</span></td><td id="LC1107" class="css-1dcdqdg"><code>  isModifierEnabled: isModifierEnabled,
</code></td></tr><tr><td id="L1108" class="css-a4x74f"><span>1108</span></td><td id="LC1108" class="css-1dcdqdg"><code>  isModifierRequired: isModifierRequired,
</code></td></tr><tr><td id="L1109" class="css-a4x74f"><span>1109</span></td><td id="LC1109" class="css-1dcdqdg"><code>  isNumeric: isNumeric,
</code></td></tr><tr><td id="L1110" class="css-a4x74f"><span>1110</span></td><td id="LC1110" class="css-1dcdqdg"><code>  removeEventListeners: removeEventListeners,
</code></td></tr><tr><td id="L1111" class="css-a4x74f"><span>1111</span></td><td id="LC1111" class="css-1dcdqdg"><code>  runModifiers: runModifiers,
</code></td></tr><tr><td id="L1112" class="css-a4x74f"><span>1112</span></td><td id="LC1112" class="css-1dcdqdg"><code>  setAttributes: setAttributes,
</code></td></tr><tr><td id="L1113" class="css-a4x74f"><span>1113</span></td><td id="LC1113" class="css-1dcdqdg"><code>  setStyles: setStyles,
</code></td></tr><tr><td id="L1114" class="css-a4x74f"><span>1114</span></td><td id="LC1114" class="css-1dcdqdg"><code>  setupEventListeners: setupEventListeners
</code></td></tr><tr><td id="L1115" class="css-a4x74f"><span>1115</span></td><td id="LC1115" class="css-1dcdqdg"><code>};
</code></td></tr><tr><td id="L1116" class="css-a4x74f"><span>1116</span></td><td id="LC1116" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L1117" class="css-a4x74f"><span>1117</span></td><td id="LC1117" class="css-1dcdqdg"><code>exports.computeAutoPlacement = computeAutoPlacement;
</code></td></tr><tr><td id="L1118" class="css-a4x74f"><span>1118</span></td><td id="LC1118" class="css-1dcdqdg"><code>exports.debounce = debounce;
</code></td></tr><tr><td id="L1119" class="css-a4x74f"><span>1119</span></td><td id="LC1119" class="css-1dcdqdg"><code>exports.findIndex = findIndex;
</code></td></tr><tr><td id="L1120" class="css-a4x74f"><span>1120</span></td><td id="LC1120" class="css-1dcdqdg"><code>exports.getBordersSize = getBordersSize;
</code></td></tr><tr><td id="L1121" class="css-a4x74f"><span>1121</span></td><td id="LC1121" class="css-1dcdqdg"><code>exports.getBoundaries = getBoundaries;
</code></td></tr><tr><td id="L1122" class="css-a4x74f"><span>1122</span></td><td id="LC1122" class="css-1dcdqdg"><code>exports.getBoundingClientRect = getBoundingClientRect;
</code></td></tr><tr><td id="L1123" class="css-a4x74f"><span>1123</span></td><td id="LC1123" class="css-1dcdqdg"><code>exports.getClientRect = getClientRect;
</code></td></tr><tr><td id="L1124" class="css-a4x74f"><span>1124</span></td><td id="LC1124" class="css-1dcdqdg"><code>exports.getOffsetParent = getOffsetParent;
</code></td></tr><tr><td id="L1125" class="css-a4x74f"><span>1125</span></td><td id="LC1125" class="css-1dcdqdg"><code>exports.getOffsetRect = getOffsetRect;
</code></td></tr><tr><td id="L1126" class="css-a4x74f"><span>1126</span></td><td id="LC1126" class="css-1dcdqdg"><code>exports.getOffsetRectRelativeToArbitraryNode = getOffsetRectRelativeToArbitraryNode;
</code></td></tr><tr><td id="L1127" class="css-a4x74f"><span>1127</span></td><td id="LC1127" class="css-1dcdqdg"><code>exports.getOuterSizes = getOuterSizes;
</code></td></tr><tr><td id="L1128" class="css-a4x74f"><span>1128</span></td><td id="LC1128" class="css-1dcdqdg"><code>exports.getParentNode = getParentNode;
</code></td></tr><tr><td id="L1129" class="css-a4x74f"><span>1129</span></td><td id="LC1129" class="css-1dcdqdg"><code>exports.getPopperOffsets = getPopperOffsets;
</code></td></tr><tr><td id="L1130" class="css-a4x74f"><span>1130</span></td><td id="LC1130" class="css-1dcdqdg"><code>exports.getReferenceOffsets = getReferenceOffsets;
</code></td></tr><tr><td id="L1131" class="css-a4x74f"><span>1131</span></td><td id="LC1131" class="css-1dcdqdg"><code>exports.getScroll = getScroll;
</code></td></tr><tr><td id="L1132" class="css-a4x74f"><span>1132</span></td><td id="LC1132" class="css-1dcdqdg"><code>exports.getScrollParent = getScrollParent;
</code></td></tr><tr><td id="L1133" class="css-a4x74f"><span>1133</span></td><td id="LC1133" class="css-1dcdqdg"><code>exports.getStyleComputedProperty = getStyleComputedProperty;
</code></td></tr><tr><td id="L1134" class="css-a4x74f"><span>1134</span></td><td id="LC1134" class="css-1dcdqdg"><code>exports.getSupportedPropertyName = getSupportedPropertyName;
</code></td></tr><tr><td id="L1135" class="css-a4x74f"><span>1135</span></td><td id="LC1135" class="css-1dcdqdg"><code>exports.getWindowSizes = getWindowSizes;
</code></td></tr><tr><td id="L1136" class="css-a4x74f"><span>1136</span></td><td id="LC1136" class="css-1dcdqdg"><code>exports.isFixed = isFixed;
</code></td></tr><tr><td id="L1137" class="css-a4x74f"><span>1137</span></td><td id="LC1137" class="css-1dcdqdg"><code>exports.isFunction = isFunction;
</code></td></tr><tr><td id="L1138" class="css-a4x74f"><span>1138</span></td><td id="LC1138" class="css-1dcdqdg"><code>exports.isModifierEnabled = isModifierEnabled;
</code></td></tr><tr><td id="L1139" class="css-a4x74f"><span>1139</span></td><td id="LC1139" class="css-1dcdqdg"><code>exports.isModifierRequired = isModifierRequired;
</code></td></tr><tr><td id="L1140" class="css-a4x74f"><span>1140</span></td><td id="LC1140" class="css-1dcdqdg"><code>exports.isNumeric = isNumeric;
</code></td></tr><tr><td id="L1141" class="css-a4x74f"><span>1141</span></td><td id="LC1141" class="css-1dcdqdg"><code>exports.removeEventListeners = removeEventListeners;
</code></td></tr><tr><td id="L1142" class="css-a4x74f"><span>1142</span></td><td id="LC1142" class="css-1dcdqdg"><code>exports.runModifiers = runModifiers;
</code></td></tr><tr><td id="L1143" class="css-a4x74f"><span>1143</span></td><td id="LC1143" class="css-1dcdqdg"><code>exports.setAttributes = setAttributes;
</code></td></tr><tr><td id="L1144" class="css-a4x74f"><span>1144</span></td><td id="LC1144" class="css-1dcdqdg"><code>exports.setStyles = setStyles;
</code></td></tr><tr><td id="L1145" class="css-a4x74f"><span>1145</span></td><td id="LC1145" class="css-1dcdqdg"><code>exports.setupEventListeners = setupEventListeners;
</code></td></tr><tr><td id="L1146" class="css-a4x74f"><span>1146</span></td><td id="LC1146" class="css-1dcdqdg"><code>exports[<span class="code-string">'default'</span>] = index;
</code></td></tr><tr><td id="L1147" class="css-a4x74f"><span>1147</span></td><td id="LC1147" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L1148" class="css-a4x74f"><span>1148</span></td><td id="LC1148" class="css-1dcdqdg"><code><span class="code-built_in">Object</span>.defineProperty(exports, <span class="code-string">'__esModule'</span>, { <span class="code-attr">value</span>: <span class="code-literal">true</span> });
</code></td></tr><tr><td id="L1149" class="css-a4x74f"><span>1149</span></td><td id="LC1149" class="css-1dcdqdg"><code>
</code></td></tr><tr><td id="L1150" class="css-a4x74f"><span>1150</span></td><td id="LC1150" class="css-1dcdqdg"><code>})));
</code></td></tr><tr><td id="L1151" class="css-a4x74f"><span>1151</span></td><td id="LC1151" class="css-1dcdqdg"><code><span class="code-comment">//# sourceMappingURL=popper-utils.js.map</span>
</code></td></tr></tbody></table></div></div></div></div><style data-emotion-css="1teho9j">.css-1teho9j{margin-top:5rem;background:black;color:#aaa;}</style><footer class="css-1teho9j"><style data-emotion-css="1ui8put">.css-1ui8put{max-width:940px;padding:10px 20px;margin:0 auto;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;}</style><div class="css-1ui8put"><p>© <!-- -->2019<!-- --> UNPKG</p><style data-emotion-css="la3nd4">.css-la3nd4{font-size:1.5rem;}</style><p class="css-la3nd4"><style data-emotion-css="bogekj">.css-bogekj{color:#aaa;display:inline-block;}.css-bogekj:hover{color:white;}</style><a title="Twitter" href="https://twitter.com/unpkg" class="css-bogekj"><style data-emotion-css="i6dzq1">.css-i6dzq1{vertical-align:text-bottom;}</style><svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="css-i6dzq1" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg"><path d="M459.37 151.716c.325 4.548.325 9.097.325 13.645 0 138.72-105.583 298.558-298.558 298.558-59.452 0-114.68-17.219-161.137-47.106 8.447.974 16.568 1.299 25.34 1.299 49.055 0 94.213-16.568 130.274-44.832-46.132-.975-84.792-31.188-98.112-72.772 6.498.974 12.995 1.624 19.818 1.624 9.421 0 18.843-1.3 27.614-3.573-48.081-9.747-84.143-51.98-84.143-102.985v-1.299c13.969 7.797 30.214 12.67 47.431 13.319-28.264-18.843-46.781-51.005-46.781-87.391 0-19.492 5.197-37.36 14.294-52.954 51.655 63.675 129.3 105.258 216.365 109.807-1.624-7.797-2.599-15.918-2.599-24.04 0-57.828 46.782-104.934 104.934-104.934 30.213 0 57.502 12.67 76.67 33.137 23.715-4.548 46.456-13.32 66.599-25.34-7.798 24.366-24.366 44.833-46.132 57.827 21.117-2.273 41.584-8.122 60.426-16.243-14.292 20.791-32.161 39.308-52.628 54.253z"></path></svg></a><style data-emotion-css="ap0i2q">.css-ap0i2q{color:#aaa;display:inline-block;margin-left:1rem;}.css-ap0i2q:hover{color:white;}</style><a title="GitHub" href="https://github.com/mjackson/unpkg" class="css-ap0i2q"><svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 496 512" class="css-i6dzq1" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg"><path d="M165.9 397.4c0 2-2.3 3.6-5.2 3.6-3.3.3-5.6-1.3-5.6-3.6 0-2 2.3-3.6 5.2-3.6 3-.3 5.6 1.3 5.6 3.6zm-31.1-4.5c-.7 2 1.3 4.3 4.3 4.9 2.6 1 5.6 0 6.2-2s-1.3-4.3-4.3-5.2c-2.6-.7-5.5.3-6.2 2.3zm44.2-1.7c-2.9.7-4.9 2.6-4.6 4.9.3 2 2.9 3.3 5.9 2.6 2.9-.7 4.9-2.6 4.6-4.6-.3-1.9-3-3.2-5.9-2.9zM244.8 8C106.1 8 0 113.3 0 252c0 110.9 69.8 205.8 169.5 239.2 12.8 2.3 17.3-5.6 17.3-12.1 0-6.2-.3-40.4-.3-61.4 0 0-70 15-84.7-29.8 0 0-11.4-29.1-27.8-36.6 0 0-22.9-15.7 1.6-15.4 0 0 24.9 2 38.6 25.8 21.9 38.6 58.6 27.5 72.9 20.9 2.3-16 8.8-27.1 16-33.7-55.9-6.2-112.3-14.3-112.3-110.5 0-27.5 7.6-41.3 23.6-58.9-2.6-6.5-11.1-33.3 2.6-67.9 20.9-6.5 69 27 69 27 20-5.6 41.5-8.5 62.8-8.5s42.8 2.9 62.8 8.5c0 0 48.1-33.6 69-27 13.7 34.7 5.2 61.4 2.6 67.9 16 17.7 25.8 31.5 25.8 58.9 0 96.5-58.9 104.2-114.8 110.5 9.2 7.9 17 22.9 17 46.4 0 33.7-.3 75.4-.3 83.6 0 6.5 4.6 14.4 17.3 12.1C428.2 457.8 496 362.9 496 252 496 113.3 383.5 8 244.8 8zM97.2 352.9c-1.3 1-1 3.3.7 5.2 1.6 1.6 3.9 2.3 5.2 1 1.3-1 1-3.3-.7-5.2-1.6-1.6-3.9-2.3-5.2-1zm-10.8-8.1c-.7 1.3.3 2.9 2.3 3.9 1.6 1 3.6.7 4.3-.7.7-1.3-.3-2.9-2.3-3.9-2-.6-3.6-.3-4.3.7zm32.4 35.6c-1.6 1.3-1 4.3 1.3 6.2 2.3 2.3 5.2 2.6 6.5 1 1.3-1.3.7-4.3-1.3-6.2-2.2-2.3-5.2-2.6-6.5-1zm-11.4-14.7c-1.6 1-1.6 3.6 0 5.9 1.6 2.3 4.3 3.3 5.6 2.3 1.6-1.3 1.6-3.9 0-6.2-1.4-2.3-4-3.3-5.6-2z"></path></svg></a></p></div></footer></div><script src="/react@16.8.6/umd/react.production.min.js"></script><script src="/react-dom@16.8.6/umd/react-dom.production.min.js"></script><script src="/@emotion/core@10.0.6/dist/core.umd.min.js"></script><script>'use strict';
(function(t, z, c) {
  function A() {
    A = Object.assign || function(a) {
      for (var b = 1; b < arguments.length; b++) {
        var d = arguments[b], c;
        for (c in d) {
          Object.prototype.hasOwnProperty.call(d, c) && (a[c] = d[c]);
        }
      }
      return a;
    };
    return A.apply(this, arguments);
  }
  function Q(a, b) {
    if (null == a) {
      return {};
    }
    var d = {}, c = Object.keys(a), f;
    for (f = 0; f < c.length; f++) {
      var k = c[f];
      0 <= b.indexOf(k) || (d[k] = a[k]);
    }
    return d;
  }
  function R(a, b) {
    b || (b = a.slice(0));
    a.raw = b;
    return a;
  }
  function S(a) {
    return a && a.__esModule && Object.prototype.hasOwnProperty.call(a, "default") ? a["default"] : a;
  }
  function D(a, b) {
    return b = {exports:{}}, a(b, b.exports), b.exports;
  }
  function J(a, b, d, c, f) {
    for (var k in a) {
      if (sa(a, k)) {
        try {
          if ("function" !== typeof a[k]) {
            var h = Error((c || "React class") + ": " + d + " type `" + k + "` is invalid; it must be a function, usually from the `prop-types` package, but received `" + typeof a[k] + "`.");
            h.name = "Invariant Violation";
            throw h;
          }
          var l = a[k](b, k, c, d, null, "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED");
        } catch (q) {
          l = q;
        }
        !l || l instanceof Error || K((c || "React class") + ": type specification of " + d + " `" + k + "` is invalid; the type checker function must return `null` or an `Error` but returned a " + typeof l + ". You may have forgotten to pass an argument to the type checker creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and shape all require an argument).");
        if (l instanceof Error && !(l.message in L)) {
          L[l.message] = !0;
          var B = f ? f() : "";
          K("Failed " + d + " type: " + l.message + (null != B ? B : ""));
        }
      }
    }
  }
  function E() {
    return null;
  }
  function ta(a) {
    var b = a.children;
    a = Q(a, ["children"]);
    return M.createElement(T.Provider, {children:b, value:a});
  }
  function U(a) {
    return a && a.map(function(a, d) {
      return t.createElement(a.tag, y({key:d}, a.attr), U(a.child));
    });
  }
  function F(a) {
    return function(b) {
      return t.createElement(ua, y({attr:y({}, a.attr)}, b), U(a.child));
    };
  }
  function ua(a) {
    var b = function(b) {
      var c = a.size || b.size || "1em";
      if (b.className) {
        var d = b.className;
      }
      a.className && (d = (d ? d + " " : "") + a.className);
      var k = a.attr, r = a.title, l = ["attr", "title"], B = {}, q;
      for (q in a) {
        Object.prototype.hasOwnProperty.call(a, q) && 0 > l.indexOf(q) && (B[q] = a[q]);
      }
      if (null != a && "function" === typeof Object.getOwnPropertySymbols) {
        var p = 0;
        for (q = Object.getOwnPropertySymbols(a); p < q.length; p++) {
          0 > l.indexOf(q[p]) && (B[q[p]] = a[q[p]]);
        }
      }
      return t.createElement("svg", y({stroke:"currentColor", fill:"currentColor", strokeWidth:"0"}, b.attr, k, B, {className:d, style:y({color:a.color || b.color}, b.style, a.style), height:c, width:c, xmlns:"http://www.w3.org/2000/svg"}), r && t.createElement("title", null, r), a.children);
    };
    return void 0 !== V ? t.createElement(V.Consumer, null, function(a) {
      return b(a);
    }) : b(W);
  }
  function G(a, b) {
    var d = b.css;
    b = Q(b, ["css"]);
    return c.jsx(a, A({css:A({}, d, {verticalAlign:"text-bottom"})}, b));
  }
  function va(a) {
    return G(X, a);
  }
  function wa(a) {
    return G(Y, a);
  }
  function xa(a) {
    return G(Z, a);
  }
  function ya(a) {
    return G(aa, a);
  }
  function ba(a) {
    var b = a.path, d = a.details, h = [];
    "/" !== b && h.push(c.jsx("tr", {key:".."}, c.jsx("td", {css:N}), c.jsx("td", {css:x}, c.jsx("a", {title:"Parent directory", href:"../", css:O}, "..")), c.jsx("td", {css:x}), c.jsx("td", {css:P})));
    a = Object.keys(d).reduce(function(a, b) {
      var c = a.subdirs, f = a.files;
      b = d[b];
      "directory" === b.type ? c.push(b) : "file" === b.type && f.push(b);
      return a;
    }, {subdirs:[], files:[]});
    var f = a.files;
    a.subdirs.sort(ca("path")).forEach(function(a) {
      a = a.path.substr(1 < b.length ? b.length + 1 : 1);
      var d = a + "/";
      h.push(c.jsx("tr", {key:a}, c.jsx("td", {css:N}, c.jsx(va, null)), c.jsx("td", {css:x}, c.jsx("a", {title:a, href:d, css:O}, a)), c.jsx("td", {css:x}, "-"), c.jsx("td", {css:P}, "-")));
    });
    f.sort(ca("path")).forEach(function(a) {
      var d = a.size, f = a.contentType;
      a = a.path.substr(1 < b.length ? b.length + 1 : 1);
      h.push(c.jsx("tr", {key:a}, c.jsx("td", {css:N}, c.jsx(wa, null)), c.jsx("td", {css:x}, c.jsx("a", {title:a, href:a, css:O}, a)), c.jsx("td", {css:x}, da(d)), c.jsx("td", {css:P}, f)));
    });
    return c.jsx("div", {css:{border:"1px solid #dfe2e5", borderRadius:3, borderTopWidth:0, "@media (max-width: 700px)":{borderRightWidth:0, borderLeftWidth:0}}}, c.jsx("table", {css:{width:"100%", borderCollapse:"collapse", borderRadius:2, background:"#fff", "@media (max-width: 700px)":{"& th + th + th + th, & td + td + td + td":{display:"none"}}}}, c.jsx("thead", null, c.jsx("tr", null, c.jsx("th", null, c.jsx(H, null, "Icon")), c.jsx("th", null, c.jsx(H, null, "Name")), c.jsx("th", null, c.jsx(H, 
    null, "Size")), c.jsx("th", null, c.jsx(H, null, "Content Type")))), c.jsx("tbody", null, h)));
  }
  function za(a) {
    a = a.split("/");
    return a[a.length - 1];
  }
  function Aa(a) {
    var b = a.uri;
    return c.jsx("div", {css:{padding:20, textAlign:"center"}}, c.jsx("img", {alt:za(a.path), src:b}));
  }
  function Ba(a) {
    a = a.highlights.slice(0);
    var b = a.length && "" === a[a.length - 1];
    b && a.pop();
    return c.jsx("div", {className:"code-listing", css:{overflowX:"auto", overflowY:"hidden", paddingTop:5, paddingBottom:5}}, c.jsx("table", {css:{border:"none", borderCollapse:"collapse", borderSpacing:0}}, c.jsx("tbody", null, a.map(function(a, b) {
      var d = b + 1;
      return c.jsx("tr", {key:b}, c.jsx("td", {id:"L" + d, css:{paddingLeft:10, paddingRight:10, color:"rgba(27,31,35,.3)", textAlign:"right", verticalAlign:"top", width:"1%", minWidth:50, userSelect:"none"}}, c.jsx("span", null, d)), c.jsx("td", {id:"LC" + d, css:{paddingLeft:10, paddingRight:10, color:"#24292e", whiteSpace:"pre"}}, c.jsx("code", {dangerouslySetInnerHTML:{__html:a}})));
    }), !b && c.jsx("tr", {key:"no-newline"}, c.jsx("td", {css:{paddingLeft:10, paddingRight:10, color:"rgba(27,31,35,.3)", textAlign:"right", verticalAlign:"top", width:"1%", minWidth:50, userSelect:"none"}}, "\\"), c.jsx("td", {css:{paddingLeft:10, color:"rgba(27,31,35,.3)", userSelect:"none"}}, "No newline at end of file")))));
  }
  function Ca() {
    return c.jsx("div", {css:{padding:20}}, c.jsx("p", {css:{textAlign:"center"}}, "No preview available."));
  }
  function ea(a) {
    var b = a.path, d = a.details, h = t.useContext(T);
    a = h.packageName;
    h = h.packageVersion;
    var f = d.highlights, k = d.uri, r = d.language;
    d = d.size;
    var l = b.split("/");
    l = l[l.length - 1];
    return c.jsx("div", {css:{border:"1px solid #dfe2e5", borderRadius:3, "@media (max-width: 700px)":{borderRightWidth:0, borderLeftWidth:0}}}, c.jsx("div", {css:{padding:10, background:"#f6f8fa", color:"#424242", border:"1px solid #d1d5da", borderTopLeftRadius:3, borderTopRightRadius:3, margin:"-1px -1px 0", display:"flex", flexDirection:"row", alignItems:"center", justifyContent:"space-between", "@media (max-width: 700px)":{paddingRight:20, paddingLeft:20}}}, c.jsx("span", null, da(d)), " ", c.jsx("span", 
    null, r), " ", c.jsx("a", {title:l, href:"/" + a + "@" + h + b, css:{display:"inline-block", textDecoration:"none", padding:"2px 8px", fontWeight:600, fontSize:"0.9rem", color:"#24292e", backgroundColor:"#eff3f6", border:"1px solid rgba(27,31,35,.2)", borderRadius:3, ":hover":{backgroundColor:"#e6ebf1", borderColor:"rgba(27,31,35,.35)"}, ":active":{backgroundColor:"#e9ecef", borderColor:"rgba(27,31,35,.35)", boxShadow:"inset 0 0.15em 0.3em rgba(27,31,35,.15)"}}}, "View Raw")), f ? c.jsx(Ba, {highlights:f}) : 
    k ? c.jsx(Aa, {path:b, uri:k}) : c.jsx(Ca, null));
  }
  function fa() {
    var a = R(["\n  .code-listing {\n    background: #fbfdff;\n    color: #383a42;\n  }\n  .code-comment,\n  .code-quote {\n    color: #a0a1a7;\n    font-style: italic;\n  }\n  .code-doctag,\n  .code-keyword,\n  .code-link,\n  .code-formula {\n    color: #a626a4;\n  }\n  .code-section,\n  .code-name,\n  .code-selector-tag,\n  .code-deletion,\n  .code-subst {\n    color: #e45649;\n  }\n  .code-literal {\n    color: #0184bb;\n  }\n  .code-string,\n  .code-regexp,\n  .code-addition,\n  .code-attribute,\n  .code-meta-string {\n    color: #50a14f;\n  }\n  .code-built_in,\n  .code-class .code-title {\n    color: #c18401;\n  }\n  .code-attr,\n  .code-variable,\n  .code-template-variable,\n  .code-type,\n  .code-selector-class,\n  .code-selector-attr,\n  .code-selector-pseudo,\n  .code-number {\n    color: #986801;\n  }\n  .code-symbol,\n  .code-bullet,\n  .code-meta,\n  .code-selector-id,\n  .code-title {\n    color: #4078f2;\n  }\n  .code-emphasis {\n    font-style: italic;\n  }\n  .code-strong {\n    font-weight: bold;\n  }\n"]);
    fa = function() {
      return a;
    };
    return a;
  }
  function ha() {
    var a = R(["\n  html {\n    box-sizing: border-box;\n  }\n  *,\n  *:before,\n  *:after {\n    box-sizing: inherit;\n  }\n\n  html,\n  body,\n  #root {\n    height: 100%;\n    margin: 0;\n  }\n\n  body {\n    ", "\n    font-size: 16px;\n    line-height: 1.5;\n    background: white;\n    color: black;\n  }\n\n  code {\n    ", "\n  }\n\n  th,\n  td {\n    padding: 0;\n  }\n\n  select {\n    font-size: inherit;\n  }\n\n  #root {\n    display: flex;\n    flex-direction: column;\n  }\n"]);
    ha = function() {
      return a;
    };
    return a;
  }
  function ia(a) {
    var b = a.packageName, d = a.packageVersion, h = a.availableVersions;
    h = void 0 === h ? [] : h;
    var f = a.filename;
    a = a.target;
    var k = [];
    if ("/" === f) {
      k.push(b);
    } else {
      var r = "/browse/" + b + "@" + d;
      k.push(c.jsx("a", {href:r + "/", css:ja}, b));
      f = f.replace(/^\/+/, "").replace(/\/+$/, "").split("/");
      var l = f.pop();
      f.forEach(function(a) {
        r += "/" + a;
        k.push(c.jsx("a", {href:r + "/", css:ja}, a));
      });
      k.push(l);
    }
    return c.jsx(ta, {packageName:b, packageVersion:d}, c.jsx(t.Fragment, null, c.jsx(c.Global, {styles:Da}), c.jsx(c.Global, {styles:Ea}), c.jsx("div", {css:{flex:"1 0 auto"}}, c.jsx("div", {css:{maxWidth:940, padding:"0 20px", margin:"0 auto"}}, c.jsx("header", {css:{textAlign:"center"}}, c.jsx("h1", {css:{fontSize:"3rem", marginTop:"2rem"}}, c.jsx("a", {href:"/", css:{color:"#000", textDecoration:"none"}}, "UNPKG"))), c.jsx("header", {css:{display:"flex", flexDirection:"row", alignItems:"center", 
    "@media (max-width: 700px)":{flexDirection:"column-reverse", alignItems:"flex-start"}}}, c.jsx("h1", {css:{fontSize:"1.5rem", fontWeight:"normal", flex:1}}, c.jsx("nav", null, k.map(function(a, b, d) {
      return c.jsx("span", {key:b}, 0 !== b && c.jsx("span", {css:{paddingLeft:5, paddingRight:5}}, "/"), b === d.length - 1 ? c.jsx("strong", null, a) : a);
    }))), c.jsx("p", {css:{marginLeft:20, "@media (max-width: 700px)":{marginLeft:0, marginBottom:0}}}, c.jsx("label", null, "Version:", " ", c.jsx("select", {name:"version", defaultValue:d, onChange:function(a) {
      window.location.href = window.location.href.replace("@" + d, "@" + a.target.value);
    }, css:{appearance:"none", cursor:"pointer", padding:"4px 24px 4px 8px", fontWeight:600, fontSize:"0.9em", color:"#24292e", border:"1px solid rgba(27,31,35,.2)", borderRadius:3, backgroundColor:"#eff3f6", backgroundImage:"url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAKCAYAAAC9vt6cAAAAAXNSR0IArs4c6QAAARFJREFUKBVjZAACNS39RhBNKrh17WI9o4quoT3Dn78HSNUMUs/CzOTI/O7Vi4dCYpJ3/jP+92BkYGAlyiBGhm8MjIxJt65e3MQM0vDu9YvLYmISILYZELOBxHABRkaGr0yMzF23r12YDFIDNgDEePv65SEhEXENBkYGFSAXuyGMjF8Z/jOsvX3tYiFIDwgwQSgIaaijnvj/P8M5IO8HsjiY/f//D4b//88A1SQhywG9jQr09PS4v/1mPAeUUPzP8B8cJowMjL+Bqu6xMQmaXL164AuyDgwDQJLa2qYSP//9vARkCoMVMzK8YeVkNbh+9uxzMB+JwGoASF5Vx0jz/98/18BqmZi171w9D2EjaaYKEwAEK00XQLdJuwAAAABJRU5ErkJggg==)", 
    backgroundPosition:"right 8px center", backgroundRepeat:"no-repeat", backgroundSize:"auto 25%", ":hover":{backgroundColor:"#e6ebf1", borderColor:"rgba(27,31,35,.35)"}, ":active":{backgroundColor:"#e9ecef", borderColor:"rgba(27,31,35,.35)", boxShadow:"inset 0 0.15em 0.3em rgba(27,31,35,.15)"}}}, h.map(function(a) {
      return c.jsx("option", {key:a, value:a}, a);
    })))))), c.jsx("div", {css:{maxWidth:940, padding:"0 20px", margin:"0 auto", "@media (max-width: 700px)":{padding:0, margin:0}}}, "directory" === a.type ? c.jsx(ba, {path:a.path, details:a.details}) : "file" === a.type ? c.jsx(ea, {path:a.path, details:a.details}) : null)), c.jsx("footer", {css:{marginTop:"5rem", background:"black", color:"#aaa"}}, c.jsx("div", {css:{maxWidth:940, padding:"10px 20px", margin:"0 auto", display:"flex", flexDirection:"row", alignItems:"center", justifyContent:"space-between"}}, 
    c.jsx("p", null, "\u00a9 ", (new Date).getFullYear(), " UNPKG"), c.jsx("p", {css:{fontSize:"1.5rem"}}, c.jsx("a", {title:"Twitter", href:"https://twitter.com/unpkg", css:{color:"#aaa", display:"inline-block", ":hover":{color:"white"}}}, c.jsx(xa, null)), c.jsx("a", {title:"GitHub", href:"https://github.com/mjackson/unpkg", css:{color:"#aaa", display:"inline-block", marginLeft:"1rem", ":hover":{color:"white"}}}, c.jsx(ya, null)))))));
  }
  var M = "default" in t ? t["default"] : t;
  z = z && z.hasOwnProperty("default") ? z["default"] : z;
  var Fa = "undefined" !== typeof globalThis ? globalThis : "undefined" !== typeof window ? window : "undefined" !== typeof global ? global : "undefined" !== typeof self ? self : {}, m = D(function(a, b) {
    function d(a) {
      if ("object" === typeof a && null !== a) {
        var b = a.$$typeof;
        switch(b) {
          case f:
            switch(a = a.type, a) {
              case g:
              case e:
              case r:
              case m:
              case l:
              case u:
                return a;
              default:
                switch(a = a && a.$$typeof, a) {
                  case p:
                  case n:
                  case q:
                    return a;
                  default:
                    return b;
                }
            }case w:
          case v:
          case k:
            return b;
        }
      }
    }
    function c(a) {
      return d(a) === e;
    }
    Object.defineProperty(b, "__esModule", {value:!0});
    var f = (a = "function" === typeof Symbol && Symbol.for) ? Symbol.for("react.element") : 60103, k = a ? Symbol.for("react.portal") : 60106, r = a ? Symbol.for("react.fragment") : 60107, l = a ? Symbol.for("react.strict_mode") : 60108, m = a ? Symbol.for("react.profiler") : 60114, q = a ? Symbol.for("react.provider") : 60109, p = a ? Symbol.for("react.context") : 60110, g = a ? Symbol.for("react.async_mode") : 60111, e = a ? Symbol.for("react.concurrent_mode") : 60111, n = a ? Symbol.for("react.forward_ref") : 
    60112, u = a ? Symbol.for("react.suspense") : 60113, v = a ? Symbol.for("react.memo") : 60115, w = a ? Symbol.for("react.lazy") : 60116;
    b.typeOf = d;
    b.AsyncMode = g;
    b.ConcurrentMode = e;
    b.ContextConsumer = p;
    b.ContextProvider = q;
    b.Element = f;
    b.ForwardRef = n;
    b.Fragment = r;
    b.Lazy = w;
    b.Memo = v;
    b.Portal = k;
    b.Profiler = m;
    b.StrictMode = l;
    b.Suspense = u;
    b.isValidElementType = function(a) {
      return "string" === typeof a || "function" === typeof a || a === r || a === e || a === m || a === l || a === u || "object" === typeof a && null !== a && (a.$$typeof === w || a.$$typeof === v || a.$$typeof === q || a.$$typeof === p || a.$$typeof === n);
    };
    b.isAsyncMode = function(a) {
      return c(a) || d(a) === g;
    };
    b.isConcurrentMode = c;
    b.isContextConsumer = function(a) {
      return d(a) === p;
    };
    b.isContextProvider = function(a) {
      return d(a) === q;
    };
    b.isElement = function(a) {
      return "object" === typeof a && null !== a && a.$$typeof === f;
    };
    b.isForwardRef = function(a) {
      return d(a) === n;
    };
    b.isFragment = function(a) {
      return d(a) === r;
    };
    b.isLazy = function(a) {
      return d(a) === w;
    };
    b.isMemo = function(a) {
      return d(a) === v;
    };
    b.isPortal = function(a) {
      return d(a) === k;
    };
    b.isProfiler = function(a) {
      return d(a) === m;
    };
    b.isStrictMode = function(a) {
      return d(a) === l;
    };
    b.isSuspense = function(a) {
      return d(a) === u;
    };
  });
  S(m);
  var la = D(function(a, b) {
    (function() {
      function a(a) {
        if ("object" === typeof a && null !== a) {
          var b = a.$$typeof;
          switch(b) {
            case k:
              switch(a = a.type, a) {
                case e:
                case n:
                case l:
                case q:
                case m:
                case v:
                  return a;
                default:
                  switch(a = a && a.$$typeof, a) {
                    case g:
                    case u:
                    case p:
                      return a;
                    default:
                      return b;
                  }
              }case I:
            case w:
            case r:
              return b;
          }
        }
      }
      function c(b) {
        return a(b) === n;
      }
      Object.defineProperty(b, "__esModule", {value:!0});
      var f = "function" === typeof Symbol && Symbol.for, k = f ? Symbol.for("react.element") : 60103, r = f ? Symbol.for("react.portal") : 60106, l = f ? Symbol.for("react.fragment") : 60107, m = f ? Symbol.for("react.strict_mode") : 60108, q = f ? Symbol.for("react.profiler") : 60114, p = f ? Symbol.for("react.provider") : 60109, g = f ? Symbol.for("react.context") : 60110, e = f ? Symbol.for("react.async_mode") : 60111, n = f ? Symbol.for("react.concurrent_mode") : 60111, u = f ? Symbol.for("react.forward_ref") : 
      60112, v = f ? Symbol.for("react.suspense") : 60113, w = f ? Symbol.for("react.memo") : 60115, I = f ? Symbol.for("react.lazy") : 60116;
      f = function() {
      };
      var Ga = function(a) {
        for (var b = arguments.length, e = Array(1 < b ? b - 1 : 0), n = 1; n < b; n++) {
          e[n - 1] = arguments[n];
        }
        var c = 0;
        b = "Warning: " + a.replace(/%s/g, function() {
          return e[c++];
        });
        "undefined" !== typeof console && console.warn(b);
        try {
          throw Error(b);
        } catch (Ra) {
        }
      }, Ha = f = function(a, b) {
        if (void 0 === b) {
          throw Error("`lowPriorityWarning(condition, format, ...args)` requires a warning message argument");
        }
        if (!a) {
          for (var e = arguments.length, n = Array(2 < e ? e - 2 : 0), c = 2; c < e; c++) {
            n[c - 2] = arguments[c];
          }
          Ga.apply(void 0, [b].concat(n));
        }
      }, ka = !1;
      b.typeOf = a;
      b.AsyncMode = e;
      b.ConcurrentMode = n;
      b.ContextConsumer = g;
      b.ContextProvider = p;
      b.Element = k;
      b.ForwardRef = u;
      b.Fragment = l;
      b.Lazy = I;
      b.Memo = w;
      b.Portal = r;
      b.Profiler = q;
      b.StrictMode = m;
      b.Suspense = v;
      b.isValidElementType = function(a) {
        return "string" === typeof a || "function" === typeof a || a === l || a === n || a === q || a === m || a === v || "object" === typeof a && null !== a && (a.$$typeof === I || a.$$typeof === w || a.$$typeof === p || a.$$typeof === g || a.$$typeof === u);
      };
      b.isAsyncMode = function(b) {
        ka || (ka = !0, Ha(!1, "The ReactIs.isAsyncMode() alias has been deprecated, and will be removed in React 17+. Update your code to use ReactIs.isConcurrentMode() instead. It has the exact same API."));
        return c(b) || a(b) === e;
      };
      b.isConcurrentMode = c;
      b.isContextConsumer = function(b) {
        return a(b) === g;
      };
      b.isContextProvider = function(b) {
        return a(b) === p;
      };
      b.isElement = function(a) {
        return "object" === typeof a && null !== a && a.$$typeof === k;
      };
      b.isForwardRef = function(b) {
        return a(b) === u;
      };
      b.isFragment = function(b) {
        return a(b) === l;
      };
      b.isLazy = function(b) {
        return a(b) === I;
      };
      b.isMemo = function(b) {
        return a(b) === w;
      };
      b.isPortal = function(b) {
        return a(b) === r;
      };
      b.isProfiler = function(b) {
        return a(b) === q;
      };
      b.isStrictMode = function(b) {
        return a(b) === m;
      };
      b.isSuspense = function(b) {
        return a(b) === v;
      };
    })();
  });
  S(la);
  var ma = D(function(a) {
    a.exports = la;
  }), na = Object.getOwnPropertySymbols, Ia = Object.prototype.hasOwnProperty, Ja = Object.prototype.propertyIsEnumerable, Ka = function() {
    try {
      if (!Object.assign) {
        return !1;
      }
      var a = new String("abc");
      a[5] = "de";
      if ("5" === Object.getOwnPropertyNames(a)[0]) {
        return !1;
      }
      var b = {};
      for (a = 0; 10 > a; a++) {
        b["_" + String.fromCharCode(a)] = a;
      }
      if ("0123456789" !== Object.getOwnPropertyNames(b).map(function(a) {
        return b[a];
      }).join("")) {
        return !1;
      }
      var c = {};
      "abcdefghijklmnopqrst".split("").forEach(function(a) {
        c[a] = a;
      });
      return "abcdefghijklmnopqrst" !== Object.keys(Object.assign({}, c)).join("") ? !1 : !0;
    } catch (h) {
      return !1;
    }
  }() ? Object.assign : function(a, b) {
    if (null === a || void 0 === a) {
      throw new TypeError("Object.assign cannot be called with null or undefined");
    }
    var c = Object(a);
    for (var h, f = 1; f < arguments.length; f++) {
      var k = Object(arguments[f]);
      for (var r in k) {
        Ia.call(k, r) && (c[r] = k[r]);
      }
      if (na) {
        h = na(k);
        for (var l = 0; l < h.length; l++) {
          Ja.call(k, h[l]) && (c[h[l]] = k[h[l]]);
        }
      }
    }
    return c;
  }, K = function() {
  }, L = {}, sa = Function.call.bind(Object.prototype.hasOwnProperty);
  K = function(a) {
    a = "Warning: " + a;
    "undefined" !== typeof console && console.error(a);
    try {
      throw Error(a);
    } catch (b) {
    }
  };
  J.resetWarningCache = function() {
    L = {};
  };
  var La = Function.call.bind(Object.prototype.hasOwnProperty), C = function() {
  };
  C = function(a) {
    a = "Warning: " + a;
    "undefined" !== typeof console && console.error(a);
    try {
      throw Error(a);
    } catch (b) {
    }
  };
  var Ma = function(a, b) {
    function c(a, b) {
      return a === b ? 0 !== a || 1 / a === 1 / b : a !== a && b !== b;
    }
    function h(a) {
      this.message = a;
      this.stack = "";
    }
    function f(a) {
      function e(e, n, g, u, f, k, v) {
        u = u || "<<anonymous>>";
        k = k || g;
        if ("SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED" !== v) {
          if (b) {
            throw e = Error("Calling PropTypes validators directly is not supported by the `prop-types` package. Use `PropTypes.checkPropTypes()` to call them. Read more at http://fb.me/use-check-prop-types"), e.name = "Invariant Violation", e;
          }
          "undefined" !== typeof console && (v = u + ":" + g, !c[v] && 3 > d && (C("You are manually calling a React.PropTypes validation function for the `" + k + "` prop on `" + u + "`. This is deprecated and will throw in the standalone `prop-types` package. You may be seeing this warning due to a third-party PropTypes library. See https://fb.me/react-warning-dont-call-proptypes for details."), c[v] = !0, d++));
        }
        return null == n[g] ? e ? null === n[g] ? new h("The " + f + " `" + k + "` is marked as required " + ("in `" + u + "`, but its value is `null`.")) : new h("The " + f + " `" + k + "` is marked as required in " + ("`" + u + "`, but its value is `undefined`.")) : null : a(n, g, u, f, k);
      }
      var c = {}, d = 0, g = e.bind(null, !1);
      g.isRequired = e.bind(null, !0);
      return g;
    }
    function k(a) {
      return f(function(b, e, c, d, g, f) {
        b = b[e];
        return l(b) !== a ? (b = m(b), new h("Invalid " + d + " `" + g + "` of type " + ("`" + b + "` supplied to `" + c + "`, expected ") + ("`" + a + "`."))) : null;
      });
    }
    function r(b) {
      switch(typeof b) {
        case "number":
        case "string":
        case "undefined":
          return !0;
        case "boolean":
          return !b;
        case "object":
          if (Array.isArray(b)) {
            return b.every(r);
          }
          if (null === b || a(b)) {
            return !0;
          }
          var e = b && (p && b[p] || b["@@iterator"]);
          var c = "function" === typeof e ? e : void 0;
          if (c) {
            if (e = c.call(b), c !== b.entries) {
              for (; !(b = e.next()).done;) {
                if (!r(b.value)) {
                  return !1;
                }
              }
            } else {
              for (; !(b = e.next()).done;) {
                if ((b = b.value) && !r(b[1])) {
                  return !1;
                }
              }
            }
          } else {
            return !1;
          }
          return !0;
        default:
          return !1;
      }
    }
    function l(a) {
      var b = typeof a;
      return Array.isArray(a) ? "array" : a instanceof RegExp ? "object" : "symbol" === b || a && ("Symbol" === a["@@toStringTag"] || "function" === typeof Symbol && a instanceof Symbol) ? "symbol" : b;
    }
    function m(a) {
      if ("undefined" === typeof a || null === a) {
        return "" + a;
      }
      var b = l(a);
      if ("object" === b) {
        if (a instanceof Date) {
          return "date";
        }
        if (a instanceof RegExp) {
          return "regexp";
        }
      }
      return b;
    }
    function q(a) {
      a = m(a);
      switch(a) {
        case "array":
        case "object":
          return "an " + a;
        case "boolean":
        case "date":
        case "regexp":
          return "a " + a;
        default:
          return a;
      }
    }
    var p = "function" === typeof Symbol && Symbol.iterator, g = {array:k("array"), bool:k("boolean"), func:k("function"), number:k("number"), object:k("object"), string:k("string"), symbol:k("symbol"), any:f(E), arrayOf:function(a) {
      return f(function(b, c, e, d, g) {
        if ("function" !== typeof a) {
          return new h("Property `" + g + "` of component `" + e + "` has invalid PropType notation inside arrayOf.");
        }
        b = b[c];
        if (!Array.isArray(b)) {
          return b = l(b), new h("Invalid " + d + " `" + g + "` of type " + ("`" + b + "` supplied to `" + e + "`, expected an array."));
        }
        for (c = 0; c < b.length; c++) {
          var n = a(b, c, e, d, g + "[" + c + "]", "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED");
          if (n instanceof Error) {
            return n;
          }
        }
        return null;
      });
    }, element:function() {
      return f(function(b, c, d, g, f) {
        b = b[c];
        return a(b) ? null : (b = l(b), new h("Invalid " + g + " `" + f + "` of type " + ("`" + b + "` supplied to `" + d + "`, expected a single ReactElement.")));
      });
    }(), elementType:function() {
      return f(function(a, b, c, d, g) {
        a = a[b];
        return ma.isValidElementType(a) ? null : (a = l(a), new h("Invalid " + d + " `" + g + "` of type " + ("`" + a + "` supplied to `" + c + "`, expected a single ReactElement type.")));
      });
    }(), instanceOf:function(a) {
      return f(function(b, c, e, d, g) {
        if (!(b[c] instanceof a)) {
          var n = a.name || "<<anonymous>>";
          b = b[c];
          b = b.constructor && b.constructor.name ? b.constructor.name : "<<anonymous>>";
          return new h("Invalid " + d + " `" + g + "` of type " + ("`" + b + "` supplied to `" + e + "`, expected ") + ("instance of `" + n + "`."));
        }
        return null;
      });
    }, node:function() {
      return f(function(a, b, c, d, g) {
        return r(a[b]) ? null : new h("Invalid " + d + " `" + g + "` supplied to " + ("`" + c + "`, expected a ReactNode."));
      });
    }(), objectOf:function(a) {
      return f(function(b, c, e, d, g) {
        if ("function" !== typeof a) {
          return new h("Property `" + g + "` of component `" + e + "` has invalid PropType notation inside objectOf.");
        }
        b = b[c];
        c = l(b);
        if ("object" !== c) {
          return new h("Invalid " + d + " `" + g + "` of type " + ("`" + c + "` supplied to `" + e + "`, expected an object."));
        }
        for (var n in b) {
          if (La(b, n) && (c = a(b, n, e, d, g + "." + n, "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED"), c instanceof Error)) {
            return c;
          }
        }
        return null;
      });
    }, oneOf:function(a) {
      return Array.isArray(a) ? f(function(b, e, g, d, f) {
        b = b[e];
        for (e = 0; e < a.length; e++) {
          if (c(b, a[e])) {
            return null;
          }
        }
        e = JSON.stringify(a, function(a, b) {
          return "symbol" === m(b) ? String(b) : b;
        });
        return new h("Invalid " + d + " `" + f + "` of value `" + String(b) + "` " + ("supplied to `" + g + "`, expected one of " + e + "."));
      }) : (1 < arguments.length ? C("Invalid arguments supplied to oneOf, expected an array, got " + arguments.length + " arguments. A common mistake is to write oneOf(x, y, z) instead of oneOf([x, y, z]).") : C("Invalid argument supplied to oneOf, expected an array."), E);
    }, oneOfType:function(a) {
      if (!Array.isArray(a)) {
        return C("Invalid argument supplied to oneOfType, expected an instance of array."), E;
      }
      for (var b = 0; b < a.length; b++) {
        var c = a[b];
        if ("function" !== typeof c) {
          return C("Invalid argument supplied to oneOfType. Expected an array of check functions, but received " + q(c) + " at index " + b + "."), E;
        }
      }
      return f(function(b, c, e, g, d) {
        for (var f = 0; f < a.length; f++) {
          if (null == (0,a[f])(b, c, e, g, d, "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED")) {
            return null;
          }
        }
        return new h("Invalid " + g + " `" + d + "` supplied to " + ("`" + e + "`."));
      });
    }, shape:function(a) {
      return f(function(b, c, e, g, d) {
        b = b[c];
        c = l(b);
        if ("object" !== c) {
          return new h("Invalid " + g + " `" + d + "` of type `" + c + "` " + ("supplied to `" + e + "`, expected `object`."));
        }
        for (var f in a) {
          if (c = a[f]) {
            if (c = c(b, f, e, g, d + "." + f, "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED")) {
              return c;
            }
          }
        }
        return null;
      });
    }, exact:function(a) {
      return f(function(b, c, g, d, e) {
        var f = b[c], n = l(f);
        if ("object" !== n) {
          return new h("Invalid " + d + " `" + e + "` of type `" + n + "` " + ("supplied to `" + g + "`, expected `object`."));
        }
        n = Ka({}, b[c], a);
        for (var k in n) {
          n = a[k];
          if (!n) {
            return new h("Invalid " + d + " `" + e + "` key `" + k + "` supplied to `" + g + "`.\nBad object: " + JSON.stringify(b[c], null, "  ") + "\nValid keys: " + JSON.stringify(Object.keys(a), null, "  "));
          }
          if (n = n(f, k, g, d, e + "." + k, "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED")) {
            return n;
          }
        }
        return null;
      });
    }};
    h.prototype = Error.prototype;
    g.checkPropTypes = J;
    g.resetWarningCache = J.resetWarningCache;
    return g.PropTypes = g;
  };
  m = D(function(a) {
    a.exports = Ma(ma.isElement, !0);
  });
  var T = t.createContext(), Na = Object.assign || function(a) {
    for (var b = 1; b < arguments.length; b++) {
      var c = arguments[b], h;
      for (h in c) {
        Object.prototype.hasOwnProperty.call(c, h) && (a[h] = c[h]);
      }
    }
    return a;
  }, Oa = {border:0, clip:"rect(0 0 0 0)", height:"1px", width:"1px", margin:"-1px", padding:0, overflow:"hidden", position:"absolute"}, H = function(a) {
    return M.createElement("div", Na({style:Oa}, a));
  }, oa = D(function(a) {
    (function(b, c) {
      a.exports = c();
    })(Fa, function() {
      function a(a) {
        if (!a) {
          return !0;
        }
        if (!f(a) || 0 !== a.length) {
          for (var b in a) {
            if (q.call(a, b)) {
              return !1;
            }
          }
        }
        return !0;
      }
      function c(a) {
        return "number" === typeof a || "[object Number]" === t.call(a);
      }
      function h(a) {
        return "string" === typeof a || "[object String]" === t.call(a);
      }
      function f(a) {
        return "object" === typeof a && "number" === typeof a.length && "[object Array]" === t.call(a);
      }
      function k(a) {
        var b = parseInt(a);
        return b.toString() === a ? b : a;
      }
      function m(b, e, d, f) {
        c(e) && (e = [e]);
        if (a(e)) {
          return b;
        }
        if (h(e)) {
          return m(b, e.split("."), d, f);
        }
        var g = k(e[0]);
        if (1 === e.length) {
          return e = b[g], void 0 !== e && f || (b[g] = d), e;
        }
        void 0 === b[g] && (c(g) ? b[g] = [] : b[g] = {});
        return m(b[g], e.slice(1), d, f);
      }
      function l(b, e) {
        c(e) && (e = [e]);
        if (!a(b)) {
          if (a(e)) {
            return b;
          }
          if (h(e)) {
            return l(b, e.split("."));
          }
          var d = k(e[0]), g = b[d];
          if (1 === e.length) {
            void 0 !== g && (f(b) ? b.splice(d, 1) : delete b[d]);
          } else {
            if (void 0 !== b[d]) {
              return l(b[d], e.slice(1));
            }
          }
          return b;
        }
      }
      var t = Object.prototype.toString, q = Object.prototype.hasOwnProperty, p = {ensureExists:function(a, b, c) {
        return m(a, b, c, !0);
      }, set:function(a, b, c, d) {
        return m(a, b, c, d);
      }, insert:function(a, b, c, d) {
        var e = p.get(a, b);
        d = ~~d;
        f(e) || (e = [], p.set(a, b, e));
        e.splice(d, 0, c);
      }, empty:function(b, d) {
        if (a(d)) {
          return b;
        }
        if (!a(b)) {
          var e, g;
          if (!(e = p.get(b, d))) {
            return b;
          }
          if (h(e)) {
            return p.set(b, d, "");
          }
          if ("boolean" === typeof e || "[object Boolean]" === t.call(e)) {
            return p.set(b, d, !1);
          }
          if (c(e)) {
            return p.set(b, d, 0);
          }
          if (f(e)) {
            e.length = 0;
          } else {
            if ("object" === typeof e && "[object Object]" === t.call(e)) {
              for (g in e) {
                q.call(e, g) && delete e[g];
              }
            } else {
              return p.set(b, d, null);
            }
          }
        }
      }, push:function(a, b) {
        var c = p.get(a, b);
        f(c) || (c = [], p.set(a, b, c));
        c.push.apply(c, Array.prototype.slice.call(arguments, 2));
      }, coalesce:function(a, b, c) {
        for (var d, e = 0, f = b.length; e < f; e++) {
          if (void 0 !== (d = p.get(a, b[e]))) {
            return d;
          }
        }
        return c;
      }, get:function(b, d, f) {
        c(d) && (d = [d]);
        if (a(d)) {
          return b;
        }
        if (a(b)) {
          return f;
        }
        if (h(d)) {
          return p.get(b, d.split("."), f);
        }
        var e = k(d[0]);
        return 1 === d.length ? void 0 === b[e] ? f : b[e] : p.get(b[e], d.slice(1), f);
      }, del:function(a, b) {
        return l(a, b);
      }};
      return p;
    });
  });
  var pa = function(a) {
    return function(b) {
      return typeof b === a;
    };
  };
  var Pa = function(a, b) {
    var c = 1, h = b || function(a, b) {
      return b;
    };
    "-" === a[0] && (c = -1, a = a.substr(1));
    return function(b, d) {
      var f;
      b = h(a, oa.get(b, a));
      d = h(a, oa.get(d, a));
      b < d && (f = -1);
      b > d && (f = 1);
      b === d && (f = 0);
      return f * c;
    };
  };
  var ca = function() {
    var a = Array.prototype.slice.call(arguments), b = a.filter(pa("string")), c = a.filter(pa("function"))[0];
    return function(a, d) {
      for (var f = b.length, h = 0, l = 0; 0 === h && l < f;) {
        h = Pa(b[l], c)(a, d), l++;
      }
      return h;
    };
  };
  let qa = "B kB MB GB TB PB EB ZB YB".split(" "), ra = (a, b) => {
    let c = a;
    "string" === typeof b ? c = a.toLocaleString(b) : !0 === b && (c = a.toLocaleString());
    return c;
  };
  var da = (a, b) => {
    if (!Number.isFinite(a)) {
      throw new TypeError(`Expected a finite number, got ${typeof a}: ${a}`);
    }
    b = Object.assign({}, b);
    if (b.signed && 0 === a) {
      return " 0 B";
    }
    var c = 0 > a;
    let h = c ? "-" : b.signed ? "+" : "";
    c && (a = -a);
    if (1 > a) {
      return a = ra(a, b.locale), h + a + " B";
    }
    c = Math.min(Math.floor(Math.log10(a) / 3), qa.length - 1);
    a = Number((a / Math.pow(1000, c)).toPrecision(3));
    a = ra(a, b.locale);
    return h + a + " " + qa[c];
  }, W = {color:void 0, size:void 0, className:void 0, style:void 0, attr:void 0}, V = t.createContext && t.createContext(W), y = function() {
    y = Object.assign || function(a) {
      for (var b, c = 1, h = arguments.length; c < h; c++) {
        b = arguments[c];
        for (var f in b) {
          Object.prototype.hasOwnProperty.call(b, f) && (a[f] = b[f]);
        }
      }
      return a;
    };
    return y.apply(this, arguments);
  }, X = function(a) {
    return F({tag:"svg", attr:{viewBox:"0 0 14 16"}, child:[{tag:"path", attr:{fillRule:"evenodd", d:"M13 4H7V3c0-.66-.31-1-1-1H1c-.55 0-1 .45-1 1v10c0 .55.45 1 1 1h12c.55 0 1-.45 1-1V5c0-.55-.45-1-1-1zM6 4H1V3h5v1z"}}]})(a);
  };
  X.displayName = "GoFileDirectory";
  var Y = function(a) {
    return F({tag:"svg", attr:{viewBox:"0 0 12 16"}, child:[{tag:"path", attr:{fillRule:"evenodd", d:"M6 5H2V4h4v1zM2 8h7V7H2v1zm0 2h7V9H2v1zm0 2h7v-1H2v1zm10-7.5V14c0 .55-.45 1-1 1H1c-.55 0-1-.45-1-1V2c0-.55.45-1 1-1h7.5L12 4.5zM11 5L8 2H1v12h10V5z"}}]})(a);
  };
  Y.displayName = "GoFile";
  var aa = function(a) {
    return F({tag:"svg", attr:{viewBox:"0 0 496 512"}, child:[{tag:"path", attr:{d:"M165.9 397.4c0 2-2.3 3.6-5.2 3.6-3.3.3-5.6-1.3-5.6-3.6 0-2 2.3-3.6 5.2-3.6 3-.3 5.6 1.3 5.6 3.6zm-31.1-4.5c-.7 2 1.3 4.3 4.3 4.9 2.6 1 5.6 0 6.2-2s-1.3-4.3-4.3-5.2c-2.6-.7-5.5.3-6.2 2.3zm44.2-1.7c-2.9.7-4.9 2.6-4.6 4.9.3 2 2.9 3.3 5.9 2.6 2.9-.7 4.9-2.6 4.6-4.6-.3-1.9-3-3.2-5.9-2.9zM244.8 8C106.1 8 0 113.3 0 252c0 110.9 69.8 205.8 169.5 239.2 12.8 2.3 17.3-5.6 17.3-12.1 0-6.2-.3-40.4-.3-61.4 0 0-70 15-84.7-29.8 0 0-11.4-29.1-27.8-36.6 0 0-22.9-15.7 1.6-15.4 0 0 24.9 2 38.6 25.8 21.9 38.6 58.6 27.5 72.9 20.9 2.3-16 8.8-27.1 16-33.7-55.9-6.2-112.3-14.3-112.3-110.5 0-27.5 7.6-41.3 23.6-58.9-2.6-6.5-11.1-33.3 2.6-67.9 20.9-6.5 69 27 69 27 20-5.6 41.5-8.5 62.8-8.5s42.8 2.9 62.8 8.5c0 0 48.1-33.6 69-27 13.7 34.7 5.2 61.4 2.6 67.9 16 17.7 25.8 31.5 25.8 58.9 0 96.5-58.9 104.2-114.8 110.5 9.2 7.9 17 22.9 17 46.4 0 33.7-.3 75.4-.3 83.6 0 6.5 4.6 14.4 17.3 12.1C428.2 457.8 496 362.9 496 252 496 113.3 383.5 8 244.8 8zM97.2 352.9c-1.3 1-1 3.3.7 5.2 1.6 1.6 3.9 2.3 5.2 1 1.3-1 1-3.3-.7-5.2-1.6-1.6-3.9-2.3-5.2-1zm-10.8-8.1c-.7 1.3.3 2.9 2.3 3.9 1.6 1 3.6.7 4.3-.7.7-1.3-.3-2.9-2.3-3.9-2-.6-3.6-.3-4.3.7zm32.4 35.6c-1.6 1.3-1 4.3 1.3 6.2 2.3 2.3 5.2 2.6 6.5 1 1.3-1.3.7-4.3-1.3-6.2-2.2-2.3-5.2-2.6-6.5-1zm-11.4-14.7c-1.6 1-1.6 3.6 0 5.9 1.6 2.3 4.3 3.3 5.6 2.3 1.6-1.3 1.6-3.9 0-6.2-1.4-2.3-4-3.3-5.6-2z"}}]})(a);
  };
  aa.displayName = "FaGithub";
  var Z = function(a) {
    return F({tag:"svg", attr:{viewBox:"0 0 512 512"}, child:[{tag:"path", attr:{d:"M459.37 151.716c.325 4.548.325 9.097.325 13.645 0 138.72-105.583 298.558-298.558 298.558-59.452 0-114.68-17.219-161.137-47.106 8.447.974 16.568 1.299 25.34 1.299 49.055 0 94.213-16.568 130.274-44.832-46.132-.975-84.792-31.188-98.112-72.772 6.498.974 12.995 1.624 19.818 1.624 9.421 0 18.843-1.3 27.614-3.573-48.081-9.747-84.143-51.98-84.143-102.985v-1.299c13.969 7.797 30.214 12.67 47.431 13.319-28.264-18.843-46.781-51.005-46.781-87.391 0-19.492 5.197-37.36 14.294-52.954 51.655 63.675 129.3 105.258 216.365 109.807-1.624-7.797-2.599-15.918-2.599-24.04 0-57.828 46.782-104.934 104.934-104.934 30.213 0 57.502 12.67 76.67 33.137 23.715-4.548 46.456-13.32 66.599-25.34-7.798 24.366-24.366 44.833-46.132 57.827 21.117-2.273 41.584-8.122 60.426-16.243-14.292 20.791-32.161 39.308-52.628 54.253z"}}]})(a);
  };
  Z.displayName = "FaTwitter";
  var O = {color:"#0076ff", textDecoration:"none", ":hover":{textDecoration:"underline"}}, x = {paddingTop:6, paddingRight:3, paddingBottom:6, paddingLeft:3, borderTop:"1px solid #eaecef"}, N = A({}, x, {color:"#424242", width:17, paddingRight:2, paddingLeft:10, "@media (max-width: 700px)":{paddingLeft:20}}), P = A({}, x, {textAlign:"right", paddingRight:10, "@media (max-width: 700px)":{paddingRight:20}});
  ba.propTypes = {path:m.string.isRequired, details:m.objectOf(m.shape({path:m.string.isRequired, type:m.oneOf(["directory", "file"]).isRequired, contentType:m.string, integrity:m.string, size:m.number})).isRequired};
  ea.propTypes = {path:m.string.isRequired, details:m.shape({contentType:m.string.isRequired, highlights:m.arrayOf(m.string), uri:m.string, integrity:m.string.isRequired, language:m.string.isRequired, size:m.number.isRequired}).isRequired};
  var Da = c.css(ha(), '\nfont-family: -apple-system,\n  BlinkMacSystemFont,\n  "Segoe UI",\n  "Roboto",\n  "Oxygen",\n  "Ubuntu",\n  "Cantarell",\n  "Fira Sans",\n  "Droid Sans",\n  "Helvetica Neue",\n  sans-serif;\n', "\nfont-family: Menlo,\n  Monaco,\n  Lucida Console,\n  Liberation Mono,\n  DejaVu Sans Mono,\n  Bitstream Vera Sans Mono,\n  Courier New,\n  monospace;\n"), Ea = c.css(fa()), ja = {color:"#0076ff", textDecoration:"none", ":hover":{textDecoration:"underline"}}, Qa = m.shape({path:m.string.isRequired, 
  type:m.oneOf(["directory", "file"]).isRequired, details:m.object.isRequired});
  ia.propTypes = {packageName:m.string.isRequired, packageVersion:m.string.isRequired, availableVersions:m.arrayOf(m.string), filename:m.string.isRequired, target:Qa.isRequired};
  z.hydrate(M.createElement(ia, window.__DATA__ || {}), document.getElementById("root"));
})(React, ReactDOM, emotionCore);

</script></body></html>
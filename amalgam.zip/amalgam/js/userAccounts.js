class UserAccounts {
    
    /* getUserID() initiates id with a value of 0 for debugging purposes. No user should actually have an id
    of 0, so if this function somehow end up managing to return 0, then something isn't working right 
    the timing is all wrong and nothing is working because of it*/
    static getUserID(){
        var jwt = Sessions.getCookie('jwt');
        var id = 0; 
        $.post("api/validate_token.php", JSON.stringify({ jwt:jwt })).done(function(result){
                id = parseInt(result.data.id);
                //console.log(result)
                console.log(id)
                return id;
        }); 
    }

    static createUser(form_data,sign_up_form){
        $.ajax({
            url: "api/create_user.php",
            type : "POST",
            contentType : 'application/json',
            data : form_data,
            success : function(result) {
                // if response is a success, tell the user it was a successful sign up & empty the input boxes
                $('#response').html("<div class='alert alert-success'>Successful sign up. Please login.</div>");
                sign_up_form.find('input').val('');
            },
            error: function(xhr, resp, text){
                // on error, tell the user sign up failed
                $('#response').html("<div class='alert alert-danger'>Unable to sign up. Please contact admin.</div>");
            }
        });
    }

    static login(form_data,login_form){
        $.ajax({
            url: "api/login.php",
            type : "POST",
            contentType : 'application/json',
            data : form_data,
            success : function(result){
                // store jwt to cookie
                Sessions.setCookie("jwt", result.jwt, 1);
                // show home page & tell the user it was a successful login
                Viewer.showHomePage();
                $('#response').html("<div class='alert alert-success'>Successful login.</div>");
            },
            // error response will be here
            error: function(xhr, resp, text){
                // on error, tell the user login has failed & empty the input boxes
                $('#response').html("<div class='alert alert-danger'>Login failed. Email or password is incorrect.</div>");
                login_form.find('input').val('');
            }
        });
    }

    static updateUser(form_data){
        $.ajax({
            url: "api/update_user.php",
            type : "POST",
            contentType : 'application/json',
            data : form_data,
            success : function(result) {
                // tell the user account was updated
                $('#response').html("<div class='alert alert-success'>Account was updated.</div>");
                // store new jwt to coookie
                Sessions.setCookie("jwt", result.jwt, 1);
            },
        
            // errors will be handled here
            // show error message to user
            error: function(xhr, resp, text){
                if(xhr.responseJSON.message=="Unable to update user."){
                    $('#response').html("<div class='alert alert-danger'>Unable to update account.</div>");
                }
                else if(xhr.responseJSON.message=="Access denied."){
                    HTMLGenerator.showLoginPage();
                    $('#response').html("<div class='alert alert-success'>Access denied. Please login</div>");
                }
                else if (xhr.responseJSON.message=="Token Timeout."){
                    $('#response').html("<div class='alert alert-danger'>Token has timed out.</div>");

                }
            }
        });
    }
}
class Viewer {
    // clearResponse() will be here
    // remove any prompt messages
    static clearResponse(){
        $('#response').html('');
    }

    // showLoginPage() will be here
    // show login page
    static showLoginPage(){
        // remove jwt
        Sessions.setCookie("jwt", "", 1);

        // login page html
        var html = HTMLGenerator.getLoginFormHTML();
        $('#content').html(html);
        Viewer.clearResponse();
        Viewer.showLoggedOutMenu();
    }

    // if the user is logged out
    static showLoggedOutMenu(){
        // show login and sign up from navbar & hide logout button
        $("#login, #sign_up").show();
        $("#logout").hide();
    }
    
    // show home page
    static showHomePage(){
        // validate jwt to verify access
        var jwt = Sessions.getCookie('jwt');
        //console.log($.post("api/decode_token.php", JSON.stringify({jwt:jwt})));
        
        $.post("api/validate_token.php", JSON.stringify({ jwt:jwt })).done(function(result) {
            // home page html will be here
            // if valid, show homepage
            var html = HTMLGenerator.getHomePageHTML();    
            $('#content').html(html);
            Viewer.showLoggedInMenu();
        })

        // show login page on error will be here
        // show login page on error
        .fail(function(result){
            Viewer.showLoginPage();
            $('#response').html("<div class='alert alert-danger'>Please login to access the home page.</div>");
        });
    }

    // if the user is logged in
    static showLoggedInMenu(){
        // hide login and sign up from navbar & show logout button
        $("#login, #sign_up").hide();
        $("#logout").show();
    }
    
    // showUpdateAccountForm() will be here
    static showUpdateAccountForm(){
        // validate jwt to verify access
        var jwt = Sessions.getCookie('jwt');
        var tokenInfo = $.post("api/decode_token.php", JSON.stringify({jwt:jwt}));
        console.log(tokenInfo);
        $.post("api/validate_token.php", JSON.stringify({ jwt:jwt })).done(function(result) {
            // html form for updating user account will be here
            // if response is valid, put user details in the form
            var html = HTMLGenerator.getUpdateAccountFormHTML(result);
            Viewer.clearResponse();
            Viewer.showLoggedInMenu();
            $('#content').html(html);
        })
    
        // error message when jwt is invalid will be here
        // on error/fail, tell the user he needs to login to show the account page
        .fail(function(result){
            Viewer.showLoginPage();
            $('#response').html("<div class='alert alert-danger'>Please login to access the account page.</div>");
        });
    }

    // show default view
    static showDefaultView(){
        //should the button on click things be handled here?
        // validate jwt to verify access
        var jwt = Sessions.getCookie('jwt');
        $.post("api/validate_token.php", JSON.stringify({ jwt:jwt })).done(function(result) {
            // html form for updating user account will be here
            // if response is valid, put user details in the form
            var html = HTMLGenerator.getHomePageHTML();
            jQuery.getJSON("http://localhost/amalgam/api/product/read.php", function(data){
                $.each(data.records, function(key, val) {
                    html += HTMLGenerator.addProductToTable(val);
                    $('#content').html(html);                  
                });
            });
            Viewer.clearResponse();
            Viewer.showLoggedInMenu();
            $('#content').html(html);
        })
    
        // error message when jwt is invalid will be here
        // on error/fail, tell the user he needs to login to show the account page
        .fail(function(result){
            Viewer.showLoginPage();
            $('#response').html("<div class='alert alert-danger'>Please login to access the account page.</div>");
        });
    }
}
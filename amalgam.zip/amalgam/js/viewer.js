class Viewer {

    static clearResponse(){
        $('#response').html('');
    }

    static showLoginPage(){
        // remove jwt
        Sessions.setCookie("jwt", "", 1);

        // login page html
        var html = HTMLGenerator.getLoginFormHTML();
        $('#content').html(html);
        Viewer.clearResponse();
        Viewer.showLoggedOutMenu();
    }

    static showLoggedOutMenu(){
        // show login and sign up from navbar & hide logout button
        $("#login, #sign_up").show();
        $("#logout, #contacts").hide(); //adding the #contacts part should cause errors
    }
    
    static showHomePage(){
        var jwt = Sessions.getCookie('jwt');
        $.post("api/validate_token.php", JSON.stringify({ jwt:jwt })).done(function(result) {
            var html = "";
            html += HTMLGenerator.getHomePageHTML();
            jQuery.getJSON("http://localhost/amalgam/api/product/read_paging.php", function(data){
                $.each(data.records, function(key, val) {
                    html += HTMLGenerator.addProductToTable(val);
                });
                // end table
                html+=`</table>`;
                if(data.paging){ 
                    html +=  HTMLGenerator.addProductPageList(data);
                }
                $("#content").html(html);
            });
            Viewer.clearResponse();
            Viewer.showLoggedInMenu();
            $('#content').html(html);
        })
        // show login page on error 
        .fail(function(result){
            Viewer.showLoginPage();
            $('#response').html("<div class='alert alert-danger'>Please login to access the home page.</div>");
        });
    }

    static showLoggedInMenu(){
        // hide login and sign up from navbar & show logout button
        $("#login, #sign_up").hide();
        $("#logout, #contacts").show(); //adding #contacts should cause errors, but it doesn't 
    }
    
    static showUpdateAccountForm(){
        // validate jwt to verify access
        var jwt = Sessions.getCookie('jwt');
        var tokenInfo = $.post("api/decode_token.php", JSON.stringify({jwt:jwt}));
        $.post("api/validate_token.php", JSON.stringify({ jwt:jwt })).done(function(result) {
            // html form for updating user account will be here
            // if response is valid, put user details in the form
            
            var html = HTMLGenerator.getUpdateAccountFormHTML(result);
            Viewer.clearResponse();
            Viewer.showLoggedInMenu();
            $('#content').html(html);
        })
    
        // error message when jwt is invalid will be here
        // on error/fail, tell the user he needs to login to show the account page
        .fail(function(result){
            Viewer.showLoginPage();
            $('#response').html("<div class='alert alert-danger'>Please login to access the account page.</div>");
        });
    }

    static showContactHomePage(){
        UserAccounts.getUserID();
        var jwt = Sessions.getCookie('jwt');
        $.post("api/validate_token.php", JSON.stringify({ jwt:jwt })).done(function(result){
            var html = "";
            html += HTMLGenerator.getContactsBase();
            $.getJSON("http://localhost/amalgam/api/contacts/read_pageC.php", function(data){
                $.each(data.records, function(key, val) { 
                    html += HTMLGenerator.addContactToTable(val);
                });
                html+=`</table>`;
                if(data.paging){ 
                    html +=  HTMLGenerator.addContactPageList(data);
                }
                $("#content").html(html); 
            });
        }).fail(function(result){
            Viewer.showLoginPage();
            $('#response').html("<div class='alert alert-danger'>Please login to access the account page.</div>");
        });

    }

    static showDefaultView(){ 
        var jwt = Sessions.getCookie('jwt');
        $.post("api/validate_token.php", JSON.stringify({ jwt:jwt })).done(function(result) {
            var read_products_html = "";
            read_products_html += HTMLGenerator.getHomePageHTML();
            jQuery.getJSON("http://localhost/amalgam/api/product/read_paging.php", function(data){
                $.each(data.records, function(key, val) {
                    read_products_html += HTMLGenerator.addProductToTable(val);
                });
                read_products_html+=`</table>`;
                if(data.paging){ 
                    read_products_html +=  HTMLGenerator.addProductPageList(data);
                }
                $("#content").html(read_products_html);
            });
            Viewer.clearResponse();
            Viewer.showLoggedInMenu();
            })
        .fail(function(result){
            Viewer.showLoginPage();
            $('#response').html("<div class='alert alert-danger'>Please login to access the account page.</div>");
        });
    }
}